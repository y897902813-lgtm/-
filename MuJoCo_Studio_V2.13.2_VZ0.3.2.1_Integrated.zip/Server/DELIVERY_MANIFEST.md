# MuJoCo Studio Clean Delivery Manifest — V2.13.2 / Client V0.3.9 WindowsFix



## V2.13.2 本次修改

- Hub→VZ 模型发布增加驱动名称/运动副绑定投射；首次 V2.13.2 校准 0%=0、100%=30、速度=30，后续 Hub 刷新保留 VZ 本地校准。Hub 运动段仍只保存在/同步于时序库。
- VZ 用户页支持右侧模型卡片拖入场景并做多模型联合仿真。运行时 composite 对 Layer/joint/closure/drive/mesh/asset 统一 `_a/_b/...` namespace，并同步 remap 所有引用；源模型与源时序不写回。
- 用户场景看板改为每模型一个绿色总包络、1 s 时间轴和 `时序1/时序2/...` 切换；“编辑”进入用户时序甘特图。Hub 时序编辑前自动复制到 VZ workspace；用户只改 start/travel，速度固定为工程师 rated speed。
- 工程师 WEB 时序色块补齐 `start–end` 和累计 `position_start→position_end` 信息。
- 二代结果查看删除 MuJoCo View/一键导出动画 HTML，后台仿真改为“刷新结果”；axis 高度/±游标移入右侧坐标系导航并压缩 header；动画栏新增“重新生成”，只覆盖最新 HTML/刷新 iframe，不自动下载。
- 架构：新增业务 Tool 目录 **0**，新增 ProjectSpec/L1/L2/L3/Session/Job 权威持久字段 **0**，新增主 Job/artifact **0**；仅新增 VZ runtime-only `vz/scene_composition.py`。
- Server: 2.13.2；Client: 0.3.9；Viewer schema/controller: 4；VZ: 0.3.2.1。


## V2.13.1 本次修改

- VZ 工程师页增加“时序库”：Hub 同步源只读，复制到 VZ workspace 后才允许重命名、删除和双击甘特色块编辑；Hub 重新同步不会覆盖本地副本。WEB 甘特图同时提供横/纵缩放、游标、时间排序/倒序、倒放、驱动显隐/显示名/拖拽顺序、平移和放大/还原。
- 甘特图颜色固定为两类：黄色=匀速/缓起缓停；蓝色=映射/点表/外部 CSV 变速。VZ 用户页增加时序分页。
- 用户动画底部 transport/progress 约缩小一半且背景 alpha=0.20；硬点/H 点坐标移至左下角，透明背景白字。
- 二代结果查看新增全驱动“自适应坐标系”和单坐标系名称“自适应”。
- CSV 不再作为 managed delivery：合并 CSV 只写模型 `时序库/`；普通分轴 CSV 仅本地下载。当前 baseline delivery 为 `nx_afu_script / gantt_png / model_json / animation_html` 四类；历史 `axes_csv_folder` 仅兼容。
- 移除 `/export-axes-csv` 的通用 desktop-only 中间件门禁，修复 Linux Server 合并时序生成被“未启用桌面能力”阻断。
- 架构：新增业务 Tool 目录 **0**，新增 ProjectSpec/L1/L2/L3/Session/Job 持久字段 **0**。
- Server: 2.13.1；Client: 0.3.9；Viewer schema/controller: 4；VZ: 0.3.2.1。

## V2.13.0 本次修改

- VZ 用户页移除可见左栏与右侧模型库管理按钮，仅保留中间场景/时序控制板和右侧只读分类/模型缩略图；顶部动画按钮缩小，用户动画中心项目组水印取消。
- 工程师缩略图生成/缓存状态移动到模型文件夹行，不再占用顶栏。
- 每个 Hub 模型目录新增物理 `时序库/`；结果合并导出同时生成带驱动/运动段/结果数据的主时序 CSV，并为 mapping 另存 `<驱动>--<运动段>映射表格.csv`。
- 驱动设置新增“导入CSV”：本地文件夹与服务端时序库共用一个 parser，恢复驱动名称、运动段参数及 mapping points，再走既有 Editor 提交链。
- Hub→VZ 增加模型级时序库 ZIP 原子同步；VZ manifest 投射 drives/segments，用户控制板按每个驱动的真实多段色块显示，并周期刷新 Hub 后续变更。
- 快速渲染默认固定为更浅的 Classic；高质量渲染继续使用工程师配置。
- 架构：新增业务 Tool 目录 **0**，新增 ProjectSpec 持久字段 **0**；新增 domain CSV 编解码 helper 与必要传输 API。
- Server: 2.13.0；Client: 0.3.9；Viewer schema/controller: 4；VZ: 0.3.2.1。


## V2.12.2.1 本次修改

- 伴生 mapping 统一为严格穿过全部归一化节点的 natural-quintic / global minimum-jerk 曲线；移除 2049 点阈值、降采样、低通和低密/高密双插值语义。
- Server motion 与 Native Viewer 复用 `mapping_curve.py`；Viewer bundle 携带该 helper 并校验 SHA-256；Browser 数学与其数值对拍。
- forward / inverse 使用同一五次曲线；不增加 acceleration clamp，不修改原始 ProjectSpec mapping points。
- 定向回归覆盖 10001 hard knots、C2/C3 连续、jerk cost、Python/JS parity。
- Server: 2.12.2.1；Client: 0.3.9；Viewer schema/controller: 4；VZ: 0.3.2.1。

## V2.12.2 本次修改

- 高密伴生映射运行时稳定化：固定 2049 knot 上限、轻量去噪、C2 spline；原始 mapping points 不改。
- Dynamic 曲线优先 MuJoCo qvel/qacc，避免 qpos 二次差分放大纹波。
- 层级/全部数模自适应共用既有 `/meshes/adaptive` 单链路，现支持 family add/remove/case-normalize。
- Hub 刷新无选择时模型属性与数模资产检视器为空态；项目文件夹只显示名称，旧甘特图异步请求不得回填。
- 公共数模文件夹支持重命名，并原子级联更新所有当前模型 `mesh_root` 引用。
- Server: 2.12.2；Client: 0.3.9；Viewer schema/controller: 4；VZ: 0.3.2.1。

## V2.12.1.5 本次修改

- 登录页改为标准 GLB 三维资产：MuJoCo 动力学核心、三条时序轨道、关键帧和收敛轨迹；离线 WebGL2 实时金属渲染并跟随鼠标视角。验证成功后相机推进、模型高速扩张并穿过核心，再以短亮场衔接 Hub。附 Blender 3.6+ 可重建脚本，不改认证 API、账号数据或后端协议。
- Hub 跨平台数据根默认值：Linux 向上 2 级，Windows 向上 4 级；持久化设置优先。
- Pure Dynamic 驱动：新增 `DriveSpec.dynamic_lock_force=2000`，仅目标静止时接合，运动前释放。
- UI：驱动面板新增自锁力入口并保留 Kp/Kv；自锁单位随关节类型显示 N / N·m。
- 架构：未新增 Tool/API/Job；复用 `param.set`、现有 DriveSpec、XML 与 simulation 链路。
- Client runtime/protocol 0.3.9、VZ runtime/protocol 0.3.2.1 不变。


- Server: 2.12.1.5
- Client runtime version string: 0.3.9
- Client runtime / distribution label: 0.3.9 / 0.3.9 WindowsFix
- Minimum compatible Client protocol for Viewer launch: 0.3.9
- Architecture authority: `architecture_master_prompt.md`
- Consolidated version history: `../CHANGELOG.md`
- Server deployment guide: `DEPLOYMENT.md`
- Server usage summary: `README.md`
- Client usage summary: `../Client/README.md`


## V2.12.1.5 VZ second-generation center 3D text / compact render-settings iteration

- Restores the original second-generation center 3D text `C项目-时序仿真组` in VZ animation HTML by reusing the existing watermark mesh code already present in the shared exporter.
- The same watermark payload/render path is used by Fast and Perfect and by Classic, Bright Studio and Automotive Interior scenes.
- Engineer HTML render settings now use a compact three-column desktop grid with reduced vertical spacing; no `render_scene` schema change is introduced.
- Added persistent schema fields: 0. Added business Tool/API/Job/artifact directories: 0.
- Main Server version is 2.12.1.5. Client runtime remains 0.3.9; Viewer bundle schema/controller signature remain 4; VZ runtime/protocol remains 0.3.2.1. Architecture contract: `architecture_master_prompt.md` section 80.

## V2.12.1.1 VZ offline-animation bootstrap hotfix

- Fixes the V2.12.1 regression where both Fast and Perfect HTML renders could remain on “正在载入离线动画…” forever.
- Root cause: the shared HTML renderer referenced `KEY_LIGHT_DIR` / `KEY_LIGHT_COLOR` after the V2.12.1 configurable directional-light change, but the corresponding bootstrap constants were not emitted into the generated HTML template. The synchronous ReferenceError stopped initialization before the first render frame.
- Reuses the existing `render_scene` lighting variables and HTML renderer; no new Tool/API/Job/artifact directory and no new persisted schema field are introduced.
- Adds a renderer bootstrap error surface so future synchronous or rejected startup failures replace the spinner with a visible error message rather than hanging indefinitely.
- Main Server version is 2.12.1.1. Client runtime remains 0.3.9; Viewer bundle schema/controller signature remain 4; VZ runtime/protocol remains 0.3.2.1. Architecture contract: `architecture_master_prompt.md` section 79.

## V2.12.1 VZ render-lighting / preview-polish iteration

- Reused the existing VZ HTML renderer and `render_scene` pool to brighten Fast/Perfect output and expose a configurable main directional light.
- Narrowed the engineer model-library width by roughly one third and switched folder icons to yellow using the existing explorer CSS.
- Reused the existing front-preview capture path, raised the per-mesh preview cap to 200000 faces, and changed preview lighting/background.
- Kept the existing HTML floor pass but made the floor back face transparent so bottom views are not occluded.
- This release introduced a missing directional-light bootstrap constant regression in the shared offline HTML; V2.12.1.1 fixes that startup failure.

## V2.12.0 VZ engineer/user preview / single-render / silhouette-outline iteration

- Reuses the existing 15-directory main Tool pool, VZ ModelStore, two-level `model_library.json`, Viewer capture path, Fast HTML exporter, and material-editor pick framebuffer; new main business Tool/API/Job directories: 0.
- Engineer Fast render prepares simulation data with zero render exports, then performs exactly one Fast HTML export and reports `X-VZ-Render-Time-Ms`; the old 1-warmup + 5-measured export loop is removed.
- Material selection replaces the world-AABB line frame with a screen-space silhouette outline derived from the existing pick FBO, so slanted/rotated meshes are tightly outlined without modifying PBR/color/material state.
- Engineer automatically generates revision-aware `derived/front_preview.png` artifacts using the second-generation front-view axis convention (X horizontal, Z vertical, Y depth). User model-library cards read those cached images only and no longer mount a Viewer per card on page entry.
- Engineer Explorer removes “+模型” and “复制模型”, keeps M model nodes, exposes folder-style hierarchy with inline rename, and renames VZ deletion to “移除模型”/Hub unpush semantics.
- Main Server version is 2.12.0. Client remains 0.3.9; Viewer bundle schema/controller signature remain 4; VZ runtime/protocol remains 0.3.2.1. Architecture contract: `architecture_master_prompt.md` section 77.


## V2.11.7 Hub project-folder properties / editable baseline names / frozen-time iteration

- Folder selection projects only the existing folder name property. Root rename reuses `/api/project-root/name`; child rename reuses `/api/model-types/{category}/name` + `ProjectStore.rename_category()`. No folder archive/delivery/Gantt query is required for the property panel.
- Baseline creation adds only transient `BaselineCreateRequest.name`; final truth is still `ProjectSpec.name`. `ProjectStore.unique_project_name()` resolves exact-folder duplicates with `_001/_002...`; `rename_baseline_history_reference()` keeps the source history marker aligned after post-create rename.
- Existing `PUT /api/projects/{id}` is reused for baseline rename, with a Server-side baseline branch that projects only the name onto the authoritative frozen baseline before dispatching existing `project.replace`.
- Baseline Hub cards use `baseline_created_at` and display larger/bold “冻结时间”; `updated_at` from later renames cannot affect frozen-time ordering.
- Added persistent ProjectSpec/L1/L2/L3/Session/Job/VZ fields: 0. Added business Tool/API/Job/artifact/tool directories: 0. Client remains 0.3.9; Viewer bundle schema/controller signature remain 4; VZ remains 0.3.2.1.

## V2.11.6 Hub recursive catalog / baseline-log reuse / WeCom sealed iteration

- Model-type folder badges recursively include every descendant model; the root project badge uses the full role-projected project catalog.
- Selecting a folder keeps direct models and adds only the newest frozen baseline from each exact descendant folder; descendant checked-in/checked-out models are not penetrated into the list.
- Baseline log confirmation refreshes the existing unified version history and prefills the latest ordinary archive log.
- WeCom baseline notification is sealed: no Hub Webhook control/prompt/local setting, no `webhook_url` baseline request field, no outgoing baseline notification request, and no notification response headers.
- No new persisted ProjectSpec/session/job/VZ field and no new business Tool/API/Job/artifact/tool directory. Client runtime remains 0.3.9; Viewer schema/signature remain 4; VZ runtime/protocol remains 0.3.2.1.


## V2.11.5 Baseline five-artifact / automotive render iteration

- Result Viewer batch CSV export now also refreshes the existing managed coordinate-system CSV-folder delivery artifact.
- Baseline creation regenerates/overwrites CSV folder, NX AFU script, Gantt PNG and model JSON from current authoritative inputs, while reusing the existing animation HTML; missing HTML is user-notified and automatically prepared by the existing background animation-export Job before baseline creation continues.
- A baseline is created only after all five managed delivery kinds are present and the latest simulation provenance matches the current project/assets.
- VZ high-quality rendering adds the backward-compatible `automotive_interior` preset and reuses existing PBR fields/shader infrastructure for neutral tone mapping, studio reflection cards, roughness-aware IBL/specular occlusion/clearcoat and Perfect-only higher-quality soft shadows.
- Client runtime stays 0.3.9, Viewer schema/signature stay 4, VZ runtime/protocol stays 0.3.2.1; no new persisted ProjectSpec/session/job/VZ field or new business Tool/API/Job/artifact.

## V2.11.4 Material selection / optional Gantt patch

- Engineer Material Editor selection is a separate line-rendered boundary frame; it does not modify the selected mesh PBR/color/material preview.
- MuJoCo Viewer launch no longer depends on successful browser Gantt-cache generation. Missing/invalid Gantt produces a user-visible warning and the Viewer trajectory launch continues.
- Client runtime remains 0.3.9; bundle schema/controller signature remain 4; VZ runtime/protocol remains 0.3.2.1.
- No new ProjectSpec/session/job/VZ persisted field and no new business Tool/API/Job/artifact.

## V2.11.3.1 Viewer mapping-companion patch

- Any manual command inside a mapping chain is canonicalized to the root source; a follower drag uses the existing inverse mapping and then all companions are forward-projected from the root.
- The whole mapping family enters manual/decoupled mode together, so virtual-source mappings write their physical follower joints on the first source drag.
- Linked source/follower slider values remain coherent while dragging either member; recouple/remote decoupled normalization also operate on the full family.
- Client runtime remains 0.3.9; bundle schema/controller signature remain 4. No persisted schema/API/Tool/Job is added. Architecture contract: `architecture_master_prompt.md` section 72.

## V2.11.3 native Viewer motor latency / kinematic closed-chain patch

- Reuses the existing Viewer session-local control dict, drive mapping helpers and the single authoritative `domain/kinematic_closure.py`; new ProjectSpec/L1/L2/L3/Session/Job fields: 0; new business Tool/API/Job/artifact: 0.
- Motor pointer motion no longer uses `tk.Scale(command=...)` per-motion Python callbacks. Tk updates the bound `DoubleVar` natively; the render loop samples active drags at most once per frame and drains latest values through `pending_manual_inputs`. Mapping/clamp/decouple work therefore runs at most once per frame, changed labels are updated selectively, decoupled/dragging widgets are not programmatically rewritten, and timeline followers are projected at a bounded 30 Hz with a resolution-relative threshold.
- Kinematic Viewer frames now enforce enabled closures after trajectory interpolation and manual motor qpos overrides. The shared DLS solver runs with `kinematics_only=True`, warm-starts nearby passive states, resets warm-start on large seeks, rejects drive/passive conflicts, and holds the last valid closed pose on non-convergence instead of showing an open-chain failure.
- Remote Viewer bundle schema remains 4 and controller signature remains 4. The bundle adds the exact authoritative `kinematic_closure.py` plus SHA-256 manifest metadata; the server-supplied standalone controller verifies and loads it. Existing Client V0.3.9 extraction/call ABI is sufficient, so Client runtime/protocol stays 0.3.9. Integrated VZ runtime/protocol stays 0.3.2.1.
- Historical V2.11.3 runtime/package/cache-buster/Viewer/animation-export version: 2.11.3. Architecture contract: `architecture_master_prompt.md` section 71.

## V2.11.1 engineer Explorer / user scene-board / strict-result-grid patch

- Reuses the V2.11.0 data root, Hub→VZ publication, `ModelStore`, two-level `model_library.json`, `control_graph.json`, scene-coordinate arrays, preview renderer and single-model controls. New main ProjectSpec/L1/L2/L3/Session/Job fields: 0. New main business Tool/API/Job: 0.
- Engineer left column is 376px and merges project/model folders into one flat Explorer with fold state, inline folder actions and model drag classification through the existing APIs. The administrator storage address UI is condensed while retaining the same resolver/probe/save contract.
- Quick rendering defaults to 120000 faces per mesh across engineer front-end and VZ backend fallbacks. Render completion suppresses the redundant lower “渲染已生成” JSON panel.
- Engineer scene coordinates are exactly two inline fields beside the model name: hard point and H point. Both accept `Point(x,y,z)`, `x,y,z` and Chinese comma variants and write the existing `scene_coordinates.*_mm` arrays.
- User site visible interaction is now animation HTML + draggable horizontal splitter + lower model control board, with a far-right two-row horizontal folder selector and larger vertical front-view thumbnails. Thumbnail drag reuses existing scene alignment/control-graph state; the old graph engine remains code-compatible but has no visible canvas in this release.
- Result sampling uses the strict timestep grid `start_time + n*timestep`; schedule boundaries and an off-grid `end_time` are excluded from result timestamps. Optimization may explicitly request boundary probes without changing the result-view contract.
- Server runtime/package/cache-buster/Viewer/animation-export version: 2.11.1. Client runtime/protocol remains 0.3.9; integrated VZ runtime/protocol remains 0.3.2.1.

## V2.11.0 unified data / VZ model-library / control-canvas release

- Server data root resolves to a detected `V2_projec`: default Server-up-two-level lookup, administrator-adjustable ancestor level, or manual parent/direct `V2_projec` path. Probe requires the folder to exist and be writable; saved changes apply on restart. `MUJOCO_STUDIO_DATA` remains the explicit environment override.
- Integrated VZ uses `<DATA_ROOT>/vz`; new empty stores contain no demo model. Legacy VZ roots are only migration candidates when the target has no models.
- Hub → VZ publish reconciles stale/changed/missing mesh assets on every push, including existing VZ models, then overwrites modeling exchange and verifies all mesh references relink. Existing VZ scene coordinates/render scene/presets/memories are preserved.
- Engineer model library adds two-level folder create/rename/delete and model drag classification. Models add optional `scene_coordinates.hard_point_mm` and `h_point_mm`.
- User control order is a persistent native DOM/SVG directed-graph canvas with categorized right model library, front-view previews, node drag/resize, connection/bend, selection/Delete, lasso/group move, pan/zoom, explicit auto-layout and DAG rejection. Existing single-model action details remain available in the drawer and the animation/viewer pane is retained.
- Alignment for a later graph model is translation-only: hard point first, H point fallback. One point does not determine 3-D rotation, so no synthetic rotation is stored in V2.11.0.
- New main ProjectSpec/L1/L2/L3/Session/Job fields: 0. New main business Tool: 0. New deployment APIs: storage-location GET/probe/PUT. New VZ application APIs: model-library folder/move and control-graph GET/PUT.

## V2.10.6.1 diagram closure shared-site coordinate patch

- The single coordinate field shown for a selected dashed closure/site edge is relabeled “闭链坐标”.
- A valid edit writes the same mm vector into both existing `endpoint_a.point_mm` and `endpoint_b.point_mm` using independent list copies.
- The existing XML generator continues to create both closure sites; synchronized ProjectSpec values therefore produce matching site `pos` values without a new backend schema or sync service.
- Root/hierarchy advanced closure properties retain independent endpoint A/B editing.
- New authoritative ProjectSpec/L1/L2/L3/Session/Job fields: 0. New business Tool/API/Job/artifact/tool-directory: 0. Server current version is 2.10.6.1; Client remains 0.3.9; Viewer bundle schema/controller signature remain 4.

## V2.10.5 manual-layout / closure-drive semantics patch

- Dragging a mesh from the library to the canvas names the new layer from the mesh basename; duplicate names reuse the current unique-name helper.
- A manual parent link that would form a hierarchy cycle is converted to the existing dashed kinematic-closure/site representation.
- Entering diagram mode does not auto-arrange. Saved manual node geometry remains authoritative, and ephemeral edits inherit the source project's `core/ui_state.json` before Kernel construction.
- New joints created from selected tree edges default to `parent——>child` names.
- Closure passive joints are automatically derived from the closure tree path after excluding every line that carries any drive binding. Manual correction clicks path lines. Drive-bound lines render a 36px Figure-1 marker; translation markers use Figure 2.
- Closure colors exclude red and use saturated green/blue/purple/orange families. Ordinary path edges remain solid; explicit site edges remain dashed.
- The entire selected-node lower property viewport accepts mesh drops; multi-mesh chips are enlarged approximately twofold.
- New authoritative ProjectSpec/L1/L2/L3/Session/Job fields: 0. New business Tool/API/Job/artifact/tool-directory: 0. Server current version is 2.10.5; Client remains 0.3.9; Viewer bundle schema/controller signature remain 4.

## V2.10.4 diagram Delete + left-button lasso density patch

- Removes the top “＋ 层级” button; diagram layer creation continues through the existing mesh-library drag path.
- Delete on a selected diagram node reuses the existing layer-removal semantics. Delete on a tree edge detaches the child to root; Delete on a closure edge removes that closure. Text-editing controls keep normal Delete behavior.
- Lasso selection is left-button drag on blank canvas only; node/edge controls retain priority, middle-button pan remains, right-click is no longer intercepted, and a transient click-suppression fence preserves the selection after pointerup.
- Multiple meshes in a selected layer are shown directly expanded in the lower “数模 / 本体” property area. Diagram title labels are 13px.
- Edge-property title rows are about one-third shorter (27px → 18px) with bolder labels; undo feedback toast lifetime is reduced by one-quarter (4800ms → 3600ms).
- New authoritative ProjectSpec/L1/L2/L3/Session/Job fields: 0. New business Tool/API/Job/artifact/tool-directory: 0. The only new state is runtime-only `hierarchyDiagramSuppressPaneClick`.
- Server current version is 2.10.4. Client remains 0.3.9; Viewer bundle schema/controller signature remain 4.

## V2.10.3 diagram refinement + delivery type reconciliation

- Corrects the packaged rotation/translation joint glyph mapping. Thumbnail width/height are independently resizable, previews fill the node border, and titles use the larger 11px floating label.
- Adds right-button rectangle multi-selection/group move, removes the hidden top-left node-coordinate clamp, and persists draggable property/library splitter proportions only in UI state.
- Closure cycles use vivid colors; hierarchy tree segments stay solid while only the explicit closure/site edge is dashed.
- Mesh-library drag can append meshes to the selected layer through its compact lower property panel.
- `ui.set` writes are serialized in invocation order and guarded by a runtime revision/ack mirror fence to remove the medium-cadence hierarchy/diagram toggle rollback.
- Managed delivery is reconciled by type, not filename. The fifth class `axes_csv_folder` is a directory containing separately exported coordinate-system CSV files and replaces the prior same-type folder atomically.
- New authoritative ProjectSpec/L1/L2/L3/Session/Job fields: 0. New business Tool/Job/tool-directory: 0. New persisted field is UI-only `ui.model.diagram.layout`. Existing CSV and delivery ZIP routes are extended instead of adding a parallel export API.
- Server current version is 2.10.3. Client remains 0.3.9; Viewer bundle schema/controller signature remain 4.

## V2.10.2 Hub critical-data + lightweight diagram interaction

- Baseline-derived projects with no local archive now receive current authoritative `critical_data` during full Hub catalog hydration; the first Editor entry/check-in is no longer a prerequisite for key-data bubbles.
- Diagram properties are compact and selection-specific: blank by default, node-only name/color/active/collapsed body-mesh controls, edge-only joint controls plus closure toggle.
- Thumbnail-first nodes expose four ports. Adaptive cubic Bezier links support direct bend dragging, middle-mouse pan and Ctrl+wheel cursor-centered zoom.
- Joint type uses packaged icon glyphs; closure paths derive same-color dashed loops without adding model fields or a second closure graph.
- New persistent ProjectSpec/L1/L2/L3/Session/Job fields: 0. New business Tool/API/Job/artifact/tool-directory: 0. The only new persisted state is UI-only `ui.model.diagram.viewport`.
- That release used Server 2.10.2. Client remained 0.3.9; Viewer bundle schema/controller signature remained 4.

## V2.10.1 hierarchy diagram lock/layout patch

- Completes inactive-layer diagram locking for rename/body-preview/mesh-drop paths plus incident edge bending and tree-edge closure toggles.
- Canvas closure-joint picking is restricted to active non-crank joints and validates the joint owner again before mutating `solve_joint_ids`; endpoint choices share the same active-layer eligibility.
- Auto-arrange uses actual node sizes, per-depth maximum widths and recursive subtree heights instead of fixed 286/184 spacing, preventing overlaps after nodes are resized.
- New persistent ProjectSpec/L1/L2/L3/Session/Job fields: 0. New business Tool/API/Job/artifact/tool-directory: 0.
- That release used Server 2.10.1. Client remained 0.3.9; Viewer bundle schema/controller signature remained 4.

## V2.10.0 hierarchy diagram modeling

- Adds tree/diagram dual projection for the same hierarchy, joints and kinematic closures; no parallel model graph is persisted.
- Diagram UI geometry, body-mesh preview choice and edge bend offsets persist only under existing `ui.model.*` through `ui.set`.
- Supports node move/resize/rename, front-view body preview, model-library drag-to-create, parent links, closure links, edge bending, canvas passive-joint selection and inactive-node locking.
- New persistent ProjectSpec/L1/L2/L3/Job fields: 0. New business Tool/API/Job/artifact/tool-directory: 0.
- That release used Server 2.10.0. Client remained 0.3.9; Viewer bundle schema/controller signature remained 4.

## V2.9.8 VZ Studio integration

- Integrates VZ Studio V0.3.2.1 with MuJoCoHub as the model publishing source.
- Adds “工程师界面” at the Hub top bar and “推送模型” in model properties.
- Integrated VZ engineer UI removes hierarchy modeling and redundant modeling/import/export controls; drive settings become the main workspace.
- Model rename preserves the original Hub name; high-quality render `perfect_max_faces_per_mesh` defaults to `120000`.
- That integration release used Server 2.9.8. Client remained 0.3.9; Viewer bundle schema/controller signature remained 4.

## V2.9.7.1 recycle / check-in archive / forward-label patch

- Recycle-bin UI adds transient checkbox multi-selection, current-filter select-all, selected count, and irreversible selected deletion.
- `DELETE /api/recycle-bin/{trash_id}` permanently removes one valid listed recycle entry for engineer/admin roles; malformed/damaged entries fail closed.
- Every `check_in` is archived through the existing lifecycle + Kernel archive path. Manual UI asks only for the optional archive log after the existing check-in/close confirmation; it no longer asks whether to archive.
- Top redo control is displayed as `前进`; internal redo API/keyboard semantics are unchanged.
- This patch's Server version was 2.9.7.1. Client remained 0.3.9; Viewer bundle schema/controller signature remained 4.
- New persistent ProjectSpec/L1/L2/L3/Job fields: 0. New business Tool/Job/artifact/tool-directory: 0. New API method: 1.

## V2.9.7 Hub / complete bundle / hierarchy modeling / integrated delivery

- Hub model-type folders default to collapsed on first load; the project-list heading includes a single collapse/expand-all control using the same in-memory collapse set. Search becomes catalog-wide whenever text is present and includes category paths.
- JSON import now carries the current Hub category. New complete ZIP export/import carries canonical model JSON, model assets, delivery data and applicable archive logs with path-safe extraction and SHA-256 inventory verification.
- Checked-in public assets are exported from an isolated verified save-as snapshot and never modified in place. Import always creates a new conflict-free public `@model_assets/<category>/<folder>` target, including the root `None` category.
- Baseline bundle import restores the immutable private mesh snapshot/delivery to the baseline and injects a separate public asset copy for the generated working model. Baseline itself retains no ordinary archive property.
- Layer-modeling mesh and drive columns reset to two columns on every Editor entry; joint range fields are conditional on `limited`; reverse vectors visibly show negated components without double-negating stored axes; Model A/B placeholder is replaced by “全部数模自适应”.
- New persistent ProjectSpec/L1/L2/L3/Job fields: 0. New business Tool/Job/artifact/tool-directory: 0. New domain helper: `domain/project_bundle.py`; new API methods: 2.
- Formal integrated package contains both Server 2.9.7 and audited Client runtime 0.3.9; Viewer bundle schema/controller signature remain unchanged.

## Retained V2.9.6.6 Windows Viewer path / Hub drag responsiveness

- Reuses the existing `viewer_runner.py` Unicode/VFS model loader for generated XML in simulation, optimization, validation and legacy animation paths; direct generated-XML `MjModel.from_xml_path(absolute_path)` call sites are removed.
- Local Viewer command arguments are workspace-relative whenever possible, with `cwd` fixed to the Viewer output directory and a cross-volume absolute fallback. Remote Client semantics remain bundle-based and never depend on direct access to a Linux server filesystem.
- Reuses `ProjectStore.move_delivery_tree()`: same-filesystem model reclassification now attempts atomic directory rename first; the existing verified recursive copy/hash implementation remains the compatibility fallback.
- Hub reclassification uses optimistic local category/name/count projection with rollback, then merges the server-returned authoritative ProjectSpec. Model-name save no longer blocks on a full project-list + preview refetch.
- New persistent fields: 0. New business Tool/API/Job/artifact/tool-directory: 0.

## V2.9.6.5 expression / custom-variable hygiene

- Fixes false `unknown variable: tran` failures for arithmetic expressions like `40/tran*tz`; `/` is treated as division for plain identifiers while full slash-qualified drive aliases remain supported.
- Central `ProjectSpec` normalization removes custom-variable entries whose trimmed name equals a distance-pair name.
- V21.5 complete-model import and modeling-exchange import perform the same cleanup explicitly, including when measurements themselves are not imported.
- New persistent ProjectSpec/L1/L2/L3/Job fields: 0. New business Tool/API/Job/artifact/tool-directory: 0.
- Permanent self-check coverage includes both the evaluator regression and the distance-pair-variable invariant.

## V2.9.6.4 external CSV / V21.5 model JSON interoperability

- Reuses `DriveSegmentSpec.points`, the existing schedule/runtime paths, project update lifecycle, and complete-model JSON adapters; no parallel motion state or business Tool directory is introduced.
- Adds `POST /api/projects/{project_id}/external-motion-csv` for editable projects. The server parses V21.5-compatible position/velocity/acceleration CSV data and embeds the resulting time/position points in the model.
- External CSV runtime and exported project JSON prefer the embedded point table. Machine-local CSV paths are not required after import; legacy path-only projects are read only as a compatibility fallback.
- V21.5 complete-model conversion now treats `external_csv` as a supported profile in both directions. V2 → V21.5 emits `external_csv_values`; V21.5 → V2 imports them into `segment.points` without degrading to `s_curve`.
- New persistent provenance fields: `external_csv_name`, `external_csv_header`, `external_csv_source_metric`. New business Tool/Job/artifact/tool-directory: 0. New API method: 1.


## V2.9.6.2 rapid-edit race hotfix

- Background event/state convergence uses a project/revision/dirty fence before applying an authoritative mirror; late snapshots cannot roll back newer local edits.
- Existing 400 ms debounce and serial save chain are retained.
- Direct persistent add actions all schedule interaction commits.

## V2.9.6.1 Viewer Gantt hotfix

- Remote Client Viewer bundle includes the authoritative Web Gantt PNG/JSON snapshot and verifies hashes before launch.
- Viewer controller signature 4 receives `gantt_cache_path`; Client V0.3.9 is the minimum launch client for this release.
- Native Viewer dynamically switches from fallback to authoritative cache and watches both PNG and JSON file signatures.

## V2.9.6 retained behavior

- Manual check-in carries a transient `archive` choice. `archive=false` signs in without writing a history snapshot; `archive=true` writes one `存档版本`. Automatic check-in and admin force-check-in continue to archive for recovery safety.
- Check-out no longer writes a lifecycle history snapshot. New history writes project only as `archive` or `baseline`; legacy reasons remain readable but normalize to the `存档版本` label.
- Baseline creation keeps the independent frozen baseline project and appends exactly one `基线版本` snapshot/marker to the source model history, including the baseline project id/name and log. The source ProjectSpec is not rewritten and no extra ordinary archive is created.
- Source history uses the existing default total limit of 20 entries. Baseline and archive entries participate in the same keep-last-N pruning path.
- `DELETE /api/projects/{project_id}/versions/{version_id}` deletes one snapshot + metadata sidecar only. Deleting a baseline history marker does not delete its standalone baseline model.
- Hub archive cards render baseline labels in red and place `删除存档` immediately before `切出为独立模型`.
- Added ProjectSpec/L1/L2/L3/Job authoritative fields: 0. Added business Tool/Job/artifact/tool-directory: 0. Added API method: 1 (`DELETE` on the existing versions resource).

## V2.9.5.2 retained behavior

- Desktop Hub renders `hubTopControls` inside the same `.sidebar` top row as MuJoCoHub; it no longer allocates a standalone Hub control row in `<main>`. Narrow layouts may wrap responsively.
- Hub-only chrome uses restrained Unity-editor-inspired compact styling: flatter 2–3px radii, subtle toolbar/pane gradients, and no hover lift/scale. No external UI dependency is added.
- Model-property action labels are shortened to `复制` and `删除`; existing copy/delete handlers, permissions and lifecycle semantics are unchanged.
- No ProjectSpec/L1/L2/L3 authoritative field, business Tool/API/Job/artifact type, or tool directory was added in V2.9.5.2. Its old browser-local Webhook layout/state clause is superseded by V2.11.6; account controls remain on the Hub title row.

## V2.9.5.1 retained behavior

- All user-side downloads/exports use the browser default download flow on both Windows and Linux; frontend save-file/save-directory pickers are not used. Server administrative directory binding remains a separate operation.
- Checked-out models use `📩🧑‍💻` in Hub and Editor labels; the model-page Hub jump button is removed.
- Delivery inspector suffix input and three actions occupy separate rows; delivery rows show the suggested large filename with saved time only as secondary text. Asset action buttons are 2px smaller, the bind button doubles in width, recycle bin is pinned to the bottom of the project-list rail, and archive cards lead with enlarged key-data content.
- Historical V2.9.5.1 behavior introduced the Hub WeCom slider/local URL. V2.11.6 explicitly supersedes that clause: the control/local setting is removed and baseline notification is sealed.
- `copy-version` reuses the source public `@model_assets` reference and does not clone a new asset folder. Baseline `/fork` retains the existing explicit folder-name prompt and `_clone_mesh_to_shared_pool()` behavior.
- Animation reload reads delivery HTML and reports success without referencing the removed/undefined `deliveryOnly` variable.
- No ProjectSpec/L1/L2/L3 authoritative field, business Tool/API/Job/artifact type, or tool directory was added in that release. Its former `wecomWebhookEnabled` browser state is removed by V2.11.6.

## V2.9.5 retained behavior

- Ordinary project archive retention defaults to 20 total versions. Manual archives and lifecycle check-in/check-out versions share the same hard cap and pruning path.
- Baseline creation does not compact the source project to three archives; baseline projects remain frozen snapshots without their own ordinary archive list.
- Hub property inspection is compacted without adding state: desktop inspector width is capped near 150% of the model-property column; delivery quick cards are removed; asset version/file rows are compressed; archive logs are visually clamped to two lines.
- No ProjectSpec/L1/L2/L3 authoritative field, business Tool/API/Job/artifact type, or tool directory was added.

## V2.9.4 retained behavior

- On Linux-deployed Server pages, user export flows use direct browser downloads and do not request local file/directory paths. Server-side administrative bindings remain separate from download destination choice.
- Coordinate-system batch CSV offers separate-per-coordinate-system files or one combined CSV.
- NX AFU and animation HTML generation automatically publish to delivery, remove the previous same-kind managed delivery, and trigger browser download; animation reload reads the delivery artifact only. The four managed delivery kinds remain latest-only.
- User project deletion moves the model (and any externally bound owned delivery payload) into `.trash/projects`; admin and engineer roles can restore for seven days. Restore never overwrites an existing project or delivery target. Internal rollback keeps using hard delete.
- Deleting a model type with its models uses the same recycle path; shared `@model_assets` selections are frozen into each project before the category library is removed, and external delivery binding roots are restorable with conflict checks.
- Copy-version honors an explicit `model_name`; adaptive same-family mesh handling forces opacity 0 only for `.001`-`.009`; adaptive drives use exact joint names and joint bindings.
- No ProjectSpec/L1/L2/L3 authoritative field or business Tool directory was added. Recycle metadata is external lifecycle state; download capability and picker handles are session/UI state only.

## V2.9.3 retained behavior

- Drive schedule resolution keeps the exact unresolved expression cause per segment; undefined symbols are not mislabeled as cycles.
- Preview may expose safely resolved partial canonical drive variables and completed schedule rows from a failed resolution, while validation/XML/simulation remain fail-closed.
- No ProjectSpec/L1/L2/L3 field, business Tool, API, Job, artifact type, or tool directory was added. Existing `resolve_schedule`, `project.validate`, `motion.compute_schedule`, XML and simulation paths remain the single implementation path.

## V2.9.2.1 retained behavior

- `None/未分类` is never exposed as a model-type node; legacy `projects/未分类` is normalized into the internal uncategorized storage when conflict-free.
- Model-type controls are left-aligned as drag handle then fold/unfold. Drag supports both sibling ordering and hierarchy moves through the existing move API, with confirmation and page reload.
- Successful Editor check-in immediately invalidates/refetches Hub lifecycle state across same-origin windows, so Hub does not remain visually checked out.

## V2.9.2 retained behavior (folder-drag rule superseded by V2.9.2.1)

- Hub left rail is “项目列表”, 20% wider; internal `None` is hidden and represented by the root project folder, which lists uncategorized models only.
- V2.9.2 originally placed fold/drag controls at the right and limited drag to same-parent reorder; V2.9.2.1 supersedes that interaction while retaining confirmation-before-write and reload-after-success.
- Project reclassification uses the target folder leaf as a prefix; baseline names use `<model>_00i` without dates.
- Unsupported/failed `showSaveFilePicker()` calls fall back to a standard browser download.
- Checked-in temporary Editor mode has a gray visual mask; mesh and drive layouts default to two columns.

## V2.9.1 retained behavior

- Hub critical-data text mirrors the Web Gantt metric formatter (two decimals, integer `.00` suppressed).
- Layer mesh rows expose only the overall adaptation action; no per-mesh adaptation button is shipped.
- Animation result iframe supports fullscreen; exported HTML distance UI keeps only select-all and under-25mm filters, with reduced panel typography.
- Derived drive variables are exposed as slash/lowercase names such as `drive/starttime1`; historical aliases are evaluation-only compatibility.

## Formal ZIP cleanliness contract

The formal delivery ZIP intentionally excludes versioned historical documents, tests/test reports,
cache/bytecode, temporary artifacts and nested source/release archives. The sole history exception is
one consolidated root `CHANGELOG.md`; detailed development history and test assets remain outside the production ZIP.

`V2_projec/` has an additional permanent whitelist: only `scenes/default_scene.xml` may be pre-shipped.
See `architecture_master_prompt.md` for the mandatory delivery and Linux cleanliness gates.

## V2.10.6.1 diagram icon hotfix

- Replaced the temporary drive-on-edge icon fallback: drive badges now use a dedicated `diagram_joint_drive.png` asset provided by the user, while sliding joints use the updated `diagram_joint_translation.png` asset.
- No new ProjectSpec field, API, Job, or business artifact is introduced.

## V2.11.2 secondary review hardening

- Native Viewer result-chart sampling now follows the configured simulation timestep through an integer-tick strict grid; fixed 241-point linspace sampling is prohibited. Single-point derivative views return zero rather than raising from `numpy.gradient`.
- VZ GET parsing is single-source inside `do_GET`; modeling-info export with query parameters no longer references an uninitialized `parsed` variable.
- Active VZ quick-render documentation matches the 120000 faces-per-mesh default.
- Architecture Section 70 records the low-risk review discipline: independent spec/standards axes, red/green-capable feedback loops, seam/interface test surfaces, deep-module locality, YAGNI and vertical-slice fixes.
- Added ProjectSpec/L1/L2/L3/Session/Job fields: 0. Added business Tool/API/Job/artifact: 0. Server is 2.11.2; Client remains 0.3.9; VZ runtime/protocol remains 0.3.2.1.