from __future__ import annotations

import atexit
import os
import subprocess
import sys
import urllib.request
import webbrowser
from pathlib import Path
from threading import Timer


ROOT = Path(__file__).resolve().parent
VZ_ROOT = ROOT / "integrations" / "VZ_Studio_V0.3.2.1"
sys.path.insert(0, str(ROOT / "backend"))

from app.config import DATA_ROOT  # noqa: E402


def configure_runtime() -> tuple[str, int]:
    """Configure one server shape for host and remote browser clients alike."""
    os.environ["MUJOCO_STUDIO_SINGLE_USER"] = "0"
    os.environ["MUJOCO_STUDIO_DESKTOP"] = "0"
    host = os.getenv("MUJOCO_STUDIO_HOST", "0.0.0.0")
    port = int(os.getenv("MUJOCO_STUDIO_PORT", "8765"))
    return host, port


def start_integrated_vz() -> subprocess.Popen | None:
    if os.getenv("MUJOCO_STUDIO_VZ_ENABLED", "1").lower() in {"0", "false", "no", "off"}:
        print("集成 VZ 服务已禁用（MUJOCO_STUDIO_VZ_ENABLED=0）")
        return None
    if not (VZ_ROOT / "run.py").is_file():
        print(f"警告：未找到集成 VZ 0.3.2.1：{VZ_ROOT}")
        return None
    vz_port = int(os.getenv("VZ_PORT", "8877"))
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{vz_port}/api/health", timeout=0.5) as response:
            if response.status == 200:
                print(f"检测到端口 {vz_port} 已有 VZ 服务，直接复用。")
                return None
    except Exception:
        pass
    env = os.environ.copy()
    env.setdefault("VZ_HOST", "0.0.0.0")
    env["VZ_PORT"] = str(vz_port)
    env["VZ_NO_BROWSER"] = "1"
    env["VZ_SKIP_DEPENDENCY_INSTALL"] = "1"
    env["VZ_PROJECT_ROOT"] = str((DATA_ROOT / "vz").resolve())
    process = subprocess.Popen([sys.executable, str(VZ_ROOT / "run.py")], cwd=str(VZ_ROOT), env=env)
    print(f"已启动集成 VZ 0.3.2.1：工程师 http://127.0.0.1:{vz_port}/engineer · 用户 http://127.0.0.1:{vz_port}/client")

    def stop_vz() -> None:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
    atexit.register(stop_vz)
    return process


def main() -> None:
    if sys.version_info < (3, 10):
        raise SystemExit(
            "MuJoCo Studio requires Python 3.10 or newer. "
            f"Detected Python {sys.version_info.major}.{sys.version_info.minor}. "
            "Create a Python 3.10+ environment, then run: python -m pip install -r requirements.txt"
        )
    import uvicorn
    host, port = configure_runtime()
    start_integrated_vz()
    if os.getenv("MUJOCO_STUDIO_NO_BROWSER", "").lower() not in {"1", "true", "yes"}:
        browser_host = "127.0.0.1" if host in {"0.0.0.0", "::"} else host
        Timer(1.2, lambda: webbrowser.open(f"http://{browser_host}:{port}")).start()
    uvicorn.run("app.main:app", host=host, port=port, app_dir=str(ROOT / "backend"), reload=False)


if __name__ == "__main__":
    main()
