from __future__ import annotations
import math

import compileall
import hashlib
import json
import sys
import tempfile
import time
import zipfile
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

from app.config import DATA_ROOT, ORPHAN_WORKSPACE_TTL_HOURS  # noqa: E402
from app.storage_config import default_ancestor_levels
from app.domain.models import DistancePairSpec, DriveSegmentSpec, DriveSpec, JointSpec, LayerSpec, MeshSpec, ProjectSpec, SimulationSettings  # noqa: E402
from app.auth import Identity, reset_active_identity, set_active_identity  # noqa: E402
from app.core.kernel import Kernel  # noqa: E402
from app.domain.project_store import ProjectStore  # noqa: E402
from app.domain.project_bundle import (  # noqa: E402
    BUNDLE_FORMAT, BUNDLE_FORMAT_VERSION, MANIFEST_NAME, ProjectBundleError,
    copy_tree_snapshot, extract_bundle_zip, load_manifest, tree_inventory,
    verify_manifest_inventory, write_bundle_zip,
)
from app.domain.motion import resolve_schedule  # noqa: E402
from app.domain.mass_properties import resolve_mass_properties  # noqa: E402
from app.domain.migration import migrate_legacy_project  # noqa: E402
from app.domain.modeling_exchange import import_modeling_exchange  # noqa: E402
from app.domain.simulation import _apply_dynamic_self_lock, build_time_grid, load_generated_mujoco_model, run_analytical_simulation  # noqa: E402
from app.domain.viewer_runner import (  # noqa: E402
    _enforce_viewer_kinematic_closure, _strict_result_time_grid,
    _viewer_apply_mapping_overrides, _viewer_mapping_topology, _viewer_root_mapping_source,
)
from app.domain.kinematic_closure import (  # noqa: E402
    ClosureConstraintRuntime, ClosureEndpointRuntime, ClosureJointRuntime, ClosureRuntime,
    solve_kinematic_closure,
)
from app.domain.validation import has_errors, validate_project  # noqa: E402
from app.domain.viewer_launcher import viewer_command  # noqa: E402
from app.domain.client_bundle import _optional_gantt_snapshot  # noqa: E402
from app.domain.xml_generator import generate_project  # noqa: E402




def _check_optional_gantt_contract() -> bool:
    """Gantt cache is auxiliary: missing/partial/invalid data must not block Viewer."""
    with tempfile.TemporaryDirectory(prefix="mujoco_studio_gantt_optional_") as temporary:
        root = Path(temporary)
        snapshot, manifest = _optional_gantt_snapshot(root)
        if snapshot or manifest.get("included") is not False or manifest.get("reason") != "not_generated":
            return False
        (root / "latest_gantt.png").write_bytes(b"partial")
        snapshot, manifest = _optional_gantt_snapshot(root)
        if snapshot or manifest.get("reason") != "cache_incomplete":
            return False
        (root / "latest_gantt.json").write_text("{bad", encoding="utf-8")
        snapshot, manifest = _optional_gantt_snapshot(root)
        if snapshot or manifest.get("reason") != "cache_invalid":
            return False
        (root / "latest_gantt.png").write_bytes(b"\x89PNG\r\n\x1a\nvalid-ish")
        (root / "latest_gantt.json").write_text(
            json.dumps({"format": "MUJOCO_STUDIO_GANTT_CACHE", "saved_at": "self-check"}),
            encoding="utf-8",
        )
        snapshot, manifest = _optional_gantt_snapshot(root)
        return bool(
            manifest.get("included") is True
            and len(snapshot) == 2
            and manifest.get("png_sha256")
            and manifest.get("json_sha256")
        )

def _check_viewer_mapping_family_contract() -> bool:
    """Exercise the production mapping-family helpers for bidirectional manual control."""
    drives = [
        {"id": "source", "joint_id": "", "name": "Source"},
        {"id": "follower", "joint_id": "joint_follower", "name": "Follower"},
    ]
    drive_by_id = {str(item["id"]): item for item in drives}
    drives_by_joint = {"joint_follower": ["follower"]}
    mapping_segments = {
        "follower": {
            "drive_id": "follower", "profile": "mapping",
            "mapping_source_joint_id": "drive:source",
            "joint_id": "joint_follower", "points": [[0.0, 0.0], [100.0, 50.0]],
        },
    }
    roots, families = _viewer_mapping_topology(
        mapping_segments, drive_by_id, drives_by_joint,
    )
    if roots != {"source": "source", "follower": "source"}:
        return False
    expected_family = frozenset({"source", "follower"})
    if families.get("source") != expected_family or families.get("follower") != expected_family:
        return False

    # First source drag: the whole family becomes manual, so the physical follower
    # joint is eligible for qpos override even though the source is virtual.
    decoupled = set(families["source"])
    manual_values = {"source": 60.0, "follower": 0.0}
    contributions = {"source": 0.0, "follower": 0.0}
    for root_id in {roots.get(drive_id, drive_id) for drive_id in decoupled}:
        contributions[root_id] = manual_values[root_id]
    contributions = _viewer_apply_mapping_overrides(
        contributions, mapping_segments, drive_by_id, drives_by_joint,
    )
    physical_writes = {
        drive_id for drive_id in decoupled if str(drive_by_id[drive_id].get("joint_id", ""))
    }
    if abs(float(contributions["source"]) - 60.0) > 1e-12:
        return False
    if abs(float(contributions["follower"]) - 30.0) > 1e-12:
        return False
    if physical_writes != {"follower"}:
        return False

    # Follower drag: inverse-map to source=80, then forward-project back to follower=40.
    root_id, source_value = _viewer_root_mapping_source(
        "follower", mapping_segments, drive_by_id, drives_by_joint,
        target_value=40.0, current_values=contributions,
    )
    if root_id != "source" or source_value is None or abs(float(source_value) - 80.0) > 1e-12:
        return False
    contributions["source"] = float(source_value)
    contributions = _viewer_apply_mapping_overrides(
        contributions, mapping_segments, drive_by_id, drives_by_joint,
    )
    return abs(float(contributions["follower"]) - 40.0) <= 1e-12


def _check_viewer_kinematic_closure_contract() -> bool:
    """Exercise the real DLS solver plus the Viewer fail-closed/warm-start seam."""
    class Model:
        nv = 2

    class Data:
        def __init__(self, q0: float = 0.2, q1: float = 0.0) -> None:
            self.qpos = np.array([q0, q1], dtype=float)
            self.site_xpos = np.zeros((2, 3), dtype=float)

    class Mujoco:
        @staticmethod
        def mj_kinematics(_model, data) -> None:
            # Simple closed-chain residual: q_drive + q_passive == 0.
            data.site_xpos[0] = [float(data.qpos[0] + data.qpos[1]), 0.0, 0.0]
            data.site_xpos[1] = [0.0, 0.0, 0.0]

        @staticmethod
        def mj_comPos(_model, _data) -> None:
            return None

        @staticmethod
        def mj_jacSite(_model, _data, jac, _jacr, site_id: int) -> None:
            jac[:] = 0.0
            if int(site_id) == 0:
                jac[0, 0] = 1.0
                jac[0, 1] = 1.0

    runtime = ClosureRuntime(
        constraints=[ClosureConstraintRuntime(
            closure_id="closure", name="closure",
            endpoint_a=ClosureEndpointRuntime(0, -1, (0.0, 0.0, 0.0)),
            endpoint_b=ClosureEndpointRuntime(1, -1, (0.0, 0.0, 0.0)),
            solve_joint_ids=("passive",), tolerance_mm=1e-6, max_iterations=20,
            damping=1e-6, max_angle_step_deg=30.0, max_slide_step_mm=500.0,
        )],
        joints={"passive": ClosureJointRuntime(
            "passive", "passive", 1, 1, 1, "translation", False, -1.0, 1.0,
        )},
    )
    model = Model()
    data = Data()
    solved = solve_kinematic_closure(
        Mujoco, model, data, runtime,
        driven_joint_ids={"drive"}, previous_qpos=None, kinematics_only=True,
    )
    if not solved.converged or abs(float(data.qpos[1]) + 0.2) > 1e-9:
        return False

    calls: list[np.ndarray | None] = []

    class Outcome:
        def __init__(self, converged: bool, residual_mm: float = 0.0, reason: str = "") -> None:
            self.converged = converged
            self.residual_mm = residual_mm
            self.reason = reason

    def policy_solver(_mj, _model, state, _runtime, *, driven_joint_ids, previous_qpos, kinematics_only):
        if driven_joint_ids != {"drive"} or not kinematics_only:
            return Outcome(False, 999.0, "policy_contract")
        calls.append(None if previous_qpos is None else np.asarray(previous_qpos, dtype=float).copy())
        state.qpos[1] = -float(state.qpos[0])
        return Outcome(True)

    previous = np.array([0.1, -0.1], dtype=float)
    data = Data(0.3, 0.0)
    saved, saved_time, suffix = _enforce_viewer_kinematic_closure(
        Mujoco, model, data, runtime, policy_solver,
        driven_joint_ids={"drive"}, previous_qpos=previous,
        previous_time_s=0.99, time_s=1.0, timestep=0.01,
    )
    if suffix or saved_time != 1.0 or not np.allclose(data.qpos, [0.3, -0.3]):
        return False
    if not calls or calls[-1] is None or not np.allclose(calls[-1], previous):
        return False

    # A large timeline jump must not warm-start the passive joints from another time.
    data = Data(0.4, 0.0)
    _enforce_viewer_kinematic_closure(
        Mujoco, model, data, runtime, policy_solver,
        driven_joint_ids={"drive"}, previous_qpos=saved,
        previous_time_s=saved_time, time_s=1.2, timestep=0.01,
    )
    if calls[-1] is not None:
        return False

    def failing_solver(_mj, _model, state, _runtime, *, driven_joint_ids, previous_qpos, kinematics_only):
        state.qpos[:] = [9.0, 9.0]
        return Outcome(False, 2.5, "unreachable")

    data = Data(0.5, 0.0)
    held, held_time, suffix = _enforce_viewer_kinematic_closure(
        Mujoco, model, data, runtime, failing_solver,
        driven_joint_ids={"drive"}, previous_qpos=saved,
        previous_time_s=saved_time, time_s=1.01, timestep=0.01,
    )
    if not np.allclose(data.qpos, saved) or held_time != saved_time or "保持上一有效姿态" not in suffix:
        return False
    return held is saved



def _check_hub_v2116_contract() -> bool:
    """Exercise recursive folder counts and newest ordinary archive-log selection."""
    with tempfile.TemporaryDirectory(prefix="mujoco_studio_hub_v2116_") as temporary:
        store = ProjectStore(Path(temporary))
        specs = [
            ("hub_direct", "机械", "checked_in", ""),
            ("hub_child", "机械/执行器", "checked_out", ""),
            ("hub_baseline", "机械/执行器", "baseline", "2026-09-09T12:00:00+00:00"),
            ("hub_deep", "机械/执行器/深层", "checked_in", ""),
        ]
        for project_id, category, status, frozen_at in specs:
            project = ProjectSpec.demo()
            project.id = project_id
            project.name = project_id
            project.category = category
            project.lifecycle.status = status
            project.lifecycle.baseline_created_at = frozen_at
            store.create(project)

        flat_counts: dict[str, int] = {}
        stack = list(store.model_type_tree())
        while stack:
            node = stack.pop()
            flat_counts[str(node.get("path", ""))] = int(node.get("count", 0) or 0)
            stack.extend(node.get("children", []))
        if flat_counts.get("机械") != 4 or flat_counts.get("机械/执行器") != 3 or flat_counts.get("机械/执行器/深层") != 1:
            return False
        summary = {str(item.get("id")): item for item in store.list()}
        if summary.get("hub_baseline", {}).get("baseline_created_at") != "2026-09-09T12:00:00+00:00":
            return False

        source = store.get("hub_direct")
        store.archive(source, reason="manual", actor="self-check", log="旧存档日志")
        time.sleep(0.002)
        store.archive(source, reason="check_in", actor="self-check", log="最新签入日志")
        time.sleep(0.002)
        store.archive(
            source, reason="baseline", actor="self-check", log="基线日志",
            baseline_project_id="baseline_marker", baseline_name="Baseline-1",
        )
        versions = store.list_versions(source.id)
        if not versions or versions[0].get("version_kind") != "baseline":
            return False
        latest_archive = next((item for item in versions if item.get("version_kind") == "archive"), None)
        return bool(latest_archive and latest_archive.get("log") == "最新签入日志")

def _check_hub_v2117_contract() -> bool:
    """Exercise baseline naming, duplicate suffixes, and history-name synchronization."""
    with tempfile.TemporaryDirectory(prefix="mujoco_studio_hub_v2117_") as temporary:
        store = ProjectStore(Path(temporary))
        source = ProjectSpec.demo()
        source.id = "hub_name_source"
        source.name = "Alpha"
        source.category = "机械/执行器"
        store.create(source)

        index, first_name = store.next_baseline_identity(source.id, source.name, source.name)
        if index != 1 or first_name != "Alpha_001":
            return False

        baseline = ProjectSpec.demo()
        baseline.id = "hub_name_baseline"
        baseline.name = first_name
        baseline.category = source.category
        baseline.lifecycle.status = "baseline"
        baseline.lifecycle.source_project_id = source.id
        baseline.metadata["baseline_version_index"] = index
        store.create(baseline)

        second_index, second_name = store.next_baseline_identity(source.id, source.name, source.name)
        if second_index != 2 or second_name != "Alpha_002":
            return False
        if store.unique_project_name(source.category, "Release") != "Release":
            return False

        release = ProjectSpec.demo()
        release.id = "hub_name_release"
        release.name = "Release"
        release.category = source.category
        release.lifecycle.status = "baseline"
        release.lifecycle.source_project_id = source.id
        store.create(release)
        if store.unique_project_name(source.category, "release") != "release_001":
            return False
        long_name = "L" * 160
        long_project = ProjectSpec.demo()
        long_project.id = "hub_name_long"
        long_project.name = long_name
        long_project.category = source.category
        store.create(long_project)
        long_duplicate = store.unique_project_name(source.category, long_name)
        if len(long_duplicate) > 160 or not long_duplicate.endswith("_001"):
            return False

        # An editable baseline name that merely looks like a sequence must not jump
        # the authoritative per-source version_index.
        baseline.name = "Alpha_900"
        baseline.metadata["version_index"] = 1
        store.save(baseline)
        stable_index, _ = store.next_baseline_identity(source.id, source.name, "Sequence-Probe")
        if stable_index != 2:
            return False

        store.archive(
            source, reason="baseline", actor="self-check", log="冻结",
            baseline_project_id=baseline.id, baseline_name=baseline.name,
        )
        if not store.rename_baseline_history_reference(source.id, baseline.id, "Release-A"):
            return False
        versions = store.list_versions(source.id)
        marker = next(
            (item for item in versions if item.get("version_kind") == "baseline" and item.get("baseline_project_id") == baseline.id),
            None,
        )
        if not marker or marker.get("baseline_name") != "Release-A":
            return False

        # Frozen baseline invariant: the existing project.replace tool is extended only
        # enough to rename ProjectSpec.name + metadata.baseline_version_label.
        persisted_baseline = store.get(baseline.id)
        persisted_baseline.metadata["baseline_version_label"] = persisted_baseline.name
        store.save(persisted_baseline)
        kernel = Kernel(store.get(baseline.id), store._directory(baseline.id), store.save)
        identity = Identity("baseline-name-self-check", "admin", session_id="baseline-name-self-check", lease_id="baseline-name-self-check-lease")
        identity_token = set_active_identity(identity)
        try:
            renamed = ProjectSpec.model_validate(kernel.project().model_dump())
            renamed.name = "Kernel-Rename"
            renamed.metadata["baseline_version_label"] = renamed.name
            rename_result = kernel.bus.dispatch({
                "tool_id": "project.replace",
                "params": {"project": renamed.model_dump(), "intent": "baseline name self-check"},
                "client": "script",
            })
            if not rename_result.ok or kernel.project().name != "Kernel-Rename":
                return False

            stale_label = ProjectSpec.model_validate(kernel.project().model_dump())
            stale_label.name = "Stale-Label-Should-Fail"
            stale_label_result = kernel.bus.dispatch({
                "tool_id": "project.replace",
                "params": {"project": stale_label.model_dump(), "intent": "stale baseline label self-check"},
                "client": "script",
            })
            if stale_label_result.ok or kernel.project().name != "Kernel-Rename":
                return False

            forbidden = ProjectSpec.model_validate(kernel.project().model_dump())
            forbidden.description = "must stay frozen"
            forbidden_result = kernel.bus.dispatch({
                "tool_id": "project.replace",
                "params": {"project": forbidden.model_dump(), "intent": "forbidden baseline content self-check"},
                "client": "script",
            })
            if forbidden_result.ok or kernel.project().description == "must stay frozen":
                return False
        finally:
            reset_active_identity(identity_token)
        return True


def _temporary_workspace_usage(root: Path) -> tuple[int, int, int]:
    candidates: list[Path] = []
    projects_root = root / "projects"
    if projects_root.is_dir():
        for base in projects_root.rglob("job_workspaces"):
            if base.is_dir() and base.parent.name == "core":
                candidates.extend(path for path in base.iterdir() if path.is_dir() and not path.is_symlink())
        for base in projects_root.rglob("viewer"):
            if base.is_dir() and base.parent.name == "outputs":
                candidates.extend(path for path in base.iterdir() if path.is_dir() and not path.is_symlink())
    edit_root = root / ".edit_sessions"
    if edit_root.is_dir():
        candidates.extend(path for path in edit_root.iterdir() if path.is_dir() and not path.is_symlink())
    total_bytes = 0
    stale = 0
    cutoff = time.time() - ORPHAN_WORKSPACE_TTL_HOURS * 3600.0
    for directory in candidates:
        try:
            if directory.stat().st_mtime < cutoff:
                stale += 1
            total_bytes += sum(
                item.stat().st_size for item in directory.rglob("*")
                if item.is_file() and not item.is_symlink()
            )
        except OSError:
            continue
    return len(candidates), total_bytes, stale




def _check_v21213_storage_and_self_lock_contract() -> bool:
    """Fast regression for V2.12.2 platform defaults and stationary drive brake."""
    if default_ancestor_levels("Linux") != 2:
        return False
    if default_ancestor_levels("Windows") != 4:
        return False
    if default_ancestor_levels("Windows Server 2025") != 4:
        return False
    if default_ancestor_levels("Darwin") != 2:
        return False

    joint = JointSpec(
        id="v21213-joint",
        name="v21213_joint",
        type="translation",
        frictionloss=12.0,
    )
    drive = DriveSpec(
        id="v21213-drive",
        name="v21213_drive",
        joint_id=joint.id,
    )
    if not math.isclose(float(drive.dynamic_lock_force), 2000.0, rel_tol=0.0, abs_tol=1e-12):
        return False

    project = ProjectSpec(
        name="v21213-self-lock-contract",
        solver_mode="dynamic",
        layers=[LayerSpec(id="v21213-layer", name="v21213_layer", joints=[joint])],
        drives=[drive],
    )

    class _LockModel:
        def __init__(self):
            self.dof_frictionloss = np.array([0.0], dtype=float)

    model = _LockModel()
    _apply_dynamic_self_lock(
        model,
        project=project,
        dof_addresses={joint.id: 0},
        positions={joint.id: 0.0},
        next_positions={joint.id: 0.0},
    )
    if not math.isclose(float(model.dof_frictionloss[0]), 2000.0, rel_tol=0.0, abs_tol=1e-12):
        return False

    _apply_dynamic_self_lock(
        model,
        project=project,
        dof_addresses={joint.id: 0},
        positions={joint.id: 0.0},
        next_positions={joint.id: 0.001},
    )
    if not math.isclose(float(model.dof_frictionloss[0]), 12.0, rel_tol=0.0, abs_tol=1e-12):
        return False

    project.drives[0].dynamic_lock_force = 0.0
    _apply_dynamic_self_lock(
        model,
        project=project,
        dof_addresses={joint.id: 0},
        positions={joint.id: 1.0},
        next_positions={joint.id: 1.0},
    )
    if not math.isclose(float(model.dof_frictionloss[0]), 12.0, rel_tol=0.0, abs_tol=1e-12):
        return False

    project.drives.append(
        DriveSpec(
            id="v21213-drive-2",
            name="v21213_drive_2",
            joint_id=joint.id,
            dynamic_lock_force=3500.0,
        )
    )
    _apply_dynamic_self_lock(
        model,
        project=project,
        dof_addresses={joint.id: 0},
        positions={joint.id: 1.0},
        next_positions={joint.id: 1.0},
    )
    return math.isclose(float(model.dof_frictionloss[0]), 3500.0, rel_tol=0.0, abs_tol=1e-12)



def _check_v21214_joint_anchor_contract() -> bool:
    """Regression for world-authored hinge points and Layer rigid-body scope."""
    import xml.etree.ElementTree as ET

    cases = [
        (
            [
                LayerSpec(
                    id="v21214-body", name="v21214_body", parent_id="root",
                    position_mm=[100.0, 0.0, 0.0],
                    joints=[JointSpec(
                        id="v21214-hinge", name="v21214_hinge", type="rotation",
                        point="125, 0, 0",
                    )],
                )
            ],
            [0.025, 0.0, 0.0],
        ),
        (
            [
                LayerSpec(
                    id="v21214-parent", name="v21214_parent", parent_id="root",
                    position_mm=[100.0, 0.0, 0.0],
                ),
                LayerSpec(
                    id="v21214-child", name="v21214_child", parent_id="v21214-parent",
                    position_mm=[50.0, 0.0, 0.0],
                    joints=[JointSpec(
                        id="v21214-hinge", name="v21214_hinge", type="rotation",
                        point="160, 0, 0",
                    )],
                ),
            ],
            [0.01, 0.0, 0.0],
        ),
    ]
    for layers, expected in cases:
        project = ProjectSpec(
            name="v21214-anchor-contract",
            solver_mode="dynamic",
            layers=layers,
        )
        with tempfile.TemporaryDirectory(prefix="mujoco_studio_v21214_anchor_") as temporary:
            generated = generate_project(project, Path(temporary), check_files=False)
            xml_root = ET.parse(generated["model"]).getroot()
            joint = next(
                node for node in xml_root.findall(".//joint")
                if node.get("name") == "v21214_hinge"
            )
            actual = [float(value) for value in str(joint.get("pos", "")).split()]
            if len(actual) != 3 or any(
                not math.isclose(actual[index], expected[index], rel_tol=0.0, abs_tol=1e-12)
                for index in range(3)
            ):
                return False

    project = ProjectSpec(
        name="v21214-scope-contract",
        layers=[LayerSpec(
            id="scope-layer", name="scope_layer",
            meshes=[
                # Validation does not need source files when check_files=False.
                # MeshSpec default STL mass remains 0.01 kg.
                __import__("app.domain.models", fromlist=["MeshSpec"]).MeshSpec(
                    id="scope-mesh-a", filename="a.stl"
                ),
                __import__("app.domain.models", fromlist=["MeshSpec"]).MeshSpec(
                    id="scope-mesh-b", filename="b.stl"
                ),
            ],
            joints=[JointSpec(id="scope-joint", name="scope_joint", type="rotation")],
        )],
    )
    from app.domain.validation import validate_project
    return any(
        issue.code == "layer_joint_applies_to_all_meshes"
        for issue in validate_project(project, check_files=False)
    )





def _check_v21215_direct_mass_contract() -> bool:
    """Regression: target kg must compile through MJCF mass, not Studio density."""
    import xml.etree.ElementTree as ET

    tetra_obj = (
        "v 0 0 0\n"
        "v 1000 0 0\n"
        "v 0 1000 0\n"
        "v 0 0 1000\n"
        "f 1 3 2\n"
        "f 1 2 4\n"
        "f 1 4 3\n"
        "f 2 3 4\n"
    )

    with tempfile.TemporaryDirectory(prefix="mujoco_studio_v21215_mass_") as temporary:
        temporary = Path(temporary)
        mesh_root = temporary / "meshes"
        mesh_root.mkdir()
        (mesh_root / "explicit.obj").write_text(tetra_obj, encoding="utf-8")
        (mesh_root / "layer.obj").write_text(tetra_obj, encoding="utf-8")
        (mesh_root / "default.obj").write_text(tetra_obj, encoding="utf-8")

        explicit = ProjectSpec(
            name="v21215-explicit-mass",
            mesh_root=str(mesh_root),
            solver_mode="dynamic",
            layers=[LayerSpec(
                id="mass-layer-explicit", name="mass_layer_explicit",
                meshes=[MeshSpec(
                    id="mass-mesh-explicit", filename="explicit.obj", mass_kg=0.01
                )],
            )],
        )
        explicit_props = resolve_mass_properties(explicit)
        explicit_row = explicit_props["meshes"]["mass-mesh-explicit"]
        if explicit_row.get("mass_application") != "direct_mass":
            return False
        if not math.isclose(float(explicit_row["resolved_mass_kg"]), 0.01, rel_tol=0.0, abs_tol=1e-12):
            return False
        explicit_out = temporary / "explicit_out"
        explicit_generated = generate_project(explicit, explicit_out, check_files=True)
        explicit_root = ET.parse(explicit_generated["model"]).getroot()
        explicit_geom = next(
            node for node in explicit_root.findall(".//geom")
            if node.get("type") == "mesh"
        )
        if explicit_geom.get("mass") != "0.01" or explicit_geom.get("density") is not None:
            return False

        layer_target = ProjectSpec(
            name="v21215-layer-mass",
            mesh_root=str(mesh_root),
            solver_mode="dynamic",
            layers=[LayerSpec(
                id="mass-layer-target", name="mass_layer_target", mass_kg=2.5,
                meshes=[MeshSpec(id="mass-mesh-layer", filename="layer.obj")],
            )],
        )
        layer_props = resolve_mass_properties(layer_target)
        layer_row = layer_props["meshes"]["mass-mesh-layer"]
        if layer_row.get("mass_application") != "direct_mass":
            return False
        if not math.isclose(float(layer_row["resolved_mass_kg"]), 2.5, rel_tol=0.0, abs_tol=1e-12):
            return False
        layer_out = temporary / "layer_out"
        layer_generated = generate_project(layer_target, layer_out, check_files=True)
        layer_root = ET.parse(layer_generated["model"]).getroot()
        layer_geom = next(
            node for node in layer_root.findall(".//geom")
            if node.get("type") == "mesh"
        )
        if layer_geom.get("mass") != "2.5" or layer_geom.get("density") is not None:
            return False

        density_default = ProjectSpec(
            name="v21215-default-density",
            mesh_root=str(mesh_root),
            solver_mode="dynamic",
            layers=[LayerSpec(
                id="mass-layer-default", name="mass_layer_default",
                meshes=[MeshSpec(id="mass-mesh-default", filename="default.obj")],
            )],
        )
        density_props = resolve_mass_properties(density_default)
        density_row = density_props["meshes"]["mass-mesh-default"]
        if density_row.get("mass_application") != "density":
            return False
        density_out = temporary / "density_out"
        density_generated = generate_project(density_default, density_out, check_files=True)
        density_root = ET.parse(density_generated["model"]).getroot()
        density_geom = next(
            node for node in density_root.findall(".//geom")
            if node.get("type") == "mesh"
        )
        if density_geom.get("mass") is not None:
            return False
        if density_geom.get("density") != "1000":
            return False

    return True


def main() -> int:
    print("[0/10] Checking V2.12.2 storage/self-lock regression contract...")
    if not _check_v21213_storage_and_self_lock_contract():
        raise RuntimeError("V2.12.2 storage/self-lock regression contract failed")
    if not _check_v21214_joint_anchor_contract():
        raise RuntimeError("V2.12.2 joint-anchor/rigid-body-scope regression contract failed")
    if not _check_v21215_direct_mass_contract():
        raise RuntimeError("V2.12.2 direct-mass regression contract failed")
    print("[1/10] Compiling backend")
    if not compileall.compile_dir(ROOT / "backend", quiet=1):
        return 1
    print("[2/10] Checking expression and variable invariants")
    joint = JointSpec(name="j1", type="translation", axis="1, 0, 0")
    variable_project = ProjectSpec(
        layers=[LayerSpec(name="L1", joints=[joint])],
        distance_pairs=[DistancePairSpec(name="distanceA")],
        variables={"distanceA": "123 + tran", "tran": "0.4782608695652174", "tz": 1},
        drives=[DriveSpec(
            name="xu_ni1", joint_id=joint.id,
            segments=[DriveSegmentSpec(
                name="seg1", mode="speed", speed="40/tran*tz", travel="425.484-300.7688",
                ease_in=False, ease_out=False,
            )],
        )],
    )
    if "distanceA" in variable_project.variables or "tran" not in variable_project.variables:
        return 1
    resolved_variables, _schedule = resolve_schedule(variable_project)
    if abs(resolved_variables.get("xu_ni1/speed1", 0.0) - 83.63636363636364) > 1e-9:
        return 1
    legacy = migrate_legacy_project({
        "root_id": "root", "layers": [], "drives": [],
        "pairs": [{"name": "distanceA", "objects_a": [], "objects_b": []}],
        "custom_variables": [{"name": "distanceA", "value": "9"}, {"name": "tran", "value": "2"}],
    })
    if legacy.variables != {"tran": "2"}:
        return 1
    exchange = import_modeling_exchange({
        "format": "mujoco_modeling_exchange", "schema_version": "2.1",
        "hierarchical_modeling": {"root_id": "root", "layers": []},
        "application_state": {"custom_variables": [{"name": "distanceA", "value": "7"}, {"name": "tran", "value": "3"}]},
        "measurement_configuration": {"pairs": [{"name": "distanceA", "objects_a": [], "objects_b": []}]},
    }, import_measurements=False)
    if exchange.variables != {"tran": "3"}:
        return 1
    print("[3/10] Validating demo")
    project = ProjectSpec.demo()
    issues = validate_project(project)
    if has_errors(issues):
        print(*[item.message for item in issues], sep="\n")
        return 1
    with tempfile.TemporaryDirectory(prefix="mujoco_studio_check_") as temp:
        root = Path(temp)
        print("[4/10] Generating MuJoCo artifacts")
        variable_artifacts = generate_project(variable_project, root / "variable_regression", check_files=False)
        if not Path(variable_artifacts["drives"]).exists():
            return 1
        artifacts = generate_project(project, root / "generated")
        if not all(Path(path).exists() for key, path in artifacts.items() if key != "directory"):
            return 1
        print("[5/10] Running trajectory simulation")
        result = run_analytical_simulation(project, root / "results")
        if not result.get("curves"):
            return 1

        # Windows/Unicode regression: generated XML in a non-ASCII project path
        # must enter MuJoCo through the existing VFS contract, never through the
        # machine-specific absolute project path that triggered ParseXML.
        unicode_dir = root / "项目_上翻" / "viewer"
        unicode_dir.mkdir(parents=True)
        unicode_xml = unicode_dir / "generated_model.xml"
        unicode_xml.write_text('<mujoco model="self_check"/>', encoding="utf-8")
        load_calls = []

        class FakeVfs(dict):
            def close(self):
                return None

        class FakeModelFactory:
            @staticmethod
            def from_xml_path(path, **kwargs):
                load_calls.append((str(path), dict(kwargs)))
                return object()

            @staticmethod
            def from_xml_string(xml, **kwargs):
                load_calls.append(("from_xml_string", dict(kwargs)))
                return object()

        class FakeMujoco:
            MjVfs = FakeVfs
            MjModel = FakeModelFactory

        load_generated_mujoco_model(unicode_xml, FakeMujoco)
        if not load_calls or load_calls[0][0] != "__mujoco_studio_scene__.xml" or "vfs" not in load_calls[0][1]:
            return 1

        command = viewer_command(
            unicode_dir / "generated_scene.xml", unicode_dir / "generated_drives.json",
            loop=False, speed=1.0, trajectory_path=unicode_dir / "simulation" / "trajectory.npz",
            working_dir=unicode_dir,
        )
        if command[3] != "generated_scene.xml" or command[4] != "generated_drives.json":
            return 1
        if command[command.index("--trajectory") + 1].replace("\\", "/") != "simulation/trajectory.npz":
            return 1

        # Reclassification on one filesystem must use directory rename instead
        # of the old recursive copy + double-hash path.
        delivery_source = root / "delivery_old"
        delivery_target = root / "delivery_new"
        delivery_source.mkdir()
        (delivery_source / "payload.bin").write_bytes(b"delivery-self-check")
        original_copy = ProjectStore.__dict__["copy_delivery_tree"]
        try:
            def fail_copy(*_args, **_kwargs):
                raise AssertionError("same-filesystem delivery move unexpectedly used verified copy")
            ProjectStore.copy_delivery_tree = fail_copy
            ProjectStore.move_delivery_tree(delivery_source, delivery_target)
        finally:
            ProjectStore.copy_delivery_tree = original_copy
        if delivery_source.exists() or (delivery_target / "payload.bin").read_bytes() != b"delivery-self-check":
            return 1

        print("[6/10] Checking complete project bundle safety and asset injection")
        public_assets = root / "public_assets"
        public_assets.mkdir()
        (public_assets / "mesh.stl").write_bytes(b"mesh-v1")
        (public_assets / "sub").mkdir()
        (public_assets / "sub" / "part.obj").write_text("obj", encoding="utf-8")
        source_inventory = tree_inventory(public_assets)
        isolated_assets = root / "isolated_assets"
        copy_tree_snapshot(public_assets, isolated_assets, max_files=10, max_bytes=1024)
        if tree_inventory(public_assets) != source_inventory or tree_inventory(isolated_assets) != source_inventory:
            return 1

        bundle_stage = root / "bundle_stage"
        (bundle_stage / "model").mkdir(parents=True)
        (bundle_stage / "model" / "model.json").write_text("{}", encoding="utf-8")
        (bundle_stage / "properties" / "model_assets").mkdir(parents=True)
        (bundle_stage / "properties" / "model_assets" / "mesh.stl").write_bytes(b"mesh-v1")
        (bundle_stage / "properties" / "delivery").mkdir(parents=True)
        (bundle_stage / "properties" / "archive_logs").mkdir(parents=True)
        manifest = {
            "format": BUNDLE_FORMAT, "format_version": BUNDLE_FORMAT_VERSION,
            "inventory": tree_inventory(bundle_stage),
        }
        (bundle_stage / MANIFEST_NAME).write_text(json.dumps(manifest), encoding="utf-8")
        bundle_zip = root / "self_check_bundle.zip"
        write_bundle_zip(bundle_stage, bundle_zip)
        extracted = root / "bundle_extracted"
        extract_bundle_zip(bundle_zip, extracted, max_files=20, max_file_bytes=1024, max_total_bytes=4096)
        verify_manifest_inventory(extracted, load_manifest(extracted))
        if not (extracted / "properties" / "delivery").is_dir():
            return 1
        malicious_zip = root / "malicious_bundle.zip"
        with zipfile.ZipFile(malicious_zip, "w") as archive:
            archive.writestr("../escape.txt", "x")
        try:
            extract_bundle_zip(malicious_zip, root / "malicious_out", max_files=5, max_file_bytes=1024, max_total_bytes=1024)
        except ProjectBundleError:
            pass
        else:
            return 1
        asset_store = ProjectStore(root / "bundle_asset_state")
        root_reference, root_asset_path = asset_store.create_model_asset_folder("None", "bundle_import", uploaded_by="self-check")
        if root_reference != "@model_assets/None/bundle_import" or not root_asset_path.is_dir():
            return 1

        print("[7/10] Checking V2.9.7.1 recycle and check-in archive contracts")
        recycle_store = ProjectStore(root / "recycle_state")
        recycle_project = recycle_store.create(ProjectSpec.demo())
        trashed = recycle_store.trash_project(recycle_project.id)
        trash_id = str(trashed.get("trash_id", ""))
        if not trash_id or trash_id not in {str(item.get("trash_id", "")) for item in recycle_store.list_trash()}:
            return 1
        deleted = recycle_store.delete_trash(trash_id)
        if deleted.get("project_id") != recycle_project.id or any(item.get("trash_id") == trash_id for item in recycle_store.list_trash()):
            return 1
        try:
            recycle_store.delete_trash("../escape")
        except ValueError:
            pass
        else:
            return 1
        damaged_project = recycle_store.create(ProjectSpec.demo())
        damaged = recycle_store.trash_project(damaged_project.id)
        damaged_entry = recycle_store.trash_root / str(damaged["trash_id"])
        (damaged_entry / "metadata.json").write_text("{broken", encoding="utf-8")
        try:
            recycle_store.delete_trash(str(damaged["trash_id"]))
        except ValueError:
            pass
        else:
            return 1
        if not damaged_entry.is_dir():
            return 1

        archive_store = ProjectStore(root / "checkin_archive_state")
        archive_project = archive_store.create(ProjectSpec.demo())
        archive_kernel = Kernel(archive_project, archive_store._directory(archive_project.id), archive_store.save)
        archive_identity = Identity("archive-self-check", "admin", session_id="archive-self-check", lease_id="archive-self-check-lease")
        archive_token = set_active_identity(archive_identity)
        try:
            checkout = archive_kernel.bus.dispatch({
                "tool_id": "project.lifecycle",
                "params": {"action": "check_out", "actor": archive_identity.username, "lease_id": archive_identity.lease_id},
                "client": "script",
            })
            if not checkout.ok:
                return 1
            # V2.9.7.1 compatibility gate: even the old explicit false knob must
            # no longer suppress an authoritative check-in safety snapshot.
            archive_kernel.prepare_next_check_in_archive(archive=False, log="")
            checkin = archive_kernel.bus.dispatch({
                "tool_id": "project.lifecycle",
                "params": {"action": "check_in", "actor": archive_identity.username, "lease_id": archive_identity.lease_id},
                "client": "script",
            })
            if not checkin.ok or len(archive_store.list_versions(archive_project.id)) != 1:
                return 1
        finally:
            archive_kernel.clear_next_check_in_archive_policy()
            reset_active_identity(archive_token)

        main_py = (ROOT / "backend" / "app" / "main.py").read_text("utf-8")
        kernel_py = (ROOT / "backend" / "app" / "core" / "kernel.py").read_text("utf-8")
        manager_py = (ROOT / "backend" / "app" / "core" / "manager.py").read_text("utf-8")
        project_store_py = (ROOT / "backend" / "app" / "domain" / "project_store.py").read_text("utf-8")
        backend_contracts = [
            "archive: bool = True",
            "archive_check_in=True",
            '@app.delete("/api/recycle-bin/{trash_id}", status_code=204)',
            "store.delete_trash(trash_id)",
            'if project.lifecycle.status == "baseline" or not latest',
            '_project_preview(project, include_latest_result=False).get("archive_fields", [])',
            'delivery: bool = False',
            'LEGACY_DELIVERY_KINDS = {"axes_csv_folder"}',
            'def _remove_delivery_path(path: Path) -> None:',
            'type is the overwrite key',
            'def download_delivery_folder(project_id: str, subdir: str = Query(default="")):',
            '_current_delivery_outputs(source)',
            '"reconciled_by_type": True',
        ]
        if any(contract not in main_py for contract in backend_contracts):
            return 1
        if 'archive_check_in=bool(params.get("archive", True))' in main_py:
            return 1
        if "self._suppress_next_check_in_archive = False" not in kernel_py:
            return 1
        kernel_v2117_contracts = [
            "def _baseline_name_only_change(",
            'current_metadata.pop("baseline_version_label", None)',
            'after_name = str(after.get("name", ""))',
            'str(after_metadata.get("baseline_version_label", "")) != after_name',
            'after_metadata.pop("baseline_version_label", None)',
            'if status == "baseline":',
            'raise ValueError("基线仅允许通过项目保存接口编辑模型名称")',
        ]
        if any(contract not in kernel_py for contract in kernel_v2117_contracts):
            return 1
        manager_contracts = [
            'source_ui = self.store.project_directory(project_id) / "core" / "ui_state.json"',
            'shutil.copy2(source_ui, target_core / "ui_state.json")',
        ]
        if any(contract not in manager_py for contract in manager_contracts):
            return 1
        hub_store_contracts = [
            '"baseline_created_at": data.get("lifecycle", {}).get("baseline_created_at", "")',
            "for index in range(1, len(parts) + 1):",
            'ancestor = "/".join(parts[:index])',
        ]
        if any(contract not in project_store_py for contract in hub_store_contracts):
            return 1
        if not _check_hub_v2116_contract():
            return 1
        hub_v2117_store_contracts = [
            "def unique_project_name(",
            'suffix = f"_{index:03d}"',
            '160 - len(suffix)',
            "def rename_baseline_history_reference(",
            "return index, self.unique_project_name(source_category, preferred)",
        ]
        if any(contract not in project_store_py for contract in hub_v2117_store_contracts):
            return 1
        if not _check_hub_v2117_contract():
            return 1

        print("[8/10] Checking V2.12.2 frontend/delivery/Viewer/VZ contracts")
        app_js = (ROOT / "frontend" / "app.js").read_text("utf-8")
        index_html = (ROOT / "frontend" / "index.html").read_text("utf-8")
        styles_css = (ROOT / "frontend" / "styles.css").read_text("utf-8")
        frontend_contracts = [
            "hubCollapseInitialized: false",
            "state.hubCollapsedModelTypes = new Set(collapsibleModelTypePaths())",
            "function hubBaselineFrozenAt(project)",
            "function hubCategoryProjects(category = state.hubCategory)",
            "if (projectStatus(project) !== 'baseline') return;",
            "projectCategory.startsWith(descendantPrefix)",
            "const catalogProjects = query ? state.projects : hubCategoryProjects(state.hubCategory);",
            "const rootProjectCount = state.projects.length;",
            "function refreshHubModelTypeCountsFromProjects()",
            "body:JSON.stringify({data, target_category:currentHubImportCategory()})",
            "form.append('target_category',currentHubImportCategory())",
            "resetEditorLayoutDefaults();",
            "state.editorLayout.meshTwoColumns = true",
            "state.editorLayout.driveTwoColumns = true",
            "data-reverse-vector=",
            "adaptive-all-project-meshes",
            "全部数模自适应",
            "hubSelectedTrashIds: new Set()",
            "hub-trash-toggle",
            "hub-trash-select-all",
            "hub-delete-selected-trash",
            "deleteSelectedHubTrashProjects()",
            "archive = true;",
            "function hierarchyViewMode()",
            "uiSet('model.hierarchy_view'",
            "model.diagram.nodes",
            "data-hierarchy-diagram-viewport",
            "diagram-link-kind",
            "data-diagram-tree-closure-toggle",
            "data-diagram-body-mesh",
            "data-diagram-edge-bend",
            "closure-joint-pick",
            "addDiagramLayerFromMesh",
            "hierarchyDiagramCreateClosure",
            "function setClosurePointMm(closure, side, point)",
            "if (side === 'shared')",
            "closure.endpoint_a.point_mm = [...normalized];",
            "closure.endpoint_b.point_mm = [...normalized];",
            'data-closure-point="${index}:shared"',
            "<label>闭链坐标<input",
            "function hierarchyDiagramEdgeLocked(edgeKind, edgeId)",
            "function hierarchyDiagramEndpointOptions(selectedId)",
            "function hierarchyDiagramViewportState()",
            "model.diagram.viewport",
            "uiCommitChain: Promise.resolve()",
            "uiRevision: 0",
            "uiPersistedRevision: 0",
            "if (state.uiPersistedRevision < fence.uiRevision) return false",
            "const firstRevision = state.uiRevision + 1",
            "hierarchyDiagramMultiSelection: new Set()",
            "hierarchyDiagramSuppressPaneClick: false",
            "function hierarchyDiagramLayoutState()",
            "model.diagram.layout",
            'data-diagram-node-resize-axis="x"',
            'data-diagram-node-resize-axis="y"',
            "data-diagram-mesh-drop-target",
            "const blankPane = diagramViewport",
            "function deleteHierarchyDiagramSelection()",
            "function removeLayerAtIndex(li",
            "event.key === 'Delete'",
            "child.parent_id = 'root';",
            "meshes.length > 1",
            "delivery:true",
            "#19e65c",
            "#1489ff",
            "#8a36ff",
            "#ff8a00",
            "function hierarchyDiagramPreferredSide(node, point)",
            "function hierarchyDiagramEdgeEndpoints(aNode, bNode)",
            "['left','right','top','bottom'].map",
            "function hierarchyDiagramTreePathEdgeIds(aId, bId)",
            "function hierarchyDiagramClosureCycles()",
            "function hierarchyDiagramClosureColor(index)",
            "function hierarchyDiagramFallbackLayoutValues()",
            "function meshBaseName(filename)",
            "layer.name = uniqueName(meshBaseName(filename)",
            "已自动转换为闭链虚线",
            "function hierarchyDiagramClosureAutoPassiveJointIds(closure)",
            "if (hierarchyDiagramEdgeDrives(child).length) return [];",
            "function hierarchyDiagramDriveIconMarkup(layer, path, inactive = false)",
            "root.dataset.diagramMeshDropTarget = String(li);",
            "`${parent.name}——>${layer.name}`",
            "passive-pick-hit",
            "hierarchy-edge-joint-icon",
            "function renderDiagramEmptyDetails()",
            "function renderDiagramNodeDetails(layer, li)",
            "function renderDiagramTreeEdgeDetails(layer, li)",
            "event.button === 1",
            "event.ctrlKey",
            "if (parent?.active === false) return toast",
            "未激活层级相关连线已锁定",
            "const dimensions = new Map",
            "const columnGap = 112;",
            "const siblingGap = 46;",
            "const subtreeHeight = (layer, stack = new Set()) =>",
        ]
        if any(contract not in app_js for contract in frontend_contracts):
            return 1
        hub_v2117_frontend_contracts = [
            'id="baselineNameText"',
            "项目文件夹属性",
            "hub-rename-folder",
            "const folderPropertiesMode = Boolean(state.hubTypeSummary)",
            "inspectorPanel.hidden = folderPropertiesMode",
            "hub-folder-properties",
            "const nameEditable = !state.hubPreviewVersionId && (editable || (status === 'baseline' && ['engineer','admin'].includes(state.auth?.role))",
            "JSON.stringify({name, log, gantt_saved_at})",
            "hub-baseline-frozen-time",
            "<b>冻结时间</b>",
            "hubBaselineFrozenAt(a).localeCompare(hubBaselineFrozenAt(b))",
        ]
        if any(contract not in (app_js + index_html + styles_css) for contract in hub_v2117_frontend_contracts):
            return 1
        summary_start = app_js.find("async function loadHubTypeSummary(category)")
        summary_end = app_js.find("function renderHub()", summary_start)
        if summary_start < 0 or summary_end < 0 or "/archives" in app_js[summary_start:summary_end]:
            return 1
        folder_start = app_js.find("if (state.hubTypeSummary) {", app_js.find("function renderHubPreview"))
        folder_end = app_js.find("$('#hubPreviewTitle').textContent = '模型属性';", folder_start)
        if folder_start < 0 or folder_end < 0:
            return 1
        folder_branch = app_js[folder_start:folder_end]
        if any(token in folder_branch for token in ("hub-type-archives", "hub-type-delivery", "project_count", "baseline_count")):
            return 1
        if 'id="hubToggleAllCategoriesButton"' not in index_html or 'id="projectBundleInput"' not in index_html:
            return 1
        if 'id="hierarchyViewToggle"' not in index_html or 'id="hierarchyDiagramPanel"' not in index_html:
            return 1
        if 'id="addLayerButton"' in index_html or "$('#addLayerButton')" in app_js:
            return 1
        if "if (event.button === 2 && diagramViewport)" in app_js or "document.addEventListener('contextmenu', event =>" in app_js:
            return 1
        if "action === 'undo' ? 3600 : null" not in app_js:
            return 1
        if '框图建模：首次进入时按当前层级关系自动排布' in app_js:
            return 1
        if 'site 坐标 mm<input data-closure-point="${index}:b"' in app_js or '默认只配置闭链子级一侧的 site 坐标' in app_js:
            return 1
        if "action === 'diagram-toggle-closure-joint'" in app_js or 'hierarchy-node-joint-picks' in app_js:
            return 1
        if '#ff2d2d' in app_js or '#ff2d2d' in styles_css:
            return 1
        if '.model-studio.diagram-mode' not in styles_css or '.hierarchy-diagram-node' not in styles_css:
            return 1
        diagram_css_contracts = [
            '.hierarchy-diagram-node.inactive .hierarchy-node-port',
            '.hierarchy-edge-hit.locked',
            '.hierarchy-edge.loop-edge',
            '.hierarchy-edge.loop-site-edge,.hierarchy-edge.closure-edge',
            'stroke-dasharray:8 5',
            '.hierarchy-node-port.side-top',
            '.hierarchy-node-port.side-bottom',
            '.diagram-compact-properties',
            'var(--diagram-library-width,140px)',
            '.diagram-layout-splitter',
            '.hierarchy-diagram-selection-box',
            'will-change:transform;overflow:visible',
            'font-size:13px',
            '.diagram-edge-properties .diagram-property-head',
            'min-height:18px',
            '.diagram-body-mesh-title',
            '.hierarchy-edge-drive-icon',
            'width:36px',
            '.hierarchy-edge.passive-pick',
            '.hierarchy-edge-hit.passive-pick-hit',
            '.diagram-property-root.mesh-drag-over',
            '.diagram-body-mesh-picker-static .diagram-mesh-chip-list span',
            'font-size:14px',
        ]
        if any(contract not in styles_css for contract in diagram_css_contracts):
            return 1
        if 'id="hierarchyDiagramZoom"' not in index_html:
            return 1
        if 'data-diagram-layout-splitter="property"' not in index_html or 'data-diagram-layout-splitter="library"' not in index_html or 'id="hierarchyDiagramSelectionBox"' not in index_html:
            return 1
        rotation_icon = ROOT / "frontend" / "diagram_joint_rotation.png"
        translation_icon = ROOT / "frontend" / "diagram_joint_translation.png"
        if not rotation_icon.is_file() or not translation_icon.is_file():
            return 1
        if hashlib.sha256(rotation_icon.read_bytes()).hexdigest() != "ecee80fe97ae5d653929c0120656aa7687a0280b5aef21e81329cfed0e4884a0":
            return 1
        if hashlib.sha256(translation_icon.read_bytes()).hexdigest() != "8f28dc16e92e9d01982debf26dba532b548c7684bd00a5cded3cb4d3480600d0":
            return 1
        if "directClosure" in app_js or "direct parent-child loop is represented by the same dashed" in app_js:
            return 1
        if "const jointPick = pickClosure ? (layer.joints || []).filter(joint => joint.type !== 'crank') : [];" in app_js:
            return 1
        if "function diagramTreeEdgeBanner" in app_js or "hierarchy-node-footer" in app_js:
            return 1
        current_version = (ROOT / "VERSION").read_text("utf-8").strip()
        init_py = (ROOT / "backend" / "app" / "__init__.py").read_text("utf-8")
        pyproject = (ROOT / "pyproject.toml").read_text("utf-8")
        animation_export = (ROOT / "backend" / "app" / "domain" / "animation_export.py").read_text("utf-8")
        viewer_runner = (ROOT / "backend" / "app" / "domain" / "viewer_runner.py").read_text("utf-8")
        if current_version != "2.13.3" or '__version__ = "2.13.3"' not in init_py or 'version = "2.13.3"' not in pyproject:
            return 1
        if 'styles.css?v=2.13.3' not in index_html or 'mapping_math.js?v=2.13.3' not in index_html or 'app.js?v=2.13.3' not in index_html or 'API 2.13.3' not in index_html:
            return 1
        if 'result["studio_version"] = "2.13.3"' not in animation_export or 'Playback Controller V2.13.3' not in viewer_runner:
            return 1
        if "MuJoCo Viewer 将继续打开；甘特图仅作为辅助显示，不影响仿真窗口。" not in app_js:
            return 1
        if "try {\n        await window.__GanttPopup__.refreshCache(projectId);" not in app_js:
            return 1
        client_bundle_py = (ROOT / "backend" / "app" / "domain" / "client_bundle.py").read_text("utf-8")
        gantt_bundle_contracts = [
            "def _optional_gantt_snapshot(",
            '"reason": "not_generated"',
            '"reason": "cache_incomplete"',
            '"reason": "cache_invalid"',
            "gantt_snapshot, gantt_manifest = _optional_gantt_snapshot(gantt_cache_dir)",
        ]
        if any(contract not in client_bundle_py for contract in gantt_bundle_contracts):
            return 1
        mapping_curve_py = (ROOT / "backend" / "app" / "domain" / "mapping_curve.py").read_text("utf-8")
        mapping_math_js = (ROOT / "frontend" / "mapping_math.js").read_text("utf-8")
        mapping_v21221_contracts = [
            "compile_minimum_jerk",
            "_block_tridiagonal_solve",
            "mapping_derivatives",
            "minimum-jerk interpolant",
        ]
        if any(contract not in mapping_curve_py for contract in mapping_v21221_contracts):
            return 1
        if any(contract not in mapping_math_js for contract in (
            "MAPPING_INTERPOLATION_MODE = 'minimum_jerk_quintic'",
            "function blockSolve",
            "function mapDerivatives",
        )):
            return 1
        if any(contract not in client_bundle_py for contract in (
            'mapping_curve_path = controller_path.with_name("mapping_curve.py")',
            '"mapping_curve": {',
            'archive.writestr("mapping_curve.py", mapping_curve_bytes)',
        )):
            return 1
        if not _check_optional_gantt_contract():
            return 1
        hub_v2117_backend_contracts = [
            'name: str = Field(default="", max_length=160)',
            'request.name if request else ""',
            'if current.lifecycle.status == "baseline":',
            'final_name = store.unique_project_name(',
            'renamed = ProjectSpec.model_validate(copy.deepcopy(current.model_dump()))',
            'renamed.metadata["baseline_version_label"] = final_name',
            'store.rename_baseline_history_reference(',
        ]
        if any(contract not in main_py for contract in hub_v2117_backend_contracts):
            return 1
        baseline_delivery_contracts = [
            "gantt_saved_at: float | None = None",
            "def _baseline_latest_simulation(source: ProjectSpec)",
            "def _baseline_animation_html(source: ProjectSpec)",
            "def _baseline_gantt_png(source: ProjectSpec, stage_root: Path, expected_saved_at: float | None)",
            "def _refresh_baseline_delivery_outputs(",
            'required_kinds = {"nx_afu_script", "gantt_png", "model_json", "animation_html"}',
            "baseline_prepare: bool = Query(False)",
        ]
        if any(contract not in main_py for contract in baseline_delivery_contracts):
            return 1
        baseline_frontend_contracts = [
            "async function publishResultAxesTimeSeries()",
            "await downloadPublishedTimeSeries(result.timeSeries);",
            "async function ensureBaselineAnimationHtml(projectId)",
            "baseline_prepare=true",
            "async function refreshBaselineGantt(projectId)",
            "async function latestArchiveLogForProject(projectId)",
            "String(version?.version_kind || 'archive') === 'archive'",
            "const existingLog = await latestArchiveLogForProject(projectId);",
            "const gantt_saved_at=await refreshBaselineGantt(projectId);",
            "4 类交付数据已冻结",
        ]
        if any(contract not in app_js for contract in baseline_frontend_contracts):
            return 1
        if any(token in (app_js + index_html + styles_css) for token in (
            "wecomWebhook", "baselineWebhook", "企微机器人", "企微 Webhook",
        )):
            return 1
        if any(token in main_py for token in (
            "def _post_wecom_text", "def _baseline_wecom_message", "X-MuJoCo-WeCom",
        )):
            return 1
        if "webhook_url" in main_py:
            return 1
        storage_py = (ROOT / "backend" / "app" / "storage_config.py").read_text("utf-8")
        run_py = (ROOT / "run.py").read_text("utf-8")
        vz_root = ROOT / "integrations" / "VZ_Studio_V0.3.2.1"
        vz_store = (vz_root / "vz" / "store.py").read_text("utf-8")
        vz_models = (vz_root / "vz" / "models.py").read_text("utf-8")
        vz_server = (vz_root / "vz" / "server.py").read_text("utf-8")
        engineer_html = (vz_root / "frontend" / "engineer.html").read_text("utf-8")
        engineer_js = (vz_root / "frontend" / "engineer.js").read_text("utf-8")
        client_html = (vz_root / "frontend" / "client.html").read_text("utf-8")
        client_js = (vz_root / "frontend" / "client.js").read_text("utf-8")
        material_editor_js = (vz_root / "frontend" / "material-editor.js").read_text("utf-8")
        material_selection_contracts = [
            "_drawSelectionOutline(vp)",
            "this.pickFramebuffer",
            "gl.drawArrays(gl.TRIANGLES,0,3)",
            "gl.bindVertexArray(null);this._drawSelectionOutline(vp)",
            "仅轮廓描边高亮，不改变材质预览",
        ]
        if any(contract not in material_editor_js for contract in material_selection_contracts):
            return 1
        if "uSelected" in material_editor_js or "if(uSelected" in material_editor_js:
            return 1
        if "newModelButton" in engineer_html or "copyModelButton" in engineer_html or "生成预览图" not in engineer_html or "移除模型" not in engineer_html:
            raise RuntimeError("V2.12.2 engineer explorer/action surface contract is incomplete")
        if '"X-VZ-Render-Samples": "1"' not in vz_server or '"X-VZ-Warmup-Renders": "0"' not in vz_server or "X-VZ-Render-Time-Ms" not in vz_server:
            raise RuntimeError("V2.12.2 one-sample Fast render contract is incomplete")
        if "mountClientLibraryPreviews" in client_js or "preview_url" not in client_js or '/static/viewer.js' in client_html:
            raise RuntimeError("V2.12.2 cached user-library preview contract is incomplete")
        if "front_preview.png" not in vz_store or 'preview\\.png' not in vz_server or '/preview"' not in vz_server:
            raise RuntimeError("V2.12.2 derived model preview API contract is incomplete")
        legacy_animation_html = (vz_root / "vz" / "legacy_animation_html_export.py").read_text("utf-8")
        automotive_render_contracts = [
            '"automotive_interior"',
            "汽车内饰摄影棚 / Automotive Interior",
        ]
        if any(contract not in (vz_models + engineer_js) for contract in automotive_render_contracts):
            return 1
        shader_contracts = [
            "vec3 pbrNeutral(vec3 x)",
            "if(uScenePresetMode==2)",
            "float specOcc=",
            "pcf=sum/25.0",
            "pcf=sum/9.0",
            "uQuality>1.5?pbrNeutral",
            "automotive_interior:{mode:2",
            "directional_light_intensity",
            "uKeyLightDir",
            "if(!gl_FrontFacing)discard",
        ]
        if any(contract not in legacy_animation_html for contract in shader_contracts):
            return 1
        key_light_definition = legacy_animation_html.find("const KEY_LIGHT_DIR=directionalFromScene(RENDER_SCENE);")
        key_light_first_use = legacy_animation_html.find("const keyLightDir=KEY_LIGHT_DIR")
        if key_light_definition < 0 or key_light_first_use < 0 or key_light_definition >= key_light_first_use:
            raise RuntimeError("V2.12.2 directional-light bootstrap order contract is incomplete")
        if "function showRendererBootFailure" not in legacy_animation_html or 'window.addEventListener("unhandledrejection"' not in legacy_animation_html:
            raise RuntimeError("V2.12.2 offline-animation startup failure surface is incomplete")
        render_scene_contracts = [
            "directional_light_intensity",
            "directional_light_yaw_deg",
            "directional_light_pitch_deg",
            "基础平行光",
            "平行光强度 0–4",
        ]
        if any(contract not in (vz_models + engineer_js) for contract in render_scene_contracts):
            return 1
        if '--sidebar:252px' not in (vz_root / 'frontend' / 'studio.css').read_text('utf-8'):
            return 1
        viewer_js = (vz_root / 'frontend' / 'viewer.js').read_text('utf-8')
        preview_contracts = [
            'parsed.slice(0,200000)',
            "bg.addColorStop(0,'#f1f2f3')",
            'shadowY=view([camera.target[0],camera.target[1],0])[1]',
        ]
        if any(contract not in viewer_js for contract in preview_contracts):
            return 1
        storage_contracts = [
            'DATA_FOLDER_NAME = "V2_projec"',
            'DEFAULT_ANCESTOR_LEVELS = 2',
            'def _candidate_from_base(base: Path) -> Path:',
            'def probe_storage_location(',
            'def save_storage_location(',
            'def resolved_data_root(',
            '"restart_required": True',
        ]
        if any(contract not in storage_py for contract in storage_contracts):
            return 1
        if '@app.get("/api/admin/storage-location")' not in main_py or '@app.post("/api/admin/storage-location/probe")' not in main_py or '@app.put("/api/admin/storage-location")' not in main_py:
            return 1
        if 'env["VZ_PROJECT_ROOT"] = str((DATA_ROOT / "vz").resolve())' not in run_py:
            return 1
        if 'id="storageLocationSection"' not in index_html or 'id="storageAncestorLevels"' not in index_html or 'id="storageBasePath"' not in index_html:
            return 1
        hub_vz_contracts = [
            '/assets/repair',
            'relinked_assets',
            'expected_links = sum',
            'created_new = False',
        ]
        if any(contract not in main_py for contract in hub_vz_contracts):
            return 1
        if 'make_demo_model' in vz_store:
            return 1
        if 'model_library.json' not in vz_store or 'control_graph.json' not in vz_store or '控制画布连线不能形成循环' not in vz_store:
            return 1
        if 'scene_coordinates' not in vz_models or 'hard_point_mm' not in vz_models or 'h_point_mm' not in vz_models:
            return 1
        for route in ['/api/model-library', '/api/control-graph']:
            if route not in vz_server:
                return 1
        vz_studio_css = (vz_root / "frontend" / "studio.css").read_text("utf-8")
        vz_client_css = (vz_root / "frontend" / "styles.css").read_text("utf-8")
        vz_animation_export = (vz_root / "vz" / "animation_export.py").read_text("utf-8")
        simulation_py = (ROOT / "backend" / "app" / "domain" / "simulation.py").read_text("utf-8")
        optimization_py = (ROOT / "backend" / "app" / "domain" / "optimization.py").read_text("utf-8")
        if engineer_html.count('data-scene-coordinate=') != 2 or 'data-scene-coordinate="hard_point_mm"' not in engineer_html or 'data-scene-coordinate="h_point_mm"' not in engineer_html:
            return 1
        engineer_contracts = [
            'function parseSceneCoordinateInput(raw)',
            "replace(/，/g,',')",
            'fast_max_faces_per_mesh:120000',
            'function renderModelList()',
            'collapsedFolders:new Set()',
            '/api/model-library/models/',
        ]
        if any(contract not in engineer_js for contract in engineer_contracts):
            return 1
        if '${info.title}已生成' in engineer_js or '渲染已生成' in engineer_js:
            return 1
        if '"fast_max_faces_per_mesh":120000' not in vz_models or 'fast_max_faces_per_mesh", 120000' not in vz_animation_export:
            return 1
        if '--sidebar:252px' not in vz_studio_css or '.model-explorer-row' not in vz_studio_css:
            return 1
        watermark_render_contracts = [
            '"animation_watermark_text": "C项目-时序仿真组"',
            '"animation_watermark_position": "0, 0, 0"',
            '"animation_watermark_size_mm": 150',
            '"animation_watermark_thickness_mm": 10',
        ]
        if any(contract not in vz_animation_export for contract in watermark_render_contracts):
            raise RuntimeError("V2.12.2 second-generation center 3D text contract is incomplete")
        if 'const watermarkMesh=createWatermarkMesh(DATA.watermark);' not in legacy_animation_html:
            raise RuntimeError("V2.12.2 shared 3D watermark mesh renderer contract is incomplete")
        if '.html-render-settings-modal .render-config-grid{grid-template-columns:repeat(3,minmax(0,1fr));' not in vz_studio_css:
            raise RuntimeError("V2.12.2 three-column render settings layout contract is incomplete")
        client_markup_contracts = [
            'id="sceneDropZone"',
            'id="sceneVerticalSplitter"',
            'id="sceneControlRows"',
            'id="clientLevel1Folders"',
            'id="clientLevel2Folders"',
            'id="clientModelLibrary"',
        ]
        if any(contract not in client_html for contract in client_markup_contracts) or 'id="controlCanvasViewport"' in client_html:
            return 1
        scene_board_contracts = [
            'function addModelToScene(',
            'function renderSceneControlBoard(',
            'function bindSceneBoard(',
            'clientFolderLevel1',
            'async function renderSceneCoordinateBadge()',
            'const referenceNode=(state.graph.nodes||[])[0]',
            "localStorage.getItem('vz.sceneViewerRatio')",
        ]
        if any(contract not in client_js for contract in scene_board_contracts):
            return 1
        if '.scene-board-shell.client-shell' not in vz_client_css or '.scene-vertical-splitter' not in vz_client_css or 'width:128px' not in vz_client_css:
            return 1
        sampling_contracts = [
            'include_boundaries: bool = False',
            'np.arange(tick_count + 1, dtype=float)',
            'times = build_time_grid(project.simulation)',
        ]
        if any(contract not in simulation_py for contract in sampling_contracts):
            return 1
        if 'include_boundaries=True' not in optimization_py:
            return 1
        strict_grid = build_time_grid(SimulationSettings(start_time=0.0, end_time=1.0, timestep=0.01), [0.1234, 0.7777])
        if len(strict_grid) != 101 or abs(float(strict_grid[0])) > 1e-12 or abs(float(strict_grid[-1]) - 1.0) > 1e-12:
            return 1
        if any(abs(float(strict_grid[i + 1] - strict_grid[i]) - 0.01) > 1e-10 for i in range(len(strict_grid) - 1)):
            return 1
        if any(abs(float(value) - 0.1234) < 1e-12 for value in strict_grid):
            return 1
        off_grid_end = build_time_grid(SimulationSettings(start_time=0.0, end_time=1.005, timestep=0.01))
        if abs(float(off_grid_end[-1]) - 1.0) > 1e-12:
            return 1
        boundary_probe = build_time_grid(SimulationSettings(start_time=0.0, end_time=1.0, timestep=0.01), [0.1234], include_boundaries=True)
        if not any(abs(float(value) - 0.1234) < 1e-12 for value in boundary_probe):
            return 1
        viewer_grid = _strict_result_time_grid(0.0, 1.0, 0.01)
        if len(viewer_grid) != 101 or any(abs(float(viewer_grid[i + 1] - viewer_grid[i]) - 0.01) > 1e-10 for i in range(len(viewer_grid) - 1)):
            return 1
        viewer_off_grid_end = _strict_result_time_grid(0.0, 1.005, 0.01)
        if abs(float(viewer_off_grid_end[-1]) - 1.0) > 1e-12:
            return 1
        if 'np.linspace(start_time, end_time, 241)' in viewer_runner or 'chart_times = _strict_result_time_grid(start_time, end_time, timestep)' not in viewer_runner:
            return 1
        if 'if order and len(chart_times) < 2:' not in viewer_runner:
            return 1
        viewer_motor_contracts = [
            'pending_manual_inputs[drive_id] = float(raw)',
            'def apply_pending_motor_inputs() -> bool:',
            '"motor_ui_hz": 30.0',
            'manual_dragging: set[str] = set()',
            'def begin_motor_drag(drive_id: str) -> None:',
            'for drive_id in tuple(manual_dragging):',
            'mapping_root_by_drive, mapping_family_by_drive = _viewer_mapping_topology(',
            'root_id, root_value = _viewer_root_mapping_source(',
            'family = set(mapping_family_by_drive.get(drive_id, frozenset({root_id})))',
            'manual_roots = {mapping_root_by_drive.get(drive_id, drive_id) for drive_id in decoupled}',
            'decoupled.intersection(linked_mapping_drive_ids)',
            'if drive_id in decoupled and drive_id not in linked_mapping_drive_ids:',
            ') = _enforce_viewer_kinematic_closure(',
            'kinematics_only=True',
        ]
        if any(contract not in viewer_runner for contract in viewer_motor_contracts):
            return 1
        motor_changed_start = viewer_runner.find('def motor_changed(drive_id: str, raw: str) -> None:')
        motor_apply_start = viewer_runner.find('def apply_pending_motor_inputs() -> bool:', motor_changed_start)
        if motor_changed_start < 0 or motor_apply_start < 0:
            return 1
        motor_changed_body = viewer_runner[motor_changed_start:motor_apply_start]
        if 'root_mapping_source(' in motor_changed_body or 'refresh_motor_labels(' in motor_changed_body or 'dict(control' in motor_changed_body:
            return 1
        if 'command=lambda value, key=drive_id: motor_changed(key, value)' in viewer_runner:
            return 1
        if not _check_viewer_mapping_family_contract():
            return 1
        if not _check_viewer_kinematic_closure_contract():
            return 1
        client_bundle_py = (ROOT / "backend" / "app" / "domain" / "client_bundle.py").read_text("utf-8")
        bundle_closure_contracts = [
            'closure_solver_path = controller_path.with_name("kinematic_closure.py")',
            '"kinematic_closure": {',
            'archive.writestr("kinematic_closure.py", closure_solver_bytes)',
            '"controller_signature_version": 4',
            '"schema_version": 4',
        ]
        if any(contract not in client_bundle_py for contract in bundle_closure_contracts):
            return 1
        if 'parsed = urlparse(self.path)\n                    path = unquote(parsed.path)' not in vz_server:
            return 1
        graph_contracts = [
            'function graphWouldCycle(',
            'function beginGraphConnection(',
            'function beginGraphNodeDrag(',
            'function beginGraphNodeResize(',
            'function beginGraphEdgeBend(',
            'function autoLayoutGraph(',
            'function graphAlignmentForModel(',
            'hard_point_mm',
            'h_point_mm',
            'transform_mm',
            'graphRevision:0',
            'revision===state.graphRevision',
            "event.key!=='Delete'&&event.key!=='Backspace'",
        ]
        if any(contract not in client_js for contract in graph_contracts):
            return 1
        if '.joint-direction-check span{border-radius:0!important}' not in styles_css:
            return 1
        if 'min-width:8ch!important' not in styles_css:
            return 1
        if '模型 A' in app_js or '模型 B' in app_js or 'select-layer-tree-tab' in app_js:
            return 1
        if '${joint.limited ? `<label class="range-pair"' not in app_js:
            return 1
        if "本次手动签入是否需要存档" in app_js or "仅签入，不存档" in app_js:
            return 1
        if '↷ 前进' not in index_html or '↷ 重做' in index_html:
            return 1

        print("[9/10] Checking command, event and undo core")
        store = ProjectStore(root / "state_data")
        persisted = store.create(ProjectSpec.demo())
        kernel = Kernel(persisted, store._directory(persisted.id), store.save)
        identity = Identity("self-check", "admin", session_id="self-check", lease_id="self-check-lease")
        identity_token = set_active_identity(identity)
        try:
            checkout = kernel.bus.dispatch({
            "tool_id": "project.lifecycle",
            "params": {"action": "check_out", "actor": identity.username, "lease_id": identity.lease_id},
            "client": "script",
            })
            command = kernel.bus.dispatch({
            "tool_id": "param.set",
            "params": {"path": "project.variables.speed_scale", "value": 1.5},
            "client": "script",
            })
            if not checkout.ok or not command.ok or kernel.events.cursor() != 2 or not kernel.bus.undo().ok:
                return 1
        finally:
            reset_active_identity(identity_token)
    print("[10/10] Reporting temporary workspace bounds")
    count, total_bytes, stale = _temporary_workspace_usage(DATA_ROOT)
    print(f"Temporary workspaces: count={count}, bytes={total_bytes}, stale_over_ttl={stale}")
    if stale:
        print(f"WARNING: {stale} temporary workspace(s) exceed the {ORPHAN_WORKSPACE_TTL_HOURS:g} h TTL")
    print("Self-check passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
