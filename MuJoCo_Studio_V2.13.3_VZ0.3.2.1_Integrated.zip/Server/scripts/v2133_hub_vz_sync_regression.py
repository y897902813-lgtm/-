#!/usr/bin/env python3
"""Focused V2.13.3 regression: Hub/VZ push-state closure + shared time-series source."""
from __future__ import annotations

import ast
import copy
import io
import json
import math
import re
import sys
import tempfile
import threading
import typing
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.app.domain.models import DriveSegmentSpec, DriveSpec, JointSpec, LayerSpec, ProjectSpec
from backend.app.domain.time_series_library import (
    build_time_series_bundle,
    is_mapping_table_name,
    parse_time_series_csv,
)

VZ_ROOT = ROOT / "integrations" / "VZ_Studio_V0.3.2.1"
if str(VZ_ROOT) not in sys.path:
    sys.path.insert(0, str(VZ_ROOT))
from vz.server import VZApplication
from vz.store import ModelStore


def text(relative: str) -> str:
    return (ROOT / relative).read_text("utf-8")


class FakeHubStore:
    def __init__(self, root: Path) -> None:
        self.root = root

    def time_series_directory(self, _project: ProjectSpec, *, create: bool = False) -> Path:
        if create:
            self.root.mkdir(parents=True, exist_ok=True)
        return self.root


def load_projection_helpers(fake_store: FakeHubStore):
    """Load projection-only helpers without importing FastAPI/passlib runtime."""
    source = text("backend/app/main.py")
    tree = ast.parse(source)
    wanted = {"_vz_version_tuple", "_vz_drive_projection_sources", "_vz_engineer_drive_settings"}
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in wanted]
    assert {node.name for node in nodes} == wanted
    module = ast.Module(body=nodes, type_ignores=[])
    ast.fix_missing_locations(module)
    scope = {
        "Any": typing.Any,
        "ProjectSpec": ProjectSpec,
        "copy": copy,
        "is_mapping_table_name": is_mapping_table_name,
        "math": math,
        "parse_time_series_csv": parse_time_series_csv,
        "re": re,
        "store": fake_store,
    }
    exec(compile(module, "<v2133-main-helpers>", "exec"), scope)
    return scope["_vz_drive_projection_sources"], scope["_vz_engineer_drive_settings"]


def build_projects() -> tuple[ProjectSpec, ProjectSpec]:
    joint_current = JointSpec(id="joint_current", name="主运动副", type="rotation")
    joint_legacy = JointSpec(id="joint_legacy", name="时序运动副", type="rotation")
    current_drive = DriveSpec(
        id="drive_current", name="当前驱动名称", joint_id=joint_current.id,
        segments=[DriveSegmentSpec(id="seg_current", name="当前段", start=0.0, duration=1.0, travel=5.0)],
    )
    time_series_current = DriveSpec(
        id="drive_current", name="CSV中的旧名称", joint_id=joint_current.id,
        segments=[DriveSegmentSpec(id="seg_current", name="当前段", start=0.0, duration=1.0, travel=5.0)],
    )
    time_series_only = DriveSpec(
        id="drive_from_ts", name="仅时序驱动", joint_id=joint_legacy.id,
        segments=[DriveSegmentSpec(id="seg_ts", name="时序段", start=2.0, duration=2.0, travel=30.0)],
    )
    layers = [LayerSpec(id="layer_main", name="机构", joints=[joint_current, joint_legacy])]
    current = ProjectSpec(id="project_2133", name="当前模型", layers=layers, drives=[current_drive])
    original_with_sequence = ProjectSpec(
        id="project_2133", name="当前模型", layers=layers,
        drives=[time_series_current, time_series_only],
    )
    return current, original_with_sequence


def test_drive_projection_from_hub_sequence() -> None:
    current, sequence_project = build_projects()
    with tempfile.TemporaryDirectory(prefix="v2133_projection_") as temp:
        library = Path(temp) / "时序库"
        library.mkdir()
        filename, content, _ = build_time_series_bundle(sequence_project, [])
        (library / filename).write_text(content, "utf-8")
        # Must be ignored by projection scan.
        (library / "驱动--段映射表格.csv").write_text("source,target\n0,0\n", "utf-8")

        source_helper, settings_helper = load_projection_helpers(FakeHubStore(library))
        sources = source_helper(current)
        assert [item["id"] for item in sources] == ["drive_current", "drive_from_ts"]
        # ProjectSpec wins over a stale CSV row with the same drive id.
        assert sources[0]["name"] == "当前驱动名称"
        assert sources[1]["name"] == "仅时序驱动"
        assert sources[1]["joint_id"] == "joint_legacy"

        parts = settings_helper(current, None, source_drives=sources)
        motions = {part["motions"][0]["exchange_drive_id"]: part["motions"][0] for part in parts}
        restored = motions["drive_from_ts"]
        assert restored["name"] == "仅时序驱动"
        assert restored["joint_id"] == "joint_legacy"
        assert restored["position_0_percent"] == 0.0
        assert restored["position_100_percent"] == 30.0
        assert restored["rated_speed"] == 30.0
        assert "exchange_segment" not in restored


def archive_for(name: str, content: str) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(name, content.encode("utf-8"))
    return buffer.getvalue()


def test_hub_source_and_vz_workspace_isolation() -> None:
    _current, sequence_project = build_projects()
    filename, content, _ = build_time_series_bundle(sequence_project, [])
    with tempfile.TemporaryDirectory(prefix="v2133_vz_ts_") as temp:
        store = ModelStore(Path(temp))
        model = store.create({"id": "vz_2133_ts", "name": "时序边界回归"}, preserve_id=True)
        store.replace_time_series_archive(model["id"], archive_for(filename, content))
        manifest = store.time_series_editor_manifest(model["id"])
        hub = next(item for item in manifest["items"] if item["scope"] == "hub")
        assert hub["readonly"] is True

        copied = store.copy_time_series(model["id"], "hub", filename, "VZ本地副本")
        local = next(item for item in copied["items"] if item["scope"] == "local")
        assert local["readonly"] is False
        workspace = store.time_series_workspace_directory(model["id"], create=True) / local["name"]
        before = workspace.read_bytes()

        # A later Hub refresh atomically replaces only time_series_library.
        refreshed_content = content.replace("当前模型", "Hub刷新后的模型")
        store.replace_time_series_archive(model["id"], archive_for(filename, refreshed_content))
        after_manifest = store.time_series_editor_manifest(model["id"])
        assert after_manifest["hub_count"] == 1 and after_manifest["local_count"] == 1
        assert workspace.is_file() and workspace.read_bytes() == before
        assert next(item for item in after_manifest["items"] if item["scope"] == "hub")["readonly"] is True
        assert next(item for item in after_manifest["items"] if item["scope"] == "local")["readonly"] is False




def test_vz_engineer_removal_bridge_callback() -> None:
    received: dict[str, typing.Any] = {}

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):  # noqa: N802 - stdlib handler contract
            length = int(self.headers.get("Content-Length", "0") or 0)
            received["path"] = self.path
            received["token"] = self.headers.get("X-VZ-Bridge-Token")
            received["body"] = json.loads(self.rfile.read(length).decode("utf-8"))
            payload = json.dumps({"updated": True}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        def log_message(self, _format, *_args):
            return None

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        with tempfile.TemporaryDirectory(prefix="v2133_bridge_") as temp:
            application = VZApplication(VZ_ROOT, Path(temp))
            application.hub_bridge_url = f"http://127.0.0.1:{server.server_address[1]}"
            application.hub_bridge_token = "regression-secret"
            result = application.notify_hub_model_removed({
                "id": "vz_bridge_model",
                "_hub_source": {"project_id": "hub_project", "published": True},
            })
            assert result["synced"] is True
            assert received == {
                "path": "/api/internal/vz/model-removed",
                "token": "regression-secret",
                "body": {"project_id": "hub_project", "model_id": "vz_bridge_model"},
            }
            skipped = application.notify_hub_model_removed({
                "id": "vz_bridge_model",
                "_hub_source": {"project_id": "hub_project", "published": False},
            })
            assert skipped == {"synced": False, "reason": "not_published_hub_model"}
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def test_reconcile_fallback_behavior() -> None:
    source = text("backend/app/main.py")
    tree = ast.parse(source)
    node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "_vz_reconcile_push_catalog")
    module = ast.Module(body=[node], type_ignores=[])
    ast.fix_missing_locations(module)
    calls: list[tuple[str, str, str]] = []

    class FakeStore:
        def list(self):
            return [{"id": "project_a", "vz_push": {"enabled": False, "model_id": "vz_a"}}]

    def fake_json(_path: str):
        return {"models": []}

    def fake_disable(project_id: str, model_id: str, *, reason: str):
        calls.append((project_id, model_id, reason))
        return {"updated": True}

    class FakeLogger:
        def warning(self, *_args, **_kwargs):
            return None

    class FakeVZError(RuntimeError):
        pass

    scope = {
        "object": object,
        "_vz_json": fake_json,
        "_vz_disable_push_from_removed_model": fake_disable,
        "store": FakeStore(),
        "LOGGER": FakeLogger(),
        "VZIntegrationError": FakeVZError,
    }
    exec(compile(module, "<v2133-reconcile>", "exec"), scope)
    result = scope["_vz_reconcile_push_catalog"]([{
        "id": "project_a",
        "vz_push": {"enabled": True, "model_id": "vz_a"},
    }])
    assert calls == [("project_a", "vz_a", "vz_catalog_reconcile")]
    assert result[0]["vz_push"]["enabled"] is False


def test_static_push_library_contracts() -> None:
    main_py = text("backend/app/main.py")
    run_py = text("run.py")
    app_js = text("frontend/app.js")
    app_css = text("frontend/styles.css")
    vz_server = text("integrations/VZ_Studio_V0.3.2.1/vz/server.py")
    engineer_js = text("integrations/VZ_Studio_V0.3.2.1/frontend/engineer.js")
    store_py = text("integrations/VZ_Studio_V0.3.2.1/vz/store.py")

    assert "def _vz_drive_projection_sources" in main_py
    assert "parse_time_series_csv" in main_py and "is_mapping_table_name" in main_py
    assert "def _vz_disable_push_from_removed_model" in main_py
    assert "def _vz_reconcile_push_catalog" in main_py
    assert '@app.post("/api/internal/vz/model-removed")' in main_py
    assert 'X-VZ-Bridge-Token' in main_py and "hmac.compare_digest" in main_py
    status_block = main_py[main_py.index('@app.get("/api/vz-push-status")'):main_py.index('@app.delete("/api/projects/{project_id}"')]
    assert "_vz_reconcile_push_catalog(store.list())" in status_block

    disable_block = main_py[main_py.index("def _vz_set_published"):main_py.index("def _vz_disable_push_from_removed_model")]
    assert '"published": False' in disable_block
    assert 'method="DELETE"' not in disable_block, "Hub关闭推送必须保留VZ本地workspace"

    assert "MUJOCO_STUDIO_VZ_BRIDGE_TOKEN" in run_py
    assert 'env["VZ_HUB_URL"]' in run_py and 'env["VZ_HUB_BRIDGE_TOKEN"]' in run_py

    assert "【已推送】" in app_js and "hub-pushed-label" in app_js and ".hub-pushed-label" in app_css
    assert "'/api/vz-push-status'" in app_js or '"/api/vz-push-status"' in app_js
    assert "}, 2000)" in app_js
    assert "state.projects = state.projects.map" in app_js

    assert "notify_hub_model_removed" in vz_server
    assert "not item.get(\"hub_managed\") or item.get(\"hub_pushed\")" in vz_server
    delete_block = vz_server[vz_server.index('def do_DELETE'):]
    assert "application.notify_hub_model_removed(model)" in delete_block
    assert "Hub 推送开关会同步关闭" in engineer_js

    # Time-series source and workspace remain physically distinct and role-labelled.
    assert '("hub", self.time_series_directory(model_id, create=True), True)' in store_py
    assert '("local", self.time_series_workspace_directory(model_id, create=True), False)' in store_py
    replace_block = store_py[store_py.index("def replace_time_series_archive"):store_py.index("def _simulation_dir")]
    assert "time_series_workspace_directory" not in replace_block


def test_version_and_architecture() -> None:
    assert text("VERSION").strip() == "2.13.3"
    architecture = text("architecture_master_prompt.md")
    assert "第八十九部分：V2.13.3" in architecture
    assert "新增业务 Tool 目录 **0**" in architecture
    assert "time_series_workspace/" in architecture
    assert "Server 当前版本严格更新为 **2.13.3**" in architecture


def main() -> int:
    test_drive_projection_from_hub_sequence()
    test_hub_source_and_vz_workspace_isolation()
    test_vz_engineer_removal_bridge_callback()
    test_reconcile_fallback_behavior()
    test_static_push_library_contracts()
    test_version_and_architecture()
    print("V2.13.3 Hub/VZ push-library + time-series single-source regression: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
