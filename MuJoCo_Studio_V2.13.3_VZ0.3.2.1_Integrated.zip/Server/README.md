# MuJoCo Studio Server 2.13.3




## V2.13.3

V2.13.3 收口 Hub↔VZ 共享推送库状态，不新增业务 Tool、ProjectSpec 权威字段或 Job。Hub→VZ 发布仍复用 `_vz_publish_project()`；VZ 工程师删除一个当前已发布的 Hub 模型时，VZ 先进入自身 trash，再通过运行时 bridge token 回传 Hub，把对应 `metadata.vz_push.enabled` 关闭。Hub 页面每 2 秒只轮询轻量推送状态，并在模型名称行右侧显示 `【已推送】`；如果即时回传不可用，状态接口会对 VZ catalog 做 reconcile，在 VZ 可达且确认模型缺失时修正 stale Hub=true。

Hub 主动关闭推送时只把 VZ `_hub_source.published` 设为 false，VZ 的工程师/用户 `/api/models` 都过滤未发布 Hub 模型，因此共享模型库同步消失，但不会物理删除 VZ 模型目录。这样再次推送可继续复用工程师已经调过的 0%/100%/速度/模式，以及 VZ 自有 `time_series_workspace/`。工程师显式“移除模型”才进入 VZ trash。

驱动设置初始化同时修复历史兼容：当前 `ProjectSpec.drives` 仍是首要权威，发布时会复用 `parse_time_series_csv()` 扫描 Hub `时序库/` 的主 `VZ_TIME_SERIES`，按 drive id 补齐只存在于原模型时序中的 drive；同 id 永远以 ProjectSpec 为准，不写回第二份驱动表。补齐驱动继续使用首次 0%=0、100%=30、速度=30 的 VZ 校准默认。Hub 时序源仍只读同步到 VZ `time_series_library/`，VZ 本地副本仍只在 `time_series_workspace/`，Hub ZIP 刷新不会覆盖本地副本。Server 2.13.3；Client 0.3.9；Viewer schema/controller 4；VZ 0.3.2.1。




## V2.13.2

V2.13.2 继续以 V2.13.1 的“Hub 主时序只读 / VZ 本地副本可编辑 / CSV 只属于时序库”为边界，不新增业务 Tool 或 ProjectSpec 持久字段。Hub→VZ 发布补齐驱动设置身份投射：驱动名称、对应运动副和 exchange drive id 一起同步；首次校准默认 0%=0、100%=30、速度=30，后续 Hub 刷新只更新身份/绑定并保留 VZ 工程师本地校准。Hub 运动段仍不进入工程师驱动设置页，真实 start/duration/travel/mapping 继续只由时序库投射。

VZ 用户页新增多模型联合仿真。右侧模型卡片拖进场景后仍写既有 control graph node；一次 `/api/simulate` 请求内用 runtime-only `scene_composition.py` 把每个源模型子树挂到 synthetic root，并按 `_a/_b/...` 对 Layer、运动副、闭链、驱动和 mesh/asset 做确定性 namespace，同时重写所有 parent/closure/drive/time-series 引用。联合时序按原时间轴并行，源模型 JSON/Hub 时序/VZ 本地副本均不被 composite 回写。用户看板每个模型只显示一个绿色全驱动时序总包络，1 秒主刻度，可切换 `时序1/时序2/...` 并进入用户时序编辑；双击只改 start/travel，速度固定读取工程师 rated speed。工程师与用户详细甘特图均显示 start–end 和累计位置。

二代结果查看删除结果页 MuJoCo View 与“一键导出动画 HTML”，原后台仿真改名“刷新结果”；坐标系高度与 ±游标迁到右侧导航并压缩 axis header，折叠 summary 统一风格。动画导航增加“重新生成”，复用现有 export job 生成/覆盖最新 HTML，但不自动下载。Server 2.13.2；Client 0.3.9；Viewer schema/controller 4；VZ 0.3.2.1。


## V2.13.1

V2.13.1 在 V2.13.0 时序库单一真值链上继续扩展，不新增业务 Tool 或 ProjectSpec 持久字段。VZ 工程师页新增“时序库”导航：Hub 同步主表只读，编辑前必须复制到 VZ `time_series_workspace/`；本地副本可改名、删除，并可在黄色/蓝色双分类甘特图中双击运动段修改起始时间、速度/时长和行程。甘特图显示层复用二代 WEB 甘特图的横/纵缩放、游标、时间排序/倒序、倒放行、驱动显隐/显示名/拖拽顺序、画布平移和放大/还原，仅保存为 VZ 浏览器显示偏好。Hub 再同步只替换 `time_series_library/`，不会覆盖工程师的 VZ 副本。

VZ 用户页下方增加时序分页，可切换当前模型的多个主时序；动画 transport/progress 缩小并把背景透明度降到 0.20，硬点/H 点坐标改为左下角透明白字。二代结果查看增加“自适应坐标系”（按全部驱动补齐同名轴）以及坐标系名称右侧“自适应”（从当前所选曲线识别名称）。

CSV 语义在本版收敛：合并 CSV 是 VZ/二代共用的特殊时序文件，只保存到模型 `时序库/`（并允许浏览器下载一份），不再写交付数据；baseline managed delivery 现为 NX AFU、甘特图 PNG、模型 JSON、动画 HTML 四类，历史 `axes_csv_folder` 仅作兼容识别。Server 2.13.1；Client 0.3.9；Viewer schema/controller 4；VZ 0.3.2.1。

## V2.13.0

V2.13.0 重构 Hub/VZ 用户界面的时序交互，同时严格复用既有结果曲线、驱动 schema、Hub 文件检视与 VZ 发布链：不新增业务 Tool 目录、不新增 ProjectSpec 持久字段。每个模型目录新增物理 `时序库/`，结果查看合并导出 CSV 时同步生成可恢复驱动的主时序表；伴生 mapping 点既嵌入主表，也另存 `<驱动>--<运动段>映射表格.csv`。

驱动设置顶部新增“导入CSV”，本地文件夹与服务端 `项目/模型/时序库` 两种来源统一进入服务端 parser，恢复 `DriveSpec/DriveSegmentSpec` 和 mapping points 后仍通过既有 Editor 保存链提交。Hub 推送 VZ 时用模型级 ZIP 原子同步时序库，后续 Hub 更新/删除会刷新 VZ；VZ 用户控制板按“驱动 → 多运动段色块”展示真实时序，变速段从时序库投射。

VZ 用户页改为中间场景 + 右侧只读模型库双栏；左侧可见 UI 和模型库管理按钮移除。工程师缩略图生成入口移到模型行；快速渲染固定使用更浅的 Classic 场景，用户动画移除中心项目组水印，顶部视图按钮整体缩小。Server 2.13.0；Client 0.3.9；Viewer schema/controller 4；VZ 0.3.2.1。


## V2.12.2.1

V2.12.2.1 只迭代伴生 mapping 数学，不改变 ProjectSpec、Hub、层级建模、数模库或 Client/VZ 协议。V2.12.2 的 2049 点阈值、运行时降采样/低通和 natural-cubic 分支被移除；归一化后的每一个 mapping 节点都保持原 target 值，并统一由全局五次 Minimum-Jerk 曲线连接。

Server motion 与 Native Viewer 复用 `backend/app/domain/mapping_curve.py`；Viewer 离线包携带同一 helper 并在 manifest 校验 SHA-256。浏览器 `mapping_math.js` 实现同一 2×2 block-tridiagonal 求解和五次系数。这样位置仍严格穿过映射节点，同时节点处的 acceleration/jerk 连续，并在严格穿点约束下最小化 integrated squared jerk。1/2 点映射保持常值/线性。

需要注意：若原始映射节点本身含高频测量噪声，在“源头绝对匀速 + 每个原始节点绝对穿过”的条件下，任何插值器都不可能把真实伴生加速度完全压平；本版不伪造平滑数据，也不通过输出限幅制造位置误差。后续若允许位置误差包络或源速度 time-scaling，可在此统一 mapping 核心上继续扩展。

新增持久字段 **0**，新增业务 Tool/API/Job **0**。Server 2.12.2.1；Client 0.3.9；Viewer schema/controller 4；VZ 0.3.2.1。

## V2.12.2

V2.12.2 继续复用现有 ProjectSpec、层级建模、`/meshes/adaptive`、公共 `model-asset-library` 与 Hub 属性链，不新增平行 Tool。高密伴生映射在运行时执行固定空间尺度重采样、轻量去噪和 C2 样条求值，原始 CSV/模型 JSON 点表保持不变；Dynamic 结果曲线优先直接使用 MuJoCo qvel/qacc。

层级“自适应”和“全部数模自适应”继续共用一个自适应入口，现升级为同族双向同步，可新增、删除库中已不存在的同族数模并校正大小写。Hub 刷新后不再自动沿用首个模型或旧属性：没有显式选择时模型属性与数模检视器保持空态；项目文件夹属性只显示名称输入/保存，异步甘特图返回也不得重新显示。公共数模文件夹新增重命名，复用现有资产库资源与 `ModelAssetCopyRequest`，并级联迁移所有当前模型 `mesh_root` 引用。

新增 ProjectSpec/L1/L2/L3/Session/Job 持久字段 **0**，新增 Tool/Job/artifact/tool directory **0**；仅在现有 `model-asset-library/folders` 资源上新增一个 PUT rename API。Client runtime/protocol 仍为 0.3.9，Viewer schema/controller 4、VZ runtime/protocol 0.3.2.1 不变。

## V2.12.1.5

本版修复质量定义主链路。此前 `MeshSpec.mass_kg / LayerSpec.mass_kg` 虽被解析成目标质量，但当 Studio 能读取 mesh 体积时，XML 生成优先写 `density=target_mass/Studio_volume`，MuJoCo 随后又按自己的 mesh shape/volume 重新推导 mass。复杂、非凸、薄壳、开口或体积算法不一致的 CAD 因此可能出现“自定义 kg 很小，实际动力学仍像巨大质量”的现象。

V2.12.1.5 规则：
- `resolved_mass_kg` 来自数模目标质量或 Layer 总质量分配时，MJCF 直接写 `<geom mass="...">`，不再同时写 density；
- 完全没有目标质量时继续走默认 `density=1000 kg/m³`；
- `density_kg_m3` 对 direct-mass 数模只作为 Studio 参考诊断，不再决定最终 kg；
- `model.mass_properties` 增加非持久派生字段 `mass_application = direct_mass | density`；
- Web 质量区显示“最终解析质量 + MJCF 直接质量/默认密度”，原“启用质量 / 逆求密度”改为“显示 / 编辑质量”。

不新增 ProjectSpec 权威字段、Tool、API 或 Job。Server 版本升级为 2.12.1.5；Client 0.3.9、Viewer schema/controller 4、VZ 0.3.2.1 不变。


## V2.12.1.4

本版针对“座椅机构本身动力学正常，但在坐垫上增加物体并通过旋转副连接后承载链塌落”的路径，修正两类问题：

- `JointSpec.point` 在 Studio UI 中是世界坐标点（mm），而 MJCF `joint pos` 必须是所属 body 的局部坐标。本版在 qpos0 参考构型按 Layer 父子静态平移累加世界原点，再执行 `world point - child body world origin` 后写入 MJCF。
- 一个 `LayerSpec` 严格对应一个 MuJoCo body；该 Layer 下所有 `meshes[]` 属于同一刚体，`joints[]` 作用于整个 Layer，而不是某一个 mesh。若附加物体要相对坐垫旋转，应把附加物体建为坐垫的 child Layer，并把 rotation joint 放在 child Layer。
- Dynamic 运动副属性增加“已驱动 / 被动自由度”提示；被动自由度仍遵循 Pure Dynamic 物理语义，不会被隐藏驱动或隐藏锁强行固定。
- 多 mesh Layer 新增运动副时增加刚体作用域确认；服务端 validation 同时给出非阻断 `layer_joint_applies_to_all_meshes` 诊断。
- V2.12.1.3 的 `dynamic_lock_force`、Hub Linux=2 / Windows=4 默认数据根层级保持不变。
- Server 版本升级为 2.12.1.4；Client runtime/protocol 0.3.9、Viewer Schema/Controller 4、VZ 0.3.2.1 不变。


## V2.12.1.3

本版严格复用现有 Hub storage、`DriveSpec`、`param.set`、XML 生成和 Pure Dynamic simulation 链路，没有新增平行业务 Tool/API/Job。

- Hub 未配置时按平台选择默认数据根搜索深度：Linux 向上 2 级、Windows 向上 4 级；已经持久化的管理员设置继续优先。
- `DriveSpec.dynamic_lock_force` 默认 2000。驱动目标静止时作为有界自锁/制动力接合，目标开始变化前自动释放回 `JointSpec.frictionloss`。
- Dynamic 驱动卡片公开“自锁力 / Kp / Kv”参数，其中 rotation 的自锁单位为 N·m，translation/crank 为 N，0 表示关闭附加自锁。
- 版本号从 2.12.1.2 严格更新为 2.12.1.3；Client 0.3.9、VZ 0.3.2.1 协议与运行时不变。


V2.12.1.2 is a focused VZ presentation iteration built on V2.12.1.1. It restores the original second-generation animation HTML center 3D text through the already-vendored watermark mesh pipeline, and compacts the engineer HTML render-settings modal to three inputs per desktop row. The main Server business Tool pool remains unchanged. VZ keeps runtime/protocol 0.3.2.1 and reuses the existing ModelStore, shared Fast/Perfect HTML exporter, watermark mesh renderer and render-settings DOM/CSS seams rather than introducing a parallel rendering/tool stack.

The VZ engineer page now uses one Fast HTML render sample only and reports that single render time; material selection is a screen-space silhouette outline that does not alter PBR material preview; front-view model PNGs are generated/cached from the engineer page in the background and reused by the user URL; the engineer Explorer removes local “new/copy model” actions, exposes Hub-like folders with inline rename, and changes model deletion wording to VZ “remove/unpush”. Front preview orientation follows the second-generation diagram thumbnail convention: X horizontal, Z vertical, Y depth.

V2.11.7 Hub folder properties, editable baseline names and frozen-time behavior remain inherited unchanged, as do V2.11.6 recursive folder counts and V2.11.5 five-artifact baseline/automotive rendering contracts. Client runtime/protocol stays 0.3.9, Viewer bundle schema/controller signature stay 4, and integrated VZ runtime/protocol stays 0.3.2.1. V2.12.1.2 contracts are in `architecture_master_prompt.md` section 80; the V2.12.1.1 startup hotfix remains in section 79 and V2.12.1 rendering contracts remain in section 78.

V2.10.6.1 is retained as a focused hierarchy-diagram closure-coordinate bug fix. It reuses the existing `kinematic_closures[].endpoint_a/endpoint_b.point_mm`, compact diagram closure properties, project commit chain, and XML generator; no new ProjectSpec field, API, Job, or parallel site model is introduced.

When a dashed closure/site edge is selected in diagram mode, its single lower-property coordinate is now labeled **“闭链坐标”**. Editing it writes the same mm vector to both endpoint A and endpoint B, using separate array copies. The existing XML generator then emits both closure sites from those synchronized endpoint values, fixing the prior result where only one site's `pos` changed and the peer site remained `0 0 0`. Root/hierarchy advanced closure properties continue to support independent A/B endpoint editing.

V2.10.5 is retained as the preceding hierarchy-diagram correctness/semantics patch. It reuses the existing DOM/SVG/WebGL editor, `layers[].parent_id`, `layers[].joints[]`, `kinematic_closures[]`, `drives[]`, `uiSet/ui.set`, and the shared thumbnail renderer; no parallel graph model or new runtime node-editor dependency is introduced.

Mesh-library drag-to-canvas now names the created layer from the mesh basename. Parent-link gestures that would make a hierarchy cycle are represented as the existing dashed closure/site edge instead of an illegal tree cycle. Diagram entry no longer writes auto-layout: saved manual `ui.model.diagram.nodes` remains authoritative, while old projects with missing geometry receive only a stable non-persisted grid. `KernelManager.begin_ephemeral_edit()` copies the authoritative `core/ui_state.json` into the isolated temporary edit root before constructing the ephemeral Kernel, so checked-in/baseline edits immediately inherit the last manual diagram layout.

Adding a joint to a selected parent/child line defaults its name to `parent——>child`. Closure passive joints are derived from the closure tree path with the diagram line as the driven/passive unit: if any joint on a path line has a drive binding, that whole line is excluded; manual correction is performed by clicking the closure-path line itself. Any tree edge with a bound drive receives a 36px Figure-1 marker that follows the same cubic Bezier line, exactly twice the existing 18px joint marker. Translation joints use the packaged Figure-2 asset. Closure colors intentionally exclude red and stay in saturated green/blue/purple/orange families; path tree edges remain solid and only the explicit closure/site line is dashed.

For selected diagram nodes, the entire lower property viewport is a mesh-drop target. Multi-mesh chips are approximately doubled in text/padding size. These are UI/projection changes only: no ProjectSpec/L1/L2/L3/Session/Job authoritative field and no new business Tool/API/Job/artifact/tool-directory is added.

V2.10.4 is retained as the Delete/left-button-lasso/density patch: node/tree-edge/closure-edge Delete semantics, left-button blank-pane lasso, expanded multi-mesh property section, 13px diagram titles, 18px edge headers and 3600ms undo feedback remain unchanged.

V2.10.2 is retained as the Hub critical-data hydration and lightweight diagram interaction patch: baseline-derived projects without a local archive show current critical data immediately, and the diagram uses compact properties, four handles, cubic Bezier bending, middle-button pan and Ctrl+wheel zoom.

V2.10.1 is retained as the hierarchy-diagram correctness/layout patch. Inactive layers lock diagram-side mutation paths and auto-arrange packs the hierarchy using each node’s actual saved width/height, depth-column maximum widths and recursive subtree heights.

V2.10.0 introduced the diagram-canvas projection to hierarchy modeling. The tree and diagram edit the same `layers[].parent_id`, child-layer joints and `kinematic_closures`; diagram-only geometry and body-mesh preview choices stay in existing `ui.model.*`.

V2.9.8 integrates VZ Studio V0.3.2.1 into MuJoCoHub: the Hub adds “工程师界面” and per-model “推送模型”, while the integrated VZ engineer UI removes hierarchy modeling and redundant modeling/import/export controls. Drive settings occupy the former hierarchy-modeling workspace; renamed VZ models retain the original Hub model name, and high-quality render defaults to 120000 faces per mesh.

V2.9.7.1 is a focused lifecycle/Hub patch on the V2.9.7 architecture. The Hub recycle bin now supports checkbox multi-selection, select-all for the current filtered list, and irreversible deletion of selected recycle entries. Every authoritative check-in now creates an archive version through the existing lifecycle/Kernel archive path; manual check-in no longer asks whether archiving is needed, but still accepts an optional archive log. The top redo control is displayed as “前进” while the internal redo command and shortcuts remain unchanged.

V2.9.7 retained the Hub and hierarchy-modeling workflow without adding parallel project state. The Hub starts with all nested folders collapsed, provides a one-click collapse/expand-all control, and searches projects across every category level. JSON import and complete ZIP import both target the currently selected Hub folder.

The new complete project bundle (`mujoco_studio_project_bundle` v1) exports the canonical model JSON together with mesh assets, delivery data and applicable archive logs. Checked-in public assets are first copied to an isolated verified snapshot so export never writes into the source asset library; import creates a conflict-free public asset folder in the selected category (including root `None`). Baselines keep their immutable private mesh snapshot and delivery data while the imported working copy uses the newly injected public asset folder.

Hierarchy modeling now resets mesh and drive lists to two-column layout whenever the Editor is re-entered, only shows joint range inputs after range limiting is enabled, projects reversed vectors with visible negative signs while retaining the canonical stored axis, and replaces the Model A/B placeholder with “全部数模自适应” using the existing adaptive-mesh endpoint.

Formal integrated deliveries continue to include both `Client/` and `Server/`. Client V0.3.9 has been audited for V2.9.7.1; Viewer bundle schema/controller signature are unchanged.

The V2.9.6.6 path/performance fixes retained in V2.9.7.1 cover Windows Viewer/generated-XML loading in Unicode project directories and removes the synchronous full-catalog refresh from Hub model reclassification/name refresh. Local Viewer subprocesses now use workspace-relative XML/data arguments when possible, while in-process MuJoCo loads reuse the existing Unicode/VFS loader. Same-filesystem delivery moves use an atomic directory rename with the existing verified-copy path retained as the fallback.

V2.9.6.5 fixes custom-variable division expressions such as `40/tran*tz` and makes distance-pair names a forbidden legacy alias in the custom-variable pool. V21.5 imports now remove measurement-pair variables before they can enter Studio runtime expressions.

V2.9.6.4 adds V21.5-compatible external motion CSV import to Studio 2.x and extends the V21.5 ↔ Studio complete-model JSON contract so `external_csv` motion remains self-contained and portable. Imported CSV data is stored as an embedded time/position point table; source file paths are provenance only and are not required at runtime or after moving the model to another machine.

V2.9.6.2 remains the rapid-edit consistency hotfix built on V2.9.6.1. V2.9.6.1 is the Viewer Gantt synchronization hotfix built on V2.9.6. V2.9.6 restructures model version history around two user-facing kinds only: **存档版本** and **基线版本**. V2.9.6 originally allowed manual check-in without an archive; V2.9.7.1 supersedes that choice so every check-in creates one archive version. Automatic check-in paths keep their safety archive, and check-out itself still does not create a lifecycle history version.

Creating a baseline still freezes the independent baseline model exactly as before, and now also appends one red-labeled baseline entry to the source model's version history. The source model is not rewritten or rolled back and no extra ordinary archive is created. The unified history remains capped by the existing `MAX_ARCHIVE_VERSIONS` / `MUJOCO_STUDIO_MAX_VERSIONS` value, default 20.

Every source-model history row now exposes “删除存档” immediately before “切出为独立模型”. Deleting a baseline history row removes only that source-history snapshot/metadata; it does **not** delete the actual frozen baseline model.

Architecture boundary:

## Retained V2.9.6.6 Windows Viewer path / Hub drag responsiveness

- Generated XML is no longer loaded by backend simulation/optimization/export code through ad-hoc absolute `MjModel.from_xml_path(...)` calls. All such loads reuse the existing Viewer Unicode/VFS compatibility loader, preventing Windows `ParseXML: Error opening file` failures caused by Chinese/UTF-8 project directories.
- The local Viewer subprocess runs with its output workspace as `cwd` and receives workspace-relative scene/drives/Gantt/trajectory arguments whenever the paths share that workspace. Cross-volume paths retain a safe absolute fallback.
- Reclassification keeps the existing `project.reclassify`/ProjectStore flow. Delivery directories now use same-filesystem `Path.replace()` first and fall back to the prior verified copy+hash path only when rename is unavailable.
- Hub drag/drop applies project category, managed name and model-type counts immediately, rolls back on API failure, and merges the returned authoritative ProjectSpec on success instead of synchronously rescanning the full project catalog. Hub name saves likewise merge the authoritative response directly.
- New ProjectSpec/L1/L2/L3/Job fields: 0. New business Tool/API/Job/artifact/tool-directory: 0.

## V2.9.6.5 expression / custom-variable hygiene

- Plain custom variables are now recognized after `/` when the slash is the arithmetic division operator, so expressions such as `40/tran*tz` resolve correctly. Slash-qualified drive variables such as `drive/duration1` retain their existing compatibility semantics.
- Distance-pair names are measurement identifiers, not user parameters. If a custom-variable name matches a distance-pair name after trimming whitespace, it is removed from `project.variables`.
- The invariant is enforced centrally by `ProjectSpec` and explicitly at both V21.5 complete-model and modeling-exchange import boundaries, so future project replacement/import paths inherit the same cleanup rule.
- `scripts/self_check.py` permanently covers both the division-expression regression and the distance-pair-variable cleanup invariant.

## V2.9.6.4 external CSV drive / model JSON interoperability

- Editor `external_csv` segments can upload a V21.5-style two-column CSV through the existing project-edit lifecycle.
- CSV decoding/delimiter handling follows V21.5: UTF-8/GBK/GB18030 and comma/semicolon/Tab/whitespace tables are supported.
- Position input is embedded directly; velocity input is trapezoid-integrated to position; acceleration input is integrated to velocity and then position, matching V21.5 semantics.
- `segment.points` is authoritative for runtime and export. Legacy `csv_path` is only a fallback for older projects and is cleared for new imports.
- Complete model JSON now supports `external_csv` in both V21.5 → Studio and Studio → V21.5 conversion, including embedded values, header/source metric, and portable source basename provenance.
- External motion playback uses the CSV sample times with linear interpolation and does not apply S-curve easing.


## V2.9.6.2 rapid-edit consistency

- Late background `/state` mirrors are revision-fenced and cannot overwrite edits made while the request is in flight.
- The 400 ms interaction debounce remains a coalescing window; it does not choose an older state over a newer one.
- Direct add buttons for layers, drives, distance pairs, variables, optimization ranges, and result axes now all enter the automatic commit path.
- Client runtime/protocol remains V0.3.9 / controller signature 4.

## V2.9.6.1 Viewer Gantt synchronization

- Linux/remote Client Viewer bundles now carry the exact `latest_gantt.png` + `latest_gantt.json` generated by the Web Gantt popup before launch.
- Client runtime V0.3.9 passes the bundled cache directory to the server-supplied Viewer controller and verifies both cache files by SHA-256.
- Native Viewer polls the authoritative cache source dynamically, switches away from compatibility fallback when the real cache appears, and reloads on PNG or JSON changes.
- Animation HTML continues to use the same project popup cache as before; Viewer and HTML therefore share one Gantt visual truth source.

- Server: 2.13.3
- Client runtime: 0.3.9
- Minimum compatible Client protocol for Viewer launch: 0.3.9
- Archive retention: default 20 unified source-history entries (archive + baseline); every check-in archives automatically, check-out creates no version
- Hub inspector: desktop inspector max width ~368px for a 245px model-property column; compact delivery/assets/archive projections
- Delivery generation: managed delivery assets are unique by **type** (model JSON, Gantt preview, NX AFU, animation HTML, coordinate-system CSV folder); a newer same-type output replaces/reconciles the older path even when its filename differs
- Coordinate-system batch CSV: separate files or one combined CSV; persistent non-baseline Editor batch export also refreshes the managed CSV-folder delivery
- Recycle bin: admin/engineer only, 7-day retention, conflict-safe restore, checkbox multi-select and irreversible selected deletion; normal user deletion is trash-move while internal rollback keeps hard-delete semantics
- Copy version: explicit `model_name` is authoritative; duplicate names fail with 409; copied models reuse the source public model-asset folder, while baseline `/fork` creates a newly named one
- Adaptive mesh: only same-family `.001`-`.009` ancillary files are forced to opacity 0; `.010+` keep their opacity
- Adaptive drives: exact joint name is used as drive name and the drive binds to that joint
- Hub root projection: internal `None` sentinel is hidden from the model-type tree; legacy `未分类` metadata/directory aliases are normalized
- Model-type drag: hierarchy + sibling ordering via existing move API; drag handle is leftmost, fold button immediately to its right; confirmation before write; reload after success
- Reclassify naming: target leaf prefix, no date-based rename
- Baseline naming: `<source-name>_00i`; timestamp remains property data
- User export policy: Windows and Linux both use direct browser download without file/directory path pickers
- Checked-in temporary Editor: darker gray non-blocking visual mask
- Editor check-in sync: opener/localStorage notification + Hub cache invalidation + authoritative refetch
- Mesh / drive layout: reset to two-column on each Editor entry; single-column toggles are session-only
- Hub attribute cache: page-memory, 10-minute TTL, force refresh after writes
- Drive variable canonical form: `drive/starttime1` slash/lowercase

- Model asset portability: exact case first; one unique case-insensitive on-disk match is accepted; ambiguous duplicates are never guessed.

## V2.10.6.1 patch note

This patch only fixes hierarchy-diagram icon resources and references: edge drives now use a dedicated drive badge asset instead of reusing the rotation-joint badge, and translation joints use the user-specified replacement icon. No ProjectSpec, API, or Job behavior changes are introduced.
