V2.13.3 重点：Hub/VZ 模型推送库状态打通。VZ 工程师显式移除 Hub 模型会通过本地 bridge 回传并实时关闭 Hub 推送开关；Hub 关闭推送会让该模型从 VZ 工程师/用户模型库同步隐藏，同时保留 VZ 本地校准和时序 workspace 供再次推送复用。Hub 模型列表对真实推送状态右平齐显示【已推送】，并以 2 秒轻量状态轮询 + 目录对账修正 stale 状态。VZ 工程师驱动设置发布时以 ProjectSpec 驱动为主，并从 Hub 时序库补齐仍只存在于原模型时序中的驱动，继续使用 0%=0、100%=30、速度=30 的首次校准默认。时序链继续保持 Hub 时序源只读同步到 VZ time_series_library，VZ 自有 time_series_workspace 可编辑且 Hub 刷新不覆盖。

V2.13.2 重点：Hub→VZ 推送现在同步驱动名称与绑定运动副，首次校准默认 0%=0、100%=30、速度=30，后续 Hub 刷新保留 VZ 本地校准。VZ 用户页支持把右侧多个模型拖入同一场景做联合仿真：运行时统一挂到 synthetic root，并对层级/运动副/闭链/驱动/资产做 _a/_b/... 命名空间与引用重映射；场景下方按“每模型一行”显示当前时序总包络并可进入用户时序编辑。工程师 WEB 时序块补齐启停时间和累计位置信息。二代结果查看删除 MuJoCo View/一键导出动画 HTML，后台仿真改名“刷新结果”，坐标系高度/游标移入右侧导航，动画页新增“重新生成”（覆盖最新 HTML，不自动下载）。

V2.13.1 重点：VZ 工程师新增“时序库”页，Hub 同步时序保持只读，复制为 VZ 本地副本后才能改名/删除/双击编辑甘特色块；黄色表示匀速/缓起缓停，蓝色表示映射等变速，并复用二代 WEB 甘特图的缩放、游标、排序/倒序、倒放、驱动显隐/显示名/拖拽顺序、画布平移和放大/还原。VZ 用户页增加随当前查看模型切换的时序分页，动画底部进度/控制 UI 缩小并降到 α=0.20，硬点/H 点坐标改为左下角透明白字。二代结果查看新增按驱动补齐同名坐标系与单坐标系名称“自适应”。CSV 从交付数据彻底剥离：合并 CSV 只属于模型时序库，baseline 当前交付为 NX/甘特图/模型 JSON/动画 HTML 四类。

V2.13.0 重点：Hub 每个模型新增“时序库”，结果合并导出同步生成可恢复驱动/运动段/mapping 的主 CSV 与独立映射表；驱动设置可从本地文件夹或服务端时序库导入。Hub 与 VZ 原子同步时序库，VZ 用户页改为中间场景/真实分段控制板 + 右侧只读模型库双栏，工程师缩略图入口移入模型行；快速渲染默认使用更浅的 Classic，并取消用户动画中心项目组水印。

V2.12.2.1 重点：伴生映射统一为严格穿过全部节点的全局五次 Minimum-Jerk 插值；移除 2049 点密度分叉和运行时低通，Server / Browser / Native Viewer 使用一致数学，Viewer bundle 携带共享映射核心并校验。

V2.12.2 重点：高密伴生映射运行时稳定化；层级/全部数模自适应升级为同族增删双向同步；Hub 刷新空选择不再显示旧模型属性或无限加载；项目文件夹属性只保留名称；公共数模文件夹支持重命名并级联更新模型引用。

V2.12.1.5 重点：修复质量目标在 Studio 体积→density→MuJoCo 体积链路中再次漂移的问题。数模/层级已经解析出的目标 kg 现在直接写入 MJCF geom mass；只有没有目标质量时才走默认 density。
质量 UI 显示最终解析质量和实际 MJCF 应用方式，并把原“启用质量”改为“显示 / 编辑质量”。

V2.12.1.4 重点：修正旋转副“世界坐标点”写入 MJCF 时未转换为 child body 局部坐标的问题；明确一个 Layer=一个刚体，Layer 内多个数模共用该 Layer 的运动副。
Dynamic UI 显示已驱动/被动自由度；多数模 Layer 新增运动副前会确认其作用于整个刚体。V2.12.1.3 的电机静止自锁与 Hub Windows/Linux 默认层级继续保留。

V2.12.1.3 重点：Hub 数据根自动按 Linux=向上2级 / Windows=向上4级选择默认值；Pure Dynamic 驱动新增默认 2000 N/N·m 的静止自锁力，并在驱动面板提供自锁/Kp/Kv 修改入口。
驱动目标开始运动时附加自锁自动释放；既有显式 Hub 路径配置继续优先。

MuJoCo Studio V2.13.3 + VZ0.3.2.1 Integrated Clean Package

目录
- Server/  : MuJoCo Studio Server 2.13.3
- Client/  : 轻量 Client runtime/protocol 0.3.9（WindowsFix 分发标签）
- Server/integrations/VZ_Studio_V0.3.2.1/ : 集成工程师/用户站点



V2.12.1.2 VZ 二代动画立体字与渲染设置紧凑化
- 恢复 VZ 动画 HTML 中原二代软件的中间 3D 立体字“C项目-时序仿真组”；直接复用现有 watermark mesh，不新增文字渲染引擎。
- Classic / Bright Studio / Automotive Interior，Fast / Perfect 共用同一立体字渲染路径。
- HTML 渲染设置桌面端改为每行 3 个输入/选择控件，并收紧 section/grid/input 纵向间距。
- Server 统一版本为 2.12.1.2；Client 仍为 0.3.9，VZ runtime/protocol 仍为 0.3.2.1。

V2.12.1.1 VZ 离线动画启动热修复
- 修复 V2.12.1 快速渲染/高质量渲染一直停留在“正在载入离线动画…”的问题。
- 根因是 V2.12.1 的可配置平行光引用了未输出到 HTML 模板的 KEY_LIGHT_DIR / KEY_LIGHT_COLOR 初始化常量。
- 补齐共享平行光初始化，并增加启动错误可见提示；不新增业务工具/API/持久字段。
- Server 统一版本为 2.12.1.1；Client 仍为 0.3.9，VZ runtime/protocol 仍为 0.3.2.1。

V2.11.7 Hub 项目文件夹属性、基线名称编辑与冻结时间
- 点击项目文件夹后，右侧只显示“项目文件夹属性”和可编辑文件夹名称；不再显示文件夹基线清单、交付数据、甘特图或模型 Inspector。
- 打基线时可同时编辑基线模型名称与自动预填的最新存档日志；同一文件夹重名自动追加 `_001`、`_002`…。
- 已冻结 baseline 可在 Hub 中继续编辑模型名称，但 Server 只允许名称变化，冻结配置/数模/交付不解冻；source unified-history 的 baseline_name 同步更新。
- baseline 列表改为加粗、放大的“冻结时间”，使用 baseline_created_at；改名不会改变冻结时间或 latest-baseline 穿透排序。
- architecture_master_prompt.md 新增第 76 节；Server 统一版本为 2.11.7，Client runtime/protocol 仍为 0.3.9，VZ runtime/protocol 仍为 0.3.2.1。

V2.11.5 基线交付五件套与汽车内饰高质量渲染（继承）

- 结果查看的批量 CSV 在完成本地下载的同时，会自动覆盖推送到项目“坐标系 CSV 文件夹”交付数据；本地可选分文件/合并表，交付端始终保持每坐标系一个 CSV 的稳定目录结构。
- 创建基线前要求最新仿真结果与当前模型/数模指纹一致，并重新生成覆盖 CSV 文件夹、NX AFU 脚本、甘特图 PNG、模型 JSON；动画 HTML 复用已有交付文件。
- 若动画 HTML 缺失，Hub 会先弹窗提示，再复用现有后台动画导出 Job 自动生成并推送，完成后自动继续打基线。最终 5 类交付数据完整才冻结基线。
- 甘特图优先冻结浏览器刚刚重新生成的完整 Result/Gantt PNG；浏览器缓存不可用时复用现有 Viewer legacy renderer 进行服务端兼容重绘。
- VZ 高质量渲染新增 Automotive Interior 场景预设：程序化顶棚/前挡/侧窗反射卡、roughness-aware IBL、specular occlusion、clearcoat、粗糙非金属轻量 sheen、Perfect 5x5 PCF 软阴影和 neutral/PBR-neutral 风格高光压缩；Fast 档继续使用原低成本 ACES + 3x3 PCF。
- 不引入 three.js/Babylon/drei/model-viewer 运行时；只借鉴其高 star 产品可视化设计思想并扩展现有 VZ shader/render_scene seam。
- architecture_master_prompt.md 新增第 74 节；新增 ProjectSpec/L1/L2/L3/Session/Job/VZ 持久字段 0，新增业务 Tool/API/Job/artifact 0。Client runtime/protocol 仍为 0.3.9，Viewer schema/signature 仍为 4。

V2.11.4 材质选择边界框与 Viewer 甘特图软依赖（继承）

- 工程师材质管理弹窗双击选中数模后，只绘制独立 3D 边界高亮框；PBR shader 不因选中状态改变材质本体。
- 打开 MuJoCo Viewer 时，甘特图缓存预载失败只提示并继续启动；普通 Viewer 的 Gantt 仍是 soft dependency。

V2.11.3.1 Viewer 映射伴生电机双向联动修复

- 映射 source/follower 不再作为两个独立 manual DOF：拖动任意成员都会归一到 canonical root source；拖 follower 时复用既有 mapping 反解，随后从 root 正向投射全部伴生成员。
- 整个 mapping family 同帧进入 manual/decoupled。即使 source 是没有 joint_id 的虚拟驱动，第一次拖 source 时有真实 joint 的 follower 也会立即写入 qpos，STL/关节无需先“碰一下伴生驱动”才能响应。
- source/follower slider 双向联动：当前拖动 slider 继续由 Tk 原生跟手，其他 family slider 使用既有 30 Hz 有界投射同步；松手后所有 slider 与最终 mapping contribution 一致。
- “重新耦合”和兼容旧 remote decoupled 状态都按整个 mapping family 归一化，避免半耦合状态。
- V2.11.3 的 native-drag/latest-value coalescing 和运动学闭链每帧 projection 全部保留；执行顺序仍是 trajectory → mapping/manual qpos → closure solve → mj_forward。
- architecture_master_prompt.md 新增第 72 节；新增 ProjectSpec/L1/L2/L3/Session/Job/VZ 持久字段 0 个，业务 Tool/API/Job/artifact 0 个。Client runtime/protocol 仍为 0.3.9，Viewer bundle schema/controller signature 仍为 4。

V2.11.3 Viewer 电机低延时与运动学闭链更新（继承）

- 电机解耦滑块采用 native-drag + latest-value coalescing：不再让每个 mouse-motion 进入 Python callback，render loop 每帧最多读取一次 active slider 最新值；未恢复 60Hz 全 slider 回写。
- 运动学模式下 enabled 闭链在每个可见 frame 的 trajectory/manual qpos 写入后统一投影，再执行最终 mj_forward；时间轴和电机控制都保持闭链。
- 闭链邻近帧 warm-start；大幅 seek 重置；奇异/不可达时保持上一有效完整闭链姿态。
- 远端 Viewer bundle 继续携带 Server 同源 kinematic_closure.py；Client runtime 不需升级。

V2.11.2 低风险复核更新（继承 V2.11.1 全部需求）

- 二次复核发现并修复 Viewer 结果图仍使用固定 241 点 linspace 的旁路，现与仿真 timestep 严格同网格。
- 修复 VZ modeling-info GET 查询引用未初始化 parsed 的 400；单点结果导数不再触发 numpy.gradient 异常。
- architecture_master_prompt.md 新增第 70 节：需求/工程双轴复核、红绿反馈闭环、deep-module/locality/seam/YAGNI 与最小纵向修补。
1. 工程师 Explorer 与统一数据入口
   - 工程师左栏宽度由 188px 提升为 376px，项目/模型与两级文件夹统一为单列 Explorer；复用既有 folder CRUD / model move API，支持展开折叠、重命名、删除、模型拖放分类。
   - 管理员数据地址仍复用 V2.11.0 的 V2_projec 解析/探测/保存合同；常用设置压缩为一行，Server 路径/候选路径等低频信息收进“诊断信息”，不新增第二套数据根。

2. 工程师场景参数与渲染 UI
   - 快速渲染单 mesh 默认面数提高到 120000；前后端 fallback 同步。
   - 渲染完成后不再在下方输出“渲染已生成”JSON 状态栏。
   - 场景坐标只保留硬点/H 点两个输入框，与模型名称同一行；支持 Point(x,y,z)、英文逗号和中文逗号，继续保存到既有 scene_coordinates 数组。

3. 用户场景看板 UI
   - 可见控制画布取消，中央改为“上方动画 HTML + 可拖动水平分隔条 + 下方控制看板”；动画 iframe 的既有右上角按钮/面板继续由原 HTML 保留。
   - 右侧模型库改为一级/二级文件夹横向切换，主体纵向展示更大的正视渲染缩略图；缩略图可拖入中央场景。
   - 下方控制看板按模型显示名称、橙色时间范围示意块和“编辑”入口；本版只重塑交互，继续复用 control_graph nodes 作为场景成员/顺序兼容存储，不宣称新增多模型求解能力。

4. 严格结果时间采样
   - 结果时间轴改为 start_time + n*timestep 的整数 tick 网格；步长 0.01 时相邻结果采样严格为 0.01 s。
   - 运动段边界不再插入结果时间轴，也不再额外加入偏离步长的 end_time；优化器若需要边界探针，显式使用 include_boundaries=True，不污染结果查看采样。

架构与版本
- 主 ProjectSpec/L1/L2/L3/Session/Job 新增权威字段：0。
- 主业务 Tool/API/Job 新增：0；优先复用 ProjectStore、VZ ModelStore、model_library/control_graph、现有场景坐标和仿真时间网格。
- 当前新增 Viewer 合同见 Server/architecture_master_prompt.md 第 71 节；第 69/70 节继续作为 V2.11.1/2 产品与低风险复核基线。
- Server runtime/package/frontend cache-buster/Viewer/动画导出版本：2.11.7。
- Client runtime/protocol：0.3.9；集成 VZ runtime/protocol：0.3.2.1。

完整版本历史见 CHANGELOG.md；交付说明见 Server/DELIVERY_MANIFEST.md。
