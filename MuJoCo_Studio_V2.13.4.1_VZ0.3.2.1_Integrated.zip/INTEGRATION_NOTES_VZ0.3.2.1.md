# MuJoCo Studio V2.9.8 × VZ Studio V0.3.2.1 Integration

## Integrated behavior

- MuJoCoHub is the source/publish platform. In **模型属性**, the **推送模型** switch controls whether a Hub-pushed model is visible in the VZ user model library.
- Hub top bar adds **工程师界面** and opens the integrated VZ engineer page on the same server host, port `8877`.
- VZ engineer page removes hierarchy-modeling navigation and user-facing controls for MJCF generation, MuJoCo simulation, model-file upload/asset management, missing-reference repair, and modeling-info import/export. **驱动设置** occupies the original modeling workspace.
- Kept: model name, material settings, HTML render settings, fast render, high-quality render, save, VZ model library.
- VZ model list and client selector preserve the Hub source/original model name (`原模型`) even after the VZ model is renamed.
- High-quality render default `perfect_max_faces_per_mesh` is `120000`; fast-render defaults remain unchanged.

## Service topology

- MuJoCo Studio: default `0.0.0.0:8765`.
- Integrated VZ Studio: default `0.0.0.0:8877`, started automatically by `Server/run.py`. If a VZ health endpoint is already available on port 8877, MuJoCo Studio reuses it.
- Override the VZ port with `VZ_PORT`; disable child-service startup with `MUJOCO_STUDIO_VZ_ENABLED=0`.
- VZ project storage retains VZ 0.3.2.1 behavior (`VZ_PROJECT_ROOT` override; Windows default `E:/VZ_project`).

## Publish semantics

The first ON action imports the Hub modeling exchange and referenced STL/OBJ assets into VZ and records immutable source identity (`project_id`, original Hub name). Turning OFF changes publication visibility without deleting the VZ engineer-side copy, so drive/render/material tuning is preserved. Turning ON again republishes that existing VZ model.
