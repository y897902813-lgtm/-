# MuJoCo Studio 轻量客户端 V0.3.9（V2.11.7 配套）

配套 Server V2.11.7；Client 运行版本仍为 V0.3.9 / WindowsFix。V2.11.7 的项目文件夹属性、基线名称编辑/去重与冻结时间展示全部位于 Server/Web 现有 seam，不改变 Client-native Viewer 协议：bundle schema 仍为 4、controller signature 仍为 4、`run_viewer()` 调用参数不变。V2.11.6 的目录穿透、基线日志预填和企微封存继续继承，因此无需提升 Client runtime；V2.11.3.x 的低延时电机、闭链与 mapping-family 行为继续由 Server-supplied controller 获得。

## 服务端地址配置

- 服务端 IP 直接位于 `main.py` 最前部常用网络配置区：`SERVER_IP = "10.13.90.107"`。
- 默认服务端端口为 `8765`，`SERVER_URL` 由 `SERVER_IP` 与 `SERVER_PORT` 组合生成。通常更换服务器时只需修改 `SERVER_IP`。
- `client_config.json` 只保存 `mesh_path` 等客户端本地运行状态，不再保存 `server_url`，从而避免旧配置覆盖 `main.py` 顶部地址。
- Client 自身仍只监听 `127.0.0.1:8766`；服务端 origin 校验继续生效。

## Viewer 状态与 runtime 生命周期

- Viewer 子进程继续使用 `python -u`，stdout 逐行读取。
- `ViewerRegistry` 保存当前 Client 进程创建且仍存活的 Viewer，并可返回其受保护 bundle 目录。
- Client 启动时仅白名单清扫 `RUNTIME_ROOT` 下超 TTL 的 `viewer_*` 目录与 `mesh_sync_*.zip`；日志、配置、页面、符号链接和其它文件不参与清扫。
- TTL 默认 24 小时，可由 `MUJOCO_STUDIO_CLIENT_ORPHAN_TTL_HOURS` 配置。
- `runner.py` 在 Viewer 存活期间每 60 秒刷新 bundle 目录 mtime。这样 Client 自身重启、内存 Registry 丢失后，仍在运行的 detached Viewer 不会仅因“新 Registry 不认识它”而被当作超期孤儿删除。
- Viewer 正常退出仍删除自身 bundle；启动失败仍沿用既有清理路径。
- `log_tail` 保留用于诊断与旧服务端兼容；Viewer Bundle schema 1/2/3/4 保持兼容，轨迹播放与数模资产绑定语义不变。

运行方式与 V0.3.6 相同；依赖仍以项目内 requirements / 启动脚本为准。
