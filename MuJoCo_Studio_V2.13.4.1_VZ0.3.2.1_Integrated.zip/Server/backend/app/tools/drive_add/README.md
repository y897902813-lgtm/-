# drive.add

Adds a typed drive and one default segment bound to an existing joint ID.
