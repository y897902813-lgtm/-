# ui.set

Writes only the `ui.*` subtree so themes and layouts use the same event path as domain changes.
