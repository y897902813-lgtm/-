# project.replace

Compatibility write tool for the existing full-project Web editor and JSON import.
The payload is validated as `ProjectSpec` before atomic persistence.
