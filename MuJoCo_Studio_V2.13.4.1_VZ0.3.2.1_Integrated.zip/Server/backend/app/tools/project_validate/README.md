# project.validate

Read-only structural, formula and optional mesh-file validation.
