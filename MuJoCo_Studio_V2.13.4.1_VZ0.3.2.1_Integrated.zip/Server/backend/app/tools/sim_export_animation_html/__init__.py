"""Self-describing offline animation HTML export tool."""

