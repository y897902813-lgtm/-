# project.reclassify

拖放模型到项目文件夹时，复用同一个写工具原子更新分类与模型名称。V1.1.0 的 Hub 调用按目标文件夹末级名称增加前缀（例如 `QA_dasifbiaw`），不再为了重新分类生成日期型名称；`version_date` / `version_index` 仅保留为旧调用兼容参数。
