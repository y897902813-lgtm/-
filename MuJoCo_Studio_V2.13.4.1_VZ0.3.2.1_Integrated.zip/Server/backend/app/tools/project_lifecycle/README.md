# project.lifecycle

通过统一命令与事件流执行项目签入、签出。基线状态不可切换。
