"""Project lifecycle command tool."""
