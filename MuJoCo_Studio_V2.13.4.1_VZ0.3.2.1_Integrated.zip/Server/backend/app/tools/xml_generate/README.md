# xml.generate

Read-only generation of MuJoCo XML and drive JSON as content-addressed artifacts.
