# model.mass_properties

只读工具。读取项目状态树中的层级/数模质量，按封闭网格体积逆求密度，并返回 XML 与 Viewer 共用的解析质量。
