"""Model mass-property query tool."""
