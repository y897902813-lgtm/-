# result.get_latest

读取当前项目最新的结构化仿真结果，不修改项目状态。
