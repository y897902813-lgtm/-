# param.set

Writes one existing stable state path. Project identity fields are read-only.
Use dry-run before confirmation; every successful run emits a semantic event.
