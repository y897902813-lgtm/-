# layer.add

Adds a typed layer under `root` or an existing parent layer ID.
