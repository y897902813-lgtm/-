"""MuJoCo Studio backend package."""

__version__ = "2.13.4.1"
