"""Pure domain services used by HTTP, tests, UI and agents."""
