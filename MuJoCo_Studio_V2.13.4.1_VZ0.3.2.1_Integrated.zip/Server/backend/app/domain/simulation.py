from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from typing import Callable

import numpy as np

from .models import ProjectSpec, SimulationSettings
from .motion import ResolvedSegment, drive_positions, joint_positions, resolve_schedule
from .crank import crank_displacement, crank_meta


ProgressCallback = Callable[[float, str], None]


def load_qpos_trajectory(path: str | Path, *, expected_nq: int | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Load and validate the authoritative Viewer/HTML qpos trajectory artifact."""
    trajectory_path = Path(path)
    with np.load(trajectory_path, allow_pickle=False) as trajectory:
        times = np.asarray(trajectory["times"], dtype=float)
        qpos = np.asarray(trajectory["qpos"], dtype=float)
    if times.ndim != 1 or qpos.ndim != 2 or len(times) != len(qpos):
        raise ValueError("trajectory.npz 的 times/qpos 维度或帧数不一致")
    if expected_nq is not None and qpos.shape[1] != int(expected_nq):
        raise ValueError(
            f"trajectory.npz 与当前模型 nq 不一致：trajectory={qpos.shape[1]}, model={int(expected_nq)}"
        )
    if len(times) > 1 and np.any(np.diff(times) < 0.0):
        raise ValueError("trajectory.npz 的 times 必须单调递增")
    return times, qpos


def sample_qpos_trajectory(times: np.ndarray, qpos: np.ndarray, time_s: float) -> np.ndarray | None:
    """Sample qpos exactly like the native Viewer: clamp ends, linearly interpolate inside."""
    sample_times = np.asarray(times, dtype=float).reshape(-1)
    frames = np.asarray(qpos, dtype=float)
    if frames.ndim != 2 or not len(sample_times) or len(sample_times) != len(frames):
        return None
    if float(time_s) <= float(sample_times[0]):
        return frames[0].copy()
    if float(time_s) >= float(sample_times[-1]):
        return frames[-1].copy()
    right = int(np.searchsorted(sample_times, float(time_s), side="right"))
    left = max(0, right - 1)
    right = min(right, len(sample_times) - 1)
    t0, t1 = float(sample_times[left]), float(sample_times[right])
    if right == left or t1 <= t0:
        return frames[left].copy()
    alpha = (float(time_s) - t0) / (t1 - t0)
    return frames[left] * (1.0 - alpha) + frames[right] * alpha


def build_drive_curves(
    project: ProjectSpec, schedule: list[ResolvedSegment], times: np.ndarray,
) -> dict[str, dict[str, object]]:
    """Return commanded drive displacement curves in Studio display units."""
    joint_lookup = {joint.id: joint for layer in project.layers for joint in layer.joints}
    schedule_by_drive: dict[str, list[ResolvedSegment]] = {}
    for segment in schedule:
        schedule_by_drive.setdefault(segment.drive_id, []).append(segment)
    payload: dict[str, dict[str, object]] = {}
    for drive in project.drives:
        segments = schedule_by_drive.get(drive.id, [])
        if not drive.enabled or not segments:
            continue
        joint = joint_lookup.get(drive.joint_id)
        angular = joint is not None and joint.type != "translation"
        payload[drive.id] = {
            "name": drive.name,
            "joint_id": drive.joint_id,
            "unit": "value" if joint is None else ("deg" if angular else "mm"),
            "position": [drive_positions(schedule, float(time_s)).get(drive.id, 0.0) for time_s in times],
        }
    return payload


def build_time_grid(
    settings: SimulationSettings,
    boundaries: list[float] | None = None,
    *,
    include_boundaries: bool = False,
) -> np.ndarray:
    """Build the canonical sampling grid for simulation results.

    Result samples are integer timestep ticks from ``start_time`` and never gain an
    off-grid endpoint or motion-boundary sample.  This keeps a configured 0.01 s
    timestep visually and numerically on the 0.01 s grid.  Callers that need extra
    evaluation probes (for example optimization constraint searches) must opt in
    explicitly with ``include_boundaries=True``; those probes are not result frames.
    """
    start = float(settings.start_time)
    end = float(settings.end_time)
    step = float(settings.timestep)
    if not math.isfinite(start) or not math.isfinite(end) or not math.isfinite(step) or step <= 0:
        raise ValueError("仿真时间范围和步长必须是有限数值，且步长必须大于 0")
    span = max(0.0, end - start)
    tick_count = int(math.floor(span / step + 1e-10))
    values = np.round(start + np.arange(tick_count + 1, dtype=float) * step, 12)
    values = values[values <= end + 1e-10]
    if not include_boundaries:
        return values
    extras = {round(end, 12)}
    for value in boundaries or []:
        numeric = float(value)
        if start <= numeric <= end:
            extras.add(round(numeric, 12))
    return np.asarray(sorted(set(values.tolist()) | extras), dtype=float)


def _require_mujoco():
    try:
        import mujoco  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "MuJoCo 引擎不可用：当前 Python 环境未安装 mujoco。请执行 "
            'python -m pip install "mujoco>=3.1,<4" 后重启 Studio。'
        ) from exc
    return mujoco


def load_generated_mujoco_model(xml_path: str | Path, mujoco_module):
    """Load generated XML through the existing Unicode/VFS compatibility contract.

    Server simulations run in-process, so changing process cwd to make a generated
    XML path relative would be unsafe under concurrent requests.  Reuse the native
    Viewer loader instead: ASCII paths keep MuJoCo's normal file loader while any
    Unicode XML/mesh path is virtualized before it reaches MuJoCo on Windows.
    """
    from .viewer_runner import load_mujoco_model

    return load_mujoco_model(xml_path, mujoco_module)


def _project_joint_lookup(project: ProjectSpec):
    return {joint.id: joint for layer in project.layers for joint in layer.joints}


def _display_positions(project: ProjectSpec, schedule: list[ResolvedSegment], time_s: float) -> dict[str, float]:
    lookup = _project_joint_lookup(project)
    raw = joint_positions(schedule, float(time_s))
    return {
        joint_id: crank_displacement(crank_meta(lookup[joint_id]), value)
        if joint_id in lookup and lookup[joint_id].type == "crank" else float(value)
        for joint_id, value in raw.items()
    }


def _to_internal(joint, value: float) -> float:
    return float(value) * 0.001 if joint.type in {"translation", "crank"} else math.radians(float(value))


def _from_internal(joint, value: float) -> float:
    return float(value) * 1000.0 if joint.type in {"translation", "crank"} else math.degrees(float(value))


def _bind_runtime(mujoco, model, drive_payload: dict[str, object], project: ProjectSpec):
    joint_map = dict(drive_payload.get("joint_map", {}))
    joint_lookup = _project_joint_lookup(project)
    addresses: dict[str, int] = {}
    dof_addresses: dict[str, int] = {}
    for joint_id, name in joint_map.items():
        mj_joint = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, str(name))
        if mj_joint >= 0 and joint_id in joint_lookup:
            addresses[str(joint_id)] = int(model.jnt_qposadr[mj_joint])
            dof_addresses[str(joint_id)] = int(model.jnt_dofadr[mj_joint])
    actuator_ids: dict[str, int] = {}
    for joint_id, name in dict(drive_payload.get("actuator_map", {})).items():
        actuator = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, str(name))
        if actuator >= 0:
            actuator_ids[str(joint_id)] = int(actuator)
    mesh_manifest = dict(drive_payload.get("mesh_manifest", {}))
    geom_ids_by_file: dict[str, list[int]] = {}
    for filename, geom_names in mesh_manifest.items():
        ids: list[int] = []
        for geom_name in geom_names:
            geom = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, str(geom_name))
            if geom >= 0:
                ids.append(int(geom))
        geom_ids_by_file[str(filename).casefold()] = ids
    return joint_lookup, addresses, dof_addresses, actuator_ids, geom_ids_by_file


def _set_dynamic_position_controls(
    data, *, actuator_ids: dict[str, int], addresses: dict[str, int], lookup: dict[str, object],
    base_qpos: np.ndarray, positions: dict[str, float],
) -> None:
    """Write Studio drive targets into MuJoCo actuator controls.

    ``actuator_ids`` is keyed by authoritative Studio joint id but its values are
    compiled MuJoCo actuator ids.  Never index ``data.ctrl`` with a joint id or
    qpos address: those index spaces are independent in MuJoCo.
    """
    for joint_id, actuator_id in actuator_ids.items():
        address = addresses.get(joint_id)
        joint = lookup.get(joint_id)
        if address is None or joint is None:
            continue
        data.ctrl[actuator_id] = base_qpos[address] + _to_internal(joint, positions.get(joint_id, 0.0))



def _dynamic_lock_force_by_joint(project: ProjectSpec) -> dict[str, float]:
    """Collapse enabled per-drive stationary brake limits to one value per joint."""
    limits: dict[str, float] = {}
    for drive in project.drives:
        if not drive.enabled or not drive.joint_id:
            continue
        limits[drive.joint_id] = max(
            limits.get(drive.joint_id, 0.0),
            max(float(drive.dynamic_lock_force), 0.0),
        )
    return limits


def _apply_dynamic_self_lock(
    model, *, project: ProjectSpec, dof_addresses: dict[str, int],
    positions: dict[str, float], next_positions: dict[str, float],
) -> None:
    """Project a motor-brake style self-lock into the current MuJoCo model.

    The persistent JointSpec.frictionloss remains the always-on dry-friction
    baseline.  A drive's dynamic_lock_force is added only while its commanded
    target is stationary across the current fixed physics step.  This gives a
    bounded static holding force without making normal commanded motion fight
    the brake.  The mutation is run-local L3 state and is never persisted.
    """
    joint_lookup = _project_joint_lookup(project)
    lock_limits = _dynamic_lock_force_by_joint(project)
    for joint_id, dof_address in dof_addresses.items():
        joint = joint_lookup.get(joint_id)
        if joint is None:
            continue
        baseline = max(float(joint.frictionloss), 0.0)
        lock_limit = max(float(lock_limits.get(joint_id, 0.0)), 0.0)
        current_target = float(positions.get(joint_id, 0.0))
        next_target = float(next_positions.get(joint_id, current_target))
        stationary = math.isclose(current_target, next_target, rel_tol=0.0, abs_tol=1e-9)
        model.dof_frictionloss[dof_address] = max(baseline, lock_limit) if stationary else baseline


def _step_dynamic_with_drive_controls(
    mujoco, model, data, *, project: ProjectSpec, schedule: list[ResolvedSegment],
    actuator_ids: dict[str, int], addresses: dict[str, int], dof_addresses: dict[str, int],
    lookup: dict[str, object], base_qpos: np.ndarray, positions: dict[str, float] | None = None,
) -> dict[str, float]:
    """Advance exactly one dynamic step with Studio drives connected to actuation.

    MuJoCo's two-phase stepping API gives an explicit and testable boundary:
    position/velocity dependent state is prepared by ``mj_step1``; then the
    current Studio drive command is written to ``mjData.ctrl``; finally
    ``mj_step2`` computes actuator forces/constraints and integrates.  The model
    generator uses ``implicitfast``, for which this API preserves the configured
    single-step integrator.
    """
    if positions is None:
        positions = _display_positions(project, schedule, float(data.time))
    next_positions = _display_positions(project, schedule, float(data.time) + float(model.opt.timestep))
    _apply_dynamic_self_lock(
        model, project=project, dof_addresses=dof_addresses,
        positions=positions, next_positions=next_positions,
    )
    # frictionloss participates in the constraint stage, so the stationary brake
    # must be projected before mj_step1 builds position-dependent constraints.
    mujoco.mj_step1(model, data)
    _set_dynamic_position_controls(
        data, actuator_ids=actuator_ids, addresses=addresses, lookup=lookup,
        base_qpos=base_qpos, positions=positions,
    )
    mujoco.mj_step2(model, data)
    return positions


def _validate_dynamic_bindings(project: ProjectSpec, addresses: dict[str, int], actuator_ids: dict[str, int]) -> None:
    """Fail loudly if an enabled physical drive was not compiled/bound to MuJoCo."""
    expected = {drive.joint_id for drive in project.drives if drive.enabled and drive.joint_id}
    missing_joint = sorted(expected - set(addresses))
    missing_actuator = sorted(expected - set(actuator_ids))
    if missing_joint or missing_actuator:
        details = []
        if missing_joint:
            details.append("joint=" + ",".join(missing_joint))
        if missing_actuator:
            details.append("actuator=" + ",".join(missing_actuator))
        raise RuntimeError("dynamic_actuator_binding_failed: " + "; ".join(details))


def _bind_distance_runtime(project: ProjectSpec, geom_ids_by_file: dict[str, list[int]]):
    """Resolve immutable distance-pair geom groups once per simulation run."""
    runtime = []
    for pair in project.distance_pairs:
        group_a = tuple(geom for filename in pair.objects_a for geom in geom_ids_by_file.get(filename.casefold(), ()))
        group_b = tuple(geom for filename in pair.objects_b for geom in geom_ids_by_file.get(filename.casefold(), ()))
        runtime.append((pair.id, float(pair.distmax_m), group_a, group_b))
    return tuple(runtime)


def _measure_bound_distances(mujoco, model, data, distance_runtime):
    values: dict[str, float] = {}
    for pair_id, distmax_m, group_a, group_b in distance_runtime:
        minimum = float("inf")
        for geom_a in group_a:
            for geom_b in group_b:
                if geom_a == geom_b:
                    continue
                distance = max(float(mujoco.mj_geomDistance(model, data, geom_a, geom_b, distmax_m, None)), 0.0)
                minimum = min(minimum, distance)
        values[pair_id] = minimum * 1000.0 if math.isfinite(minimum) else float("inf")
    return values


def _measure_distances(mujoco, model, data, project: ProjectSpec, geom_ids_by_file: dict[str, list[int]]):
    """Compatibility wrapper for callers/tests that still pass ProjectSpec + mesh lookup."""
    return _measure_bound_distances(mujoco, model, data, _bind_distance_runtime(project, geom_ids_by_file))


def _curve_payload_from_qpos(
    project: ProjectSpec, times: np.ndarray, qpos: np.ndarray, base_qpos: np.ndarray,
    addresses: dict[str, int], *, qvel: np.ndarray | None = None, qacc: np.ndarray | None = None,
    dof_addresses: dict[str, int] | None = None,
) -> dict[str, dict[str, object]]:
    """Build display curves, preferring solver velocity/acceleration when available.

    Dynamic MuJoCo runs already expose qvel/qacc.  Re-differentiating qpos twice
    amplifies tiny position quantisation and mapping-knot noise, so only analytical
    or unavailable channels fall back to numerical gradients.
    """
    lookup = _project_joint_lookup(project)
    dof_addresses = dof_addresses or {}
    payload: dict[str, dict[str, object]] = {}
    for joint_id, address in addresses.items():
        joint = lookup[joint_id]
        position = np.asarray([_from_internal(joint, row[address] - base_qpos[address]) for row in qpos], dtype=float)
        dof = dof_addresses.get(joint_id)
        if qvel is not None and dof is not None and qvel.ndim == 2 and dof < qvel.shape[1]:
            velocity = np.asarray([_from_internal(joint, row[dof]) for row in qvel], dtype=float)
        else:
            velocity = np.gradient(position, times) if len(times) > 1 else np.zeros_like(position)
        if qacc is not None and dof is not None and qacc.ndim == 2 and dof < qacc.shape[1]:
            acceleration = np.asarray([_from_internal(joint, row[dof]) for row in qacc], dtype=float)
        else:
            acceleration = np.gradient(velocity, times) if len(times) > 1 else np.zeros_like(position)
        payload[joint_id] = {
            "name": joint.name,
            "joint_type": joint.type,
            "unit": "deg" if joint.type == "rotation" else "mm",
            "position": position.tolist(),
            "velocity": velocity.tolist(),
            "acceleration": acceleration.tolist(),
        }
    return payload


def _write_results(project: ProjectSpec, result_dir: Path, *, mode: str, times: np.ndarray, qpos: np.ndarray,
                   qvel: np.ndarray, ctrl: np.ndarray, base_qpos: np.ndarray, addresses: dict[str, int],
                   schedule: list[ResolvedSegment], variables: dict[str, float], contacts: list[int],
                   distance_values: dict[str, list[float]], model, dof_addresses: dict[str, int] | None = None,
                   qacc: np.ndarray | None = None) -> dict[str, object]:
    curve_payload = _curve_payload_from_qpos(
        project, times, qpos, base_qpos, addresses, qvel=qvel, qacc=qacc, dof_addresses=dof_addresses,
    )
    distance_payload: dict[str, dict[str, object]] = {}
    pair_lookup = {pair.id: pair for pair in project.distance_pairs}
    for pair_id, values in distance_values.items():
        pair = pair_lookup[pair_id]
        finite = [(i, value) for i, value in enumerate(values) if math.isfinite(value)]
        if finite:
            min_index, min_value = min(finite, key=lambda item: item[1])
            min_time = float(times[min_index])
        else:
            min_value, min_time = float("inf"), None
        distance_payload[pair_id] = {
            "name": pair.name, "unit": "mm", "values": values,
            "minimum_mm": min_value, "minimum_time_s": min_time,
            "objects_a": pair.objects_a, "objects_b": pair.objects_b,
        }

    result_dir.mkdir(parents=True, exist_ok=True)
    trajectory_path = result_dir / "trajectory.npz"
    np.savez_compressed(trajectory_path, times=times, qpos=qpos, qvel=qvel, ctrl=ctrl)
    result_path = result_dir / "simulation_result.json"
    csv_path = result_dir / "simulation_curves.csv"
    payload: dict[str, object] = {
        "project_id": project.id,
        "solver_mode": mode,
        "engine": "mujoco",
        "times": times.tolist(),
        "curves": curve_payload,
        "drive_curves": build_drive_curves(project, schedule, times),
        "variables": variables,
        "contacts": contacts,
        "distance_curves": distance_payload,
        "maximum_contacts": max(contacts, default=0),
        "end_time": float(times[-1]) if len(times) else project.simulation.start_time,
        "trajectory_file": "trajectory.npz",
        "trajectory": {"nframes": int(len(times)), "nq": int(model.nq), "nv": int(model.nv), "nu": int(model.nu)},
        "model_summary": {"nq": int(model.nq), "nv": int(model.nv), "nu": int(model.nu), "nbody": int(model.nbody), "ngeom": int(model.ngeom), "njnt": int(model.njnt)},
    }
    result_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    with csv_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        joint_ids = list(curve_payload)
        pair_ids = list(distance_payload)
        writer.writerow(["time_s", "contact_count"] + [f"{curve_payload[item]['name']}_position" for item in joint_ids] + [f"{distance_payload[item]['name']}_mm" for item in pair_ids])
        for index, time_s in enumerate(times):
            writer.writerow([time_s, contacts[index] if index < len(contacts) else 0] + [curve_payload[item]["position"][index] for item in joint_ids] + [distance_payload[item]["values"][index] for item in pair_ids])
    payload["artifacts"] = {"result": str(result_path), "csv": str(csv_path), "trajectory": str(trajectory_path)}
    return payload


def run_analytical_simulation(
    project: ProjectSpec, result_dir: Path, *, variable_overrides: dict[str, float] | None = None,
    progress: ProgressCallback | None = None, should_cancel: Callable[[], bool] | None = None,
) -> dict[str, object]:
    """Compatibility-only fast curve evaluation. It does not create Viewer trajectory data."""
    variables, schedule = resolve_schedule(project, variable_overrides)
    times = build_time_grid(project.simulation)
    joint_lookup = _project_joint_lookup(project)
    curves: dict[str, list[float]] = {joint_id: [] for joint_id in {item.joint_id for item in schedule if item.joint_id}}
    for index, time_s in enumerate(times):
        if should_cancel and should_cancel():
            raise InterruptedError("simulation cancelled")
        positions = _display_positions(project, schedule, float(time_s))
        for joint_id in curves:
            curves[joint_id].append(float(positions.get(joint_id, 0.0)))
        if progress and (index % max(1, len(times)//100) == 0 or index == len(times)-1):
            progress((index+1)/max(len(times),1), f"Kinematic curve {index+1}/{len(times)}")
    curve_payload = {}
    for joint_id, values in curves.items():
        position = np.asarray(values, dtype=float)
        velocity = np.gradient(position, times) if len(times)>1 else np.zeros_like(position)
        acceleration = np.gradient(velocity, times) if len(times)>1 else np.zeros_like(position)
        joint = joint_lookup[joint_id]
        curve_payload[joint_id] = {"name": joint.name, "joint_type": joint.type, "unit": "deg" if joint.type == "rotation" else "mm", "position": position.tolist(), "velocity": velocity.tolist(), "acceleration": acceleration.tolist()}
    result_dir.mkdir(parents=True, exist_ok=True)
    result_path = result_dir / "simulation_result.json"
    payload = {"project_id": project.id, "solver_mode": project.solver_mode, "engine": "analytical", "times": times.tolist(), "curves": curve_payload, "drive_curves": build_drive_curves(project,schedule,times), "variables": variables, "end_time": max((item.end for item in schedule), default=project.simulation.start_time)}
    result_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    payload["artifacts"] = {"result": str(result_path)}
    return payload


def run_kinematic_simulation(
    project: ProjectSpec, result_dir: Path, *, variable_overrides: dict[str, float] | None = None,
    progress: ProgressCallback | None = None, should_cancel: Callable[[], bool] | None = None,
) -> dict[str, object]:
    """Pure position-level kinematics: write qpos, solve optional closure, then mj_forward; never mj_step."""
    mujoco = _require_mujoco()
    from .xml_generator import generate_project
    from .kinematic_closure import build_closure_runtime, solve_kinematic_closure, closure_failure_payload

    result_dir.mkdir(parents=True, exist_ok=True)
    generated = generate_project(project, result_dir / "generated", check_files=True)
    drive_payload = json.loads(Path(generated["drives"]).read_text("utf-8"))
    variables, schedule = resolve_schedule(project, variable_overrides)
    times = build_time_grid(project.simulation)
    model = load_generated_mujoco_model(generated["model"], mujoco)
    data = mujoco.MjData(model)
    base_qpos = data.qpos.copy()
    lookup, addresses, dof_addresses, _, geom_ids = _bind_runtime(mujoco, model, drive_payload, project)
    closure_runtime = build_closure_runtime(mujoco, model, drive_payload)
    previous_qpos = base_qpos.copy()
    qpos_frames: list[np.ndarray] = []
    contacts: list[int] = []
    distance_values = {pair.id: [] for pair in project.distance_pairs}
    distance_runtime = _bind_distance_runtime(project, geom_ids)

    for index, time_s in enumerate(times):
        if should_cancel and should_cancel():
            raise InterruptedError("simulation cancelled")
        positions = _display_positions(project, schedule, float(time_s))
        data.qpos[:] = base_qpos
        for joint_id, value in positions.items():
            if joint_id in addresses:
                data.qpos[addresses[joint_id]] = base_qpos[addresses[joint_id]] + _to_internal(lookup[joint_id], value)
        solved = solve_kinematic_closure(mujoco, model, data, closure_runtime, driven_joint_ids=set(positions), previous_qpos=previous_qpos, kinematics_only=False)
        if not solved.converged:
            raise ValueError(json.dumps(closure_failure_payload(solved, time_s=float(time_s)), ensure_ascii=False))
        previous_qpos = data.qpos.copy()
        mujoco.mj_forward(model, data)
        qpos_frames.append(data.qpos.copy())
        contacts.append(int(data.ncon))
        measured = _measure_bound_distances(mujoco, model, data, distance_runtime)
        for pair_id, value in measured.items():
            distance_values[pair_id].append(value)
        if progress and (index % max(1, len(times)//100) == 0 or index == len(times)-1):
            progress((index+1)/max(len(times),1), f"Kinematic trajectory {index+1}/{len(times)}")

    qpos = np.asarray(qpos_frames, dtype=float)
    qvel = np.gradient(qpos, times, axis=0) if len(times)>1 else np.zeros((len(times), model.nv), dtype=float)
    if qvel.shape[1] != model.nv:
        qvel = np.zeros((len(times), model.nv), dtype=float)
    ctrl = np.zeros((len(times), model.nu), dtype=float)
    payload = _write_results(project, result_dir, mode="kinematic", times=times, qpos=qpos, qvel=qvel, ctrl=ctrl, base_qpos=base_qpos, addresses=addresses, dof_addresses=dof_addresses, schedule=schedule, variables=variables, contacts=contacts, distance_values=distance_values, model=model)
    payload["artifacts"].update(generated)
    return payload


def run_dynamic_simulation(
    project: ProjectSpec, result_dir: Path, *, variable_overrides: dict[str, float] | None = None,
    progress: ProgressCallback | None = None, should_cancel: Callable[[], bool] | None = None,
) -> dict[str, object]:
    """Pure MuJoCo dynamics: drives become position actuators; no qpos is overwritten after initialization."""
    mujoco = _require_mujoco()
    from .xml_generator import generate_project

    result_dir.mkdir(parents=True, exist_ok=True)
    generated = generate_project(project, result_dir / "generated", check_files=True)
    drive_payload = json.loads(Path(generated["drives"]).read_text("utf-8"))
    variables, schedule = resolve_schedule(project, variable_overrides)
    # Dynamic integration remains strictly fixed-step. Segment boundaries are sampled by the command evaluator,
    # not by inserting irregular physics steps.
    times = build_time_grid(project.simulation)
    model = load_generated_mujoco_model(generated["model"], mujoco)
    data = mujoco.MjData(model)
    base_qpos = data.qpos.copy()
    lookup, addresses, dof_addresses, actuator_ids, geom_ids = _bind_runtime(mujoco, model, drive_payload, project)
    _validate_dynamic_bindings(project, addresses, actuator_ids)
    qpos_frames: list[np.ndarray] = []
    qvel_frames: list[np.ndarray] = []
    qacc_frames: list[np.ndarray] = []
    ctrl_frames: list[np.ndarray] = []
    contacts: list[int] = []
    distance_values = {pair.id: [] for pair in project.distance_pairs}
    distance_runtime = _bind_distance_runtime(project, geom_ids)
    cached_command_time: float | None = None
    cached_positions: dict[str, float] | None = None

    # Simulate from t=0 to the requested end; record only requested sample times.
    for index, target_time in enumerate(times):
        if should_cancel and should_cancel():
            raise InterruptedError("simulation cancelled")
        while data.time + 1e-12 < float(target_time):
            step_time = float(data.time)
            if cached_command_time is not None and abs(cached_command_time - step_time) <= 1e-10:
                step_positions = cached_positions
            else:
                step_positions = _display_positions(project, schedule, step_time)
            _step_dynamic_with_drive_controls(
                mujoco, model, data, project=project, schedule=schedule,
                actuator_ids=actuator_ids, addresses=addresses, dof_addresses=dof_addresses,
                lookup=lookup, base_qpos=base_qpos, positions=step_positions,
            )
            cached_command_time = None
            cached_positions = None
            if should_cancel and should_cancel():
                raise InterruptedError("simulation cancelled")
        # Refresh command at exact sample for ctrl trace, without changing qpos. The same
        # command is cached for the next fixed step so schedule/mapping evaluation is not
        # repeated at an identical timestamp.
        positions = _display_positions(project, schedule, float(target_time))
        cached_command_time = float(target_time)
        cached_positions = positions
        _set_dynamic_position_controls(
            data, actuator_ids=actuator_ids, addresses=addresses, lookup=lookup,
            base_qpos=base_qpos, positions=positions,
        )
        mujoco.mj_forward(model, data)
        qpos_frames.append(data.qpos.copy())
        qvel_frames.append(data.qvel.copy())
        qacc_frames.append(data.qacc.copy())
        ctrl_frames.append(data.ctrl.copy())
        contacts.append(int(data.ncon))
        measured = _measure_bound_distances(mujoco, model, data, distance_runtime)
        for pair_id, value in measured.items():
            distance_values[pair_id].append(value)
        if progress and (index % max(1, len(times)//100) == 0 or index == len(times)-1):
            progress((index+1)/max(len(times),1), f"Dynamic trajectory {index+1}/{len(times)}")

    qpos = np.asarray(qpos_frames, dtype=float)
    qvel = np.asarray(qvel_frames, dtype=float)
    qacc = np.asarray(qacc_frames, dtype=float)
    ctrl = np.asarray(ctrl_frames, dtype=float) if model.nu else np.zeros((len(times),0),dtype=float)
    payload = _write_results(project, result_dir, mode="dynamic", times=times, qpos=qpos, qvel=qvel, qacc=qacc, ctrl=ctrl, base_qpos=base_qpos, addresses=addresses, dof_addresses=dof_addresses, schedule=schedule, variables=variables, contacts=contacts, distance_values=distance_values, model=model)
    payload["artifacts"].update(generated)
    return payload


def run_project_simulation(
    project: ProjectSpec, result_dir: Path, *, variable_overrides: dict[str, float] | None = None,
    progress: ProgressCallback | None = None, should_cancel: Callable[[], bool] | None = None,
) -> dict[str, object]:
    if project.simulation.engine == "analytical" and project.solver_mode == "kinematic" and not project.kinematic_closures:
        return run_analytical_simulation(project, result_dir, variable_overrides=variable_overrides, progress=progress, should_cancel=should_cancel)
    if project.solver_mode == "dynamic":
        return run_dynamic_simulation(project, result_dir, variable_overrides=variable_overrides, progress=progress, should_cancel=should_cancel)
    return run_kinematic_simulation(project, result_dir, variable_overrides=variable_overrides, progress=progress, should_cancel=should_cancel)


def run_mujoco_simulation(
    project: ProjectSpec, result_dir: Path, *, variable_overrides: dict[str, float] | None = None,
    progress: ProgressCallback | None = None, should_cancel: Callable[[], bool] | None = None,
) -> dict[str, object]:
    """Compatibility alias used by older tools."""
    return run_dynamic_simulation(project, result_dir, variable_overrides=variable_overrides, progress=progress, should_cancel=should_cancel) if project.solver_mode == "dynamic" else run_kinematic_simulation(project, result_dir, variable_overrides=variable_overrides, progress=progress, should_cancel=should_cancel)
