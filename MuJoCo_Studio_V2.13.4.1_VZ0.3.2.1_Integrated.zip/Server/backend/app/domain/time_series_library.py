from __future__ import annotations

import csv
import io
import json
import math
import re
from datetime import datetime, timezone
from typing import Any, Iterable

from .models import DriveSpec, ProjectSpec
from .motion import ScheduleResolutionError, resolve_schedule

TIME_SERIES_SCHEMA = "vz_time_series_library"
TIME_SERIES_SCHEMA_VERSION = "1.0"
MAPPING_TABLE_SUFFIX = "映射表格.csv"


def _dump(model: Any, **kwargs: Any) -> dict[str, Any]:
    if hasattr(model, "model_dump"):
        return model.model_dump(**kwargs)
    return model.dict(**kwargs)


def _validate_drive(data: dict[str, Any]) -> DriveSpec:
    if hasattr(DriveSpec, "model_validate"):
        return DriveSpec.model_validate(data)
    return DriveSpec.parse_obj(data)


def safe_csv_stem(value: str, fallback: str = "时序") -> str:
    text = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "_", str(value or "")).strip(" ._")
    return text[:96] or fallback


def is_mapping_table_name(name: str) -> bool:
    return str(name or "").endswith(MAPPING_TABLE_SUFFIX)


def _joint_name_map(project: ProjectSpec) -> dict[str, str]:
    return {
        str(joint.id): str(joint.name or joint.id)
        for layer in project.layers
        for joint in layer.joints
    }


def _resolved_schedule(project: ProjectSpec) -> dict[tuple[str, str], Any]:
    try:
        _variables, schedule = resolve_schedule(project)
    except ScheduleResolutionError as exc:
        schedule = exc.partial_schedule
    except (ValueError, TypeError):
        schedule = []
    return {(str(item.drive_id), str(item.segment_id)): item for item in schedule}


def _finite_or_blank(value: Any) -> Any:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return ""
    return number if math.isfinite(number) else ""


def build_time_series_bundle(
    project: ProjectSpec,
    axes: Iterable[dict[str, Any]],
    *,
    generated_at: datetime | None = None,
) -> tuple[str, str, list[tuple[str, str]]]:
    """Build one portable merged time-series CSV plus companion mapping tables.

    The CSV intentionally contains both human-readable columns and lossless JSON
    payload cells for drive/segment parameters.  Mapping rows are embedded in the
    main CSV and also emitted as standalone ``<drive>--<segment>映射表格.csv`` files.
    """
    timestamp = generated_at or datetime.now(timezone.utc)
    stamp = timestamp.astimezone(timezone.utc).strftime("%Y%m%d_%H%M%S")
    main_name = f"{safe_csv_stem(project.name, '模型')}--{stamp}时序.csv"
    joints = _joint_name_map(project)
    resolved = _resolved_schedule(project)
    stream = io.StringIO(newline="")
    writer = csv.writer(stream, quoting=csv.QUOTE_MINIMAL, lineterminator="\r\n")
    writer.writerow(["VZ_TIME_SERIES", TIME_SERIES_SCHEMA_VERSION, "schema", TIME_SERIES_SCHEMA])
    writer.writerow(["META", "model_id", project.id, "model_name", project.name, "generated_at", timestamp.isoformat()])
    writer.writerow(["COLUMNS", "record_type", "human_fields...", "json_payload"])

    mapping_files: list[tuple[str, str]] = []
    used_mapping_names: set[str] = set()
    for drive in project.drives:
        drive_data = _dump(drive, exclude={"segments"})
        joint_name = joints.get(str(drive.joint_id), str(drive.joint_id))
        writer.writerow([
            "DRIVE", drive.id, drive.name, drive.joint_id, joint_name,
            json.dumps(drive_data, ensure_ascii=False, separators=(",", ":")),
        ])
        for segment in drive.segments:
            segment_data = _dump(segment)
            item = resolved.get((str(drive.id), str(segment.id)))
            source_joint_name = joints.get(str(segment.mapping_source_joint_id), str(segment.mapping_source_joint_id or ""))
            writer.writerow([
                "SEGMENT", drive.id, segment.id, segment.name, segment.profile,
                _finite_or_blank(getattr(item, "start", "")),
                _finite_or_blank(getattr(item, "end", "")),
                source_joint_name,
                json.dumps(segment_data, ensure_ascii=False, separators=(",", ":")),
            ])
            point_kind = "MAPPING_POINT" if segment.profile == "mapping" else "POINT"
            for index, row in enumerate(segment.points or []):
                if not isinstance(row, (list, tuple)) or len(row) < 2:
                    continue
                writer.writerow([point_kind, drive.id, segment.id, index, row[0], row[1]])
            if segment.profile == "mapping" and segment.points:
                stem = f"{safe_csv_stem(drive.name, 'drive')}--{safe_csv_stem(segment.name, 'segment')}"
                name = f"{stem}映射表格.csv"
                suffix_index = 2
                while name.casefold() in used_mapping_names:
                    name = f"{stem}_{suffix_index}映射表格.csv"
                    suffix_index += 1
                used_mapping_names.add(name.casefold())
                mapping = io.StringIO(newline="")
                mw = csv.writer(mapping, quoting=csv.QUOTE_MINIMAL, lineterminator="\r\n")
                mw.writerow(["source", "target"])
                for row in segment.points:
                    if isinstance(row, (list, tuple)) and len(row) >= 2:
                        mw.writerow([row[0], row[1]])
                mapping_files.append((name, "\ufeff" + mapping.getvalue()))
                writer.writerow(["MAPPING_TABLE", drive.id, segment.id, name, len(segment.points)])

    writer.writerow(["RESULT_HEADER", "coordinate_system", "time_s", "curve", "value", "unit"])
    for axis in axes:
        axis_name = str(axis.get("name") or "坐标系")
        times = list(axis.get("times") or [])
        for curve in axis.get("curves") or []:
            values = list(curve.get("values") or [])
            label = str(curve.get("label") or "曲线")
            unit = str(curve.get("unit") or "")
            for index, sample_time in enumerate(times):
                if index >= len(values):
                    break
                value = values[index]
                if value is None or value == "":
                    continue
                writer.writerow(["RESULT", axis_name, sample_time, label, value, unit])
    return main_name, "\ufeff" + stream.getvalue(), mapping_files


def parse_time_series_csv(content: str, project: ProjectSpec | None = None) -> dict[str, Any]:
    """Parse a V2.13+ time-series CSV into authoritative DriveSpec payloads."""
    text = str(content or "").lstrip("\ufeff")
    if not text.strip():
        raise ValueError("时序 CSV 为空")
    rows = list(csv.reader(io.StringIO(text)))
    if not rows or len(rows[0]) < 2 or rows[0][0] != "VZ_TIME_SERIES":
        raise ValueError("不是 V2.13+ 时序库 CSV（缺少 VZ_TIME_SERIES 标记）")
    if str(rows[0][1]).strip() != TIME_SERIES_SCHEMA_VERSION:
        raise ValueError(f"不支持的时序库版本：{rows[0][1]}")

    joints_by_id: dict[str, str] = {}
    joints_by_name: dict[str, str] = {}
    if project is not None:
        for layer in project.layers:
            for joint in layer.joints:
                joints_by_id[str(joint.id)] = str(joint.id)
                joints_by_name[str(joint.name or "").strip()] = str(joint.id)

    drive_rows: dict[str, dict[str, Any]] = {}
    drive_order: list[str] = []
    segment_rows: dict[tuple[str, str], dict[str, Any]] = {}
    segment_order: dict[str, list[str]] = {}
    point_rows: dict[tuple[str, str], list[list[float]]] = {}
    segment_source_names: dict[tuple[str, str], str] = {}
    warnings: list[str] = []

    for row in rows[1:]:
        if not row:
            continue
        kind = str(row[0]).strip()
        if kind == "DRIVE" and len(row) >= 6:
            drive_id = str(row[1]).strip()
            try:
                payload = json.loads(row[5])
            except (TypeError, ValueError) as exc:
                raise ValueError(f"驱动 {row[2] if len(row) > 2 else drive_id} 参数 JSON 无效") from exc
            if not isinstance(payload, dict):
                raise ValueError("驱动参数必须是 JSON 对象")
            payload["id"] = drive_id or str(payload.get("id", ""))
            payload["name"] = str(row[2] or payload.get("name", "act1"))
            raw_joint_id = str(row[3] or payload.get("joint_id", ""))
            joint_name = str(row[4] or "").strip()
            if joints_by_id:
                mapped = joints_by_id.get(raw_joint_id) or joints_by_name.get(joint_name)
                if mapped:
                    payload["joint_id"] = mapped
                else:
                    payload["joint_id"] = raw_joint_id
                    warnings.append(f"驱动“{payload['name']}”未在当前模型找到运动副“{joint_name or raw_joint_id}”，已保留原引用")
            else:
                payload["joint_id"] = raw_joint_id
            payload["segments"] = []
            if drive_id not in drive_rows:
                drive_order.append(drive_id)
            drive_rows[drive_id] = payload
            segment_order.setdefault(drive_id, [])
        elif kind == "SEGMENT" and len(row) >= 9:
            drive_id, segment_id = str(row[1]).strip(), str(row[2]).strip()
            try:
                payload = json.loads(row[8])
            except (TypeError, ValueError) as exc:
                raise ValueError(f"运动段 {row[3] if len(row) > 3 else segment_id} 参数 JSON 无效") from exc
            if not isinstance(payload, dict):
                raise ValueError("运动段参数必须是 JSON 对象")
            payload["id"] = segment_id or str(payload.get("id", ""))
            payload["name"] = str(row[3] or payload.get("name", "seg1"))
            payload["profile"] = str(row[4] or payload.get("profile", "s_curve"))
            segment_rows[(drive_id, segment_id)] = payload
            segment_order.setdefault(drive_id, []).append(segment_id)
            segment_source_names[(drive_id, segment_id)] = str(row[7] or "").strip()
        elif kind in {"POINT", "MAPPING_POINT"} and len(row) >= 6:
            key = (str(row[1]).strip(), str(row[2]).strip())
            try:
                x, y = float(row[4]), float(row[5])
            except (TypeError, ValueError):
                continue
            if math.isfinite(x) and math.isfinite(y):
                point_rows.setdefault(key, []).append([x, y])

    if not drive_order:
        raise ValueError("时序 CSV 中没有 DRIVE 记录")

    output: list[dict[str, Any]] = []
    for drive_id in drive_order:
        drive = drive_rows[drive_id]
        segments: list[dict[str, Any]] = []
        for segment_id in segment_order.get(drive_id, []):
            key = (drive_id, segment_id)
            segment = segment_rows[key]
            if key in point_rows:
                segment["points"] = point_rows[key]
                if segment.get("profile") == "mapping":
                    segment["mapping_point_count"] = len(point_rows[key])
            source_id = str(segment.get("mapping_source_joint_id", "") or "")
            source_name = segment_source_names.get(key, "")
            if source_id and joints_by_id:
                segment["mapping_source_joint_id"] = joints_by_id.get(source_id) or joints_by_name.get(source_name) or source_id
                if segment["mapping_source_joint_id"] == source_id and source_id not in joints_by_id:
                    warnings.append(f"运动段“{segment.get('name', segment_id)}”的映射源“{source_name or source_id}”未在当前模型找到，已保留原引用")
            segment["csv_path"] = ""
            segments.append(segment)
        drive["segments"] = segments
        validated = _validate_drive(drive)
        output.append(_dump(validated))

    return {
        "schema": TIME_SERIES_SCHEMA,
        "schema_version": TIME_SERIES_SCHEMA_VERSION,
        "drives": output,
        "warnings": warnings,
    }
