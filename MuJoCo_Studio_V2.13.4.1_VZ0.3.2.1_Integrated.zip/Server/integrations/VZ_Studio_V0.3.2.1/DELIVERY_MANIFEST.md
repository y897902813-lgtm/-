# VZ Studio 0.2.16.1 交付清单

## 本次迭代

- 长期存储白名单正式收口：模型结构/闭链、驱动/变量、记忆位置、控制顺序、材质、渲染/仿真配置及其 STL/OBJ、纹理、环境图资源。
- `simulations/<job_id>/` 整体改为临时任务：启动删除遗留任务；已完成任务最多保留 1 小时；正在运行的任务用 `.vz_active` 防止被周期清理误删。
- `animations/*.html` 继续作为临时预览/下载结果：启动清理，当前会话最多保留 1 小时。
- `trash/undo_*` 超过 15 分钟自动物理删除；启动和运行期间都会回收。
- 用户网址不再长期保存当前模型和浏览相机；刷新/重新进入/切换模型固定从正视图开始。
- 当前页面内相机继续跟随仿真、记忆跳转和三步 `↶` 撤销，关闭页面后丢弃。
- V0.2.15.x 的 `model_cameras` / `selected_model_id` 在启动时自动迁移清理，`user_settings.json` 只保留 `render_quality`。
- V0.2.15 的紧凑闭链层级树与最多三步临时姿态撤销逻辑保持不变。
- 版本统一升级至 0.2.16.1。

## 验证

- Python `compileall` 通过。
- `engineer.js`、`client.js`、`material-editor.js`、`viewer.js` 均通过 `node --check`。
- 全量 unittest：85 项运行，83 项通过，2 项按既有 MuJoCo wheel 条件跳过，0 失败。

---

# 历史交付：VZ Studio 0.2.10.0
## 二代建模信息 JSON 互通
- 新增 `vz/modeling_exchange.py`。
- 支持 MuJoCo Studio V2.5.6.11.1 `mujoco_modeling_exchange` 2.0。
- schema 1.0 / 2.x 均可导入。
- 二代复杂驱动、测距、逻辑驱动通过 `_modeling_exchange` 兼容元数据保留。
- VZ 材质/Material Slot/渲染场景等通过 `vz_extensions` 保留，二代可忽略。
- 工程师页新增“导入建模信息 / 导出建模信息”。

---

# VZ Studio 0.2.8.1 交付清单

## V0.2.8.1 核心变更

- 材质编辑器双击对象后直接高亮对象本体，不再绘制对象包围盒。
- 左键轻点场景空白区域可取消选择，拖动旋转不会误触取消。
- 材质库缩略预览区域最大高度从 260 px 增至 520 px。
- 保持 0.2.8 Mesh Slot / PBR 参数与完美渲染持久化链路不变。

## V0.2.8.1 验证

- Python compileall、material-editor.js / engineer.js Node 语法检查通过。
- unittest 共 50 项：48 项通过，2 项按既有 MuJoCo wheel 条件跳过，0 失败。
- 选择交互定向契约：双击选择、空白取消、对象本体 shader 高亮、无边界框。
- 材质缩略预览区 CSS 定向契约：max-height = 520 px。

---

# VZ Studio 0.2.8 交付清单

## V0.2.8 核心变更

- 新增 `frontend/material-editor.js` 独立材质编辑器，复用项目 WebGL2/PBR 架构，无外部 CDN 依赖。
- 新增场景 Mesh 级 `material_slots.slot_0` 持久化；对象映射使用稳定 `mesh.id`，模型标识使用 `asset.id`。
- 修复中文材质目录分类和 generic 金属回退问题；皮革/哑光、塑料、裸金属推荐参数互相独立。
- 恢复旧材质设置中的高级参数默认展开，取消材质类型下拉框的隐式全参数覆盖。
- 新增纹理缩放与纹理旋转参数，并同步到正式离线 WebGL2 渲染。
- 完美/快速动画导出优先读取 Mesh Slot 覆盖值，未覆盖时兼容原资产级 `render_config`。

## V0.2.8 验证

- `python -m compileall -q vz run.py` 通过。
- `node --check frontend/engineer.js` 与 `node --check frontend/material-editor.js` 通过。
- unittest 共 50 项：48 项通过，2 项因构建环境未安装 MuJoCo wheel 按既有设计跳过，0 失败。
- 新增定向回归覆盖：中文分类独立 PBR、未知材质非金属回退、Mesh Slot round-trip、独立材质窗口前端契约。
- HTTP smoke：`/api/health` 返回版本 0.2.8；`/engineer` 与 `/static/material-editor.js` 可正常读取。

---

# VZ Studio 0.2.5.2.4 交付清单

## V0.2.5.1 完美导出核心变更

- 新增 `perfect` 动画导出质量级别和工程师端“◆ 完美导出”入口。
- 完美模式至少 90 FPS、2,500,000 faces/mesh、DPR cap 3.5。
- 数模 `render_config` 新增 BaseColor / Normal / Roughness / Metallic / AO 贴图、真实贴图尺度、法线强度、AO 强度和清漆粗糙度。
- 模型级 `render_scene` 新增环境图、环境强度/旋转、曝光、阴影强度与阴影柔化。
- 新增后台 `render_assets/textures` 与 `render_assets/environments` 素材库及 `/api/render-assets`。
- STL/OBJ 通用材质使用 triplanar PBR 投射；所有被引用的素材在完美导出时 Base64 内嵌到单个 HTML。
- WebGL2 完美渲染加入 BaseColor/Normal/Roughness/Metallic/AO、环境反射近似、曝光、ACES 风格 tone mapping、4096 动态 shadow map 与 5×5 PCF。
- 快速/高保真模式继续不嵌入大贴图/阴影资源，避免破坏原有导出速度优势。

## V0.2.5.1 验证

- `python -m compileall -q .` 通过。
- `engineer.js` / `client.js` / `viewer.js` 全部通过 `node --check`。
- unittest 共 29 项：27 项通过，2 项因构建环境未安装 MuJoCo wheel 按既有设计跳过，0 失败。
- 完美导出 HTML 的内联 JavaScript 单独提取后通过 Node 语法检查。
- Chromium + WebGL2 + SwiftShader 实际加载最小 Perfect 烟雾页：WebGL2 可用、页面错误 0、控制台 Shader/GL 错误 0。
- 贴图路径执行相对路径和扩展名校验，拒绝绝对路径及 `..` 穿越。

---

# 历史交付记录：VZ Studio 0.2.5


## V0.2.5 核心变更

- 数模资产新增持久化 `render_config`，旧项目加载时自动补齐默认值。
- 新增按夹角阈值的 creased normals；默认 35°，支持 smooth / flat 两种覆盖模式。
- 快速导出：30 FPS、120k faces/mesh、1.75 DPR 上限，使用增强材质着色器。
- 高保真导出：至少 60 FPS、1,000k faces/mesh、2.5 DPR 上限、额外补光。
- 材质参数：material preset、metallic、roughness、specular、clearcoat、environment strength。
- 工程师端将 MuJoCo 仿真与动画导出拆成独立按钮；新增 `/api/export-animation`。
- 数模库与资产管理器新增逐资产渲染配置 UI。
- 离线 HTML 仍为单文件，无运行时 CDN/服务器依赖。

## 验证

- Python 全量语法检查。
- `engineer.js` / `client.js` / `viewer.js` Node 语法检查。
- 全量 unittest 回归。
- creased normals 90° 折边逻辑自检。
- 导出 HTML 内联脚本 Node 语法检查。

---

# 历史交付记录：VZ Studio 0.2.4.2

## 本次迭代

- 层级建模顶部新增模型名称输入与“查看正视图渲染图”。预览会按整个模型包围盒自动取景并生成静态截图。
- 驱动动作新增“动作速度”；由活动动作投射出的兼容 `drives[]` 统一使用 `mode: speed`。
- 用户端移除速度字段，只提交起始/结束位置；后端使用工程师设置的 `rated_speed` 计算每段持续时间。
- 工程师 MuJoCo 仿真改为后台任务；右上角进度条实时提示 MJCF/仿真/HTML 导出阶段，点击时预先打开页面，完成后自动跳转到动画。
- 直接复用二代软件的离线动画 HTML 核心导出器，保留 WebGL2 播放器及正视图、侧视图、POV 视图逻辑。
- Windows 项目根目录改为 `E:\VZ_project`；Linux 改为 `run.py` 同级 `VZ_project/`，并支持从旧 `data/` 首次迁移。
- 模型、STL/OBJ、MJCF、结果 JSON 和动画 HTML 全部落在独立 `VZ_project` 中。

## 验证项目

- Python 源码全量 `compileall`。
- `engineer.js`、`client.js`、`viewer.js` 执行 `node --check`。
- 单元/HTTP 测试覆盖：速度时长计算、用户端无速度字段、二代 HTML 相机按钮、层级循环、活动动作投影、MJCF 接口和双入口。
- 安装 MuJoCo 的环境额外执行真实 MJCF 编译和真实用户序列动画 HTML 导出。

## VZ 0.2.2 STL upload hotfix

- Replaced browser Base64/data-URL mesh uploads with direct binary streaming uploads.
- Removed the mismatch where the UI accepted 50 MiB meshes but Base64 expansion could exceed the 60 MiB JSON request cap at about 45 MiB.
- Mesh upload ceiling now matches the second-generation Studio: 2 GiB per STL/OBJ asset.
- Server writes uploads in 1 MiB chunks to a temporary file and atomically moves the completed asset into `VZ_project/models/<model>/assets/`.
- Kept the legacy JSON/Base64 endpoint compatible for older VZ 0.2.x pages.
- Added regression coverage for binary upload, Unicode filenames, uppercase `.STL`, asset readback, and the frontend no longer using `readAsDataURL`.
- Verified a real 48 MiB HTTP upload returns 201 and preserves the exact byte count.

## Windows asset path + folder upload hotfix

- Hardened managed asset writes under `VZ_project/models/<model>/assets/`: ensure the directory exists, write to a temporary file, atomically replace, retry once if the Windows destination directory disappears, and verify persisted byte count before model metadata is committed.
- Added a startup storage write probe for `VZ_project` so an unavailable/unwritable `E:` drive fails with a clear diagnostic.
- Successful uploads automatically prune stale metadata for mesh files that are already missing on disk; the “修复失效引用” action now performs the same physical-file repair through the backend.
- Added a dedicated STL/OBJ folder picker using `webkitdirectory directory multiple`, recursive filtering of all STL/OBJ entries, relative-path metadata via `webkitRelativePath`, per-file progress, and preservation of unsaved model edits.
- Added server-side relative-path validation against absolute paths, drive paths, empty components, and `..` traversal.
- Regression suite expanded to 22 tests: 20 pass in the build sandbox and 2 MuJoCo-dependent integration tests are skipped because the wheel is unavailable there.
- Re-verified a real 48 MiB HTTP STL upload after this hotfix: HTTP 201 and exact persisted size `50,331,648` bytes.


## VZ 0.2.4.2 final regression

- 旋转副默认轴 0,1,0；滑动副默认轴 1,0,0，并统一“滑动副”命名。
- 工程师模型渲染截图使用侧视图；驱动 0%/100% 仅作为标定范围，工程师仿真保持静止。
- 用户选择模型即生成 0 行程静止动画；首次无记忆视角时使用正视图。
- 用户视角按模型保存到 VZ_project/user_settings.json，首帧直接恢复，无默认视角跳变。
- 动画右上显示控制对象/运动/数值与百分比，不再显示测距界面。
- 发送并仿真自动播放一次，抵达终点后停止，不循环。


## V0.2.5.1.1 性能修复

- `/api/simulate` 用户端刷新改为 `quality="preview"`。
- Preview 强制 smooth normals，不触发高成本 crease 重建。
- Preview 静态网格 Base64 增加 64 MiB 有界 LRU 内容哈希缓存。
- FAST / HIGH / PERFECT 正式导出链路保持不变。


## V0.2.5.2 渲染交互更新

- 工程师端删除“查看正视图渲染图”和旧高保真导出相关入口。
- “快速导出 / 完美导出”改名为“快速渲染 / 高质量渲染”，改为页内弹窗播放。
- 工程师渲染弹窗和离线播放器均支持选择本地路径保存 HTML（浏览器不支持时退回普通下载）。
- 用户端增加快速/高质量渲染开关，默认快速预览路径。
- 用户播放器按需求缩小标题与位置面板字号、调整透明度与列宽、右下角固定白色开发支持文字。


## V0.2.5.2.4 天空背景优化

- 动画 HTML 天空渐变在原灰蓝基础上混入约 22% 黑色，降低整体亮度但保留层次。
- WebGL clear color、远景 fog color 与 Canvas 初始背景同步压暗，避免远景和加载阶段亮灰突变。
- 不修改模型材质、灯光强度、阴影、动画轨迹以及快速/高质量渲染功能。
