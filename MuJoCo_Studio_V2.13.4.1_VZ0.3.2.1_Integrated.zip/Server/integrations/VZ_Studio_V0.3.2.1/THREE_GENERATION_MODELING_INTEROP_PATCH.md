# Three-generation modeling exchange patch (VZ 0.3.2.1)

This package was modified for interoperability with V21.5 and MuJoCo Studio V2.9.3.

- Hierarchy names/parent relations are exchanged and external IDs are normalized only at the VZ import boundary.
- Mesh exchange focuses on object/file name, color and opacity.
- Joint category and parameters, including unsupported legacy parameters, are preserved.
- Drive/segment fields that VZ does not expose remain attached to imported activities and are overlaid back during export even after supported fields are edited.
- Invalid individual hierarchy/mesh/joint records are skipped or repaired instead of aborting the complete import.
- Measurement-pair import/export is selectable in the engineer UI.
## 规划 Prompt 固化

本包已将三代互通准则写入软件长期规划 Prompt。后续迭代应把该准则作为持续兼容合同，
而不是一次性补丁；若未来新增运动副、驱动字段或重构导入导出，必须执行三代往返回归。

