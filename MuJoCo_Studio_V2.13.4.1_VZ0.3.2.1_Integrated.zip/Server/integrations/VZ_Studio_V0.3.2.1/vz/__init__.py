"""VZ Studio standalone backend."""

__version__ = "0.3.2.1"
