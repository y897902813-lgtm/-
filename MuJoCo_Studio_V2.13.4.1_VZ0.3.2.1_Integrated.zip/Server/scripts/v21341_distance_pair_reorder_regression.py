#!/usr/bin/env python3
"""Focused V2.13.4.1 regression: distance-pair drag reorder + authoritative list order."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.app.domain.models import DistancePairSpec, ProjectSpec


def text(relative: str) -> str:
    return (ROOT / relative).read_text("utf-8")


def extract_js_function(source: str, name: str) -> str:
    marker = f"function {name}("
    start = source.index(marker)
    brace = source.index("{", start)
    depth = 0
    quote = ""
    escaped = False
    for index in range(brace, len(source)):
        char = source[index]
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = ""
            continue
        if char in {"'", '"', "`"}:
            quote = char
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return source[start:index + 1]
    raise AssertionError(f"could not extract JS function {name}")


def test_version_and_architecture() -> None:
    assert text("VERSION").strip() == "2.13.4.1"
    architecture = text("architecture_master_prompt.md")
    assert "第九十一部分：V2.13.4.1 测距对拖拽排序规范" in architecture
    assert "排序权威仍是 `ProjectSpec.distance_pairs`" in architecture
    assert "新增业务 Tool 目录 **0**" in architecture
    assert "新增 ProjectSpec/L1/L2/L3/Session/Job 权威持久字段 **0**" in architecture
    assert "Server 当前版本严格更新为 **2.13.4.1**" in architecture


def test_ui_drag_contract() -> None:
    js = text("frontend/app.js")
    css = text("frontend/styles.css")
    assert 'data-pair-card data-pair-id="${esc(pair.id)}"' in js
    assert 'data-pair-drag-handle="${esc(pair.id)}"' in js
    assert "activeDistancePairDragId" in js
    assert "application/x-distance-pair" in js
    assert "pair-drop-before" in js and "pair-drop-after" in js
    assert "reorderDistancePairList(list, draggedPairId, targetPairId, before)" in js
    assert "markDirty();\n      renderPairs();\n      commitCurrentStep('测距对顺序已更新', true)" in js
    assert ".pair-v21341-drag-handle" in css
    assert ".pair-card-v2134.dragging" in css
    assert ".pair-card-v2134.pair-drop-before" in css
    assert ".pair-card-v2134.pair-drop-after" in css


def test_reorder_helper_behavior() -> None:
    js = text("frontend/app.js")
    helper = extract_js_function(js, "reorderDistancePairList")
    test_source = helper + r'''
const ids = list => list.map(item => item.id).join(',');
let a = [{id:'a'},{id:'b'},{id:'c'}];
if (!reorderDistancePairList(a,'c','a',true) || ids(a) !== 'c,a,b') process.exit(11);
let b = [{id:'a'},{id:'b'},{id:'c'}];
if (!reorderDistancePairList(b,'a','c',false) || ids(b) !== 'b,c,a') process.exit(12);
let c = [{id:'a'},{id:'b'},{id:'c'}];
if (reorderDistancePairList(c,'b','b',true) || ids(c) !== 'a,b,c') process.exit(13);
let d = [{id:'a'},{id:'b'},{id:'c'}];
if (reorderDistancePairList(d,'missing','a',true) || ids(d) !== 'a,b,c') process.exit(14);
'''
    subprocess.run(["node", "-e", test_source], check=True, cwd=ROOT)


def test_projectspec_order_roundtrip() -> None:
    project = ProjectSpec(
        id="pair_order_regression",
        name="pair order regression",
        distance_pairs=[
            DistancePairSpec(id="pair_c", name="C"),
            DistancePairSpec(id="pair_a", name="A"),
            DistancePairSpec(id="pair_b", name="B"),
        ],
    )
    dumped = project.model_dump() if hasattr(project, "model_dump") else project.dict()
    assert [item["id"] for item in dumped["distance_pairs"]] == ["pair_c", "pair_a", "pair_b"]
    if hasattr(ProjectSpec, "model_validate"):
        restored = ProjectSpec.model_validate(dumped)
    else:
        restored = ProjectSpec.parse_obj(dumped)
    assert [item.id for item in restored.distance_pairs] == ["pair_c", "pair_a", "pair_b"]
    field_map = DistancePairSpec.model_fields if hasattr(DistancePairSpec, "model_fields") else DistancePairSpec.__fields__
    pair_fields = set(field_map)
    assert not ({"order", "sort_index", "sort_order"} & pair_fields)


def main() -> int:
    test_version_and_architecture()
    test_ui_drag_contract()
    test_reorder_helper_behavior()
    test_projectspec_order_roundtrip()
    print("V2.13.4.1 distance-pair drag reorder regression: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
