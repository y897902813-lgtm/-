#!/usr/bin/env python3
"""Generate the offline MuJoCo timeline-optimization login GLB.

The layout mirrors Server/scripts/build_login_glb_blender.py and exists so the
release can be rebuilt in headless CI where Blender is not installed.
"""
import json, math, random, struct
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "frontend" / "login_mujoco_timeline.glb"
groups = {}

def add(name, verts, norms, faces, role="decor"):
    p, n, ix = groups.setdefault((role, name), [[], [], []]); base = len(p)//3
    p.extend(v for q in verts for v in q); n.extend(v for q in norms for v in q)
    ix.extend(base+i for f in faces for i in f)

def torus(name, R, r, major=72, minor=12, tilt=(0,0,0), phase=0, role="decor"):
    verts=[]; norms=[]; faces=[]
    cx,sx=math.cos(tilt[0]),math.sin(tilt[0]); cy,sy=math.cos(tilt[1]),math.sin(tilt[1]); cz,sz=math.cos(tilt[2]),math.sin(tilt[2])
    def rot(v):
        x,y,z=v; y,z=y*cx-z*sx,y*sx+z*cx; x,z=x*cy+z*sy,-x*sy+z*cy; return (x*cz-y*sz,x*sz+y*cz,z)
    for i in range(major):
        a=2*math.pi*i/major+phase
        for j in range(minor):
            b=2*math.pi*j/minor; nn=rot((math.cos(a)*math.cos(b),math.sin(a)*math.cos(b),math.sin(b)))
            cc=rot((R*math.cos(a),R*math.sin(a),0)); verts.append(tuple(cc[k]+r*nn[k] for k in range(3))); norms.append(nn)
    for i in range(major):
        for j in range(minor):
            a=i*minor+j;b=((i+1)%major)*minor+j;c=((i+1)%major)*minor+(j+1)%minor;d=i*minor+(j+1)%minor;faces += [(a,b,c),(a,c,d)]
    add(name,verts,norms,faces,role)

def gear(name, inner, outer, depth, teeth=28, tooth_depth=.12, phase=0, role="core"):
    """Build a bevel-faced annular gear with a genuinely open centre."""
    verts=[]; norms=[]; faces=[]; half=depth/2; segments=teeth*4
    bevel=min(depth*.22,(outer-inner)*.13,.045)
    def radius_at(i): return outer+(tooth_depth if i%4 in (1,2) else 0)
    def point(a,r,z): return (math.cos(a)*r,math.sin(a)*r,z)
    def quad(points,normal):
        base=len(verts); verts.extend(points); norms.extend([normal]*4)
        faces.extend(((base,base+1,base+2),(base,base+2,base+3)))
    for i in range(segments):
        a0=phase+2*math.pi*i/segments; a1=phase+2*math.pi*(i+1)/segments; am=(a0+a1)/2
        r0=radius_at(i); r1=radius_at(i+1); co,si=math.cos(am),math.sin(am); d=math.sqrt(.5)
        ot0=point(a0,r0-bevel,half); ot1=point(a1,r1-bevel,half)
        os0=point(a0,r0,half-bevel); os1=point(a1,r1,half-bevel)
        ob0=point(a0,r0,-half+bevel); ob1=point(a1,r1,-half+bevel)
        of0=point(a0,r0-bevel,-half); of1=point(a1,r1-bevel,-half)
        it0=point(a0,inner+bevel,half); it1=point(a1,inner+bevel,half)
        is0=point(a0,inner,half-bevel); is1=point(a1,inner,half-bevel)
        ib0=point(a0,inner,-half+bevel); ib1=point(a1,inner,-half+bevel)
        iff0=point(a0,inner+bevel,-half); iff1=point(a1,inner+bevel,-half)
        quad((ot0,ot1,it1,it0),(0,0,1)); quad((of0,iff0,iff1,of1),(0,0,-1))
        quad((os0,os1,ot1,ot0),(co*d,si*d,d)); quad((os0,ob0,ob1,os1),(co,si,0))
        quad((ob0,of0,of1,ob1),(co*d,si*d,-d)); quad((it0,it1,is1,is0),(-co*d,-si*d,d))
        quad((is0,is1,ib1,ib0),(-co,-si,0)); quad((ib0,ib1,iff1,iff0),(-co*d,-si*d,-d))
    add(name,verts,norms,faces,role)

def sphere(name, c, r, seg=20, rings=12, role="decor"):
    v=[];n=[];f=[]
    for j in range(rings+1):
        b=math.pi*j/rings
        for i in range(seg):
            a=2*math.pi*i/seg; nn=(math.sin(b)*math.cos(a),math.sin(b)*math.sin(a),math.cos(b)); n.append(nn);v.append(tuple(c[k]+r*nn[k] for k in range(3)))
    for j in range(rings):
        for i in range(seg):
            a=j*seg+i;b=a and j*seg+(i+1)%seg;c=(j+1)*seg+(i+1)%seg;d=(j+1)*seg+i
            if j: f.append((a,b,c))
            if j<rings-1:f.append((a,c,d))
    add(name,v,n,f,role)

def box(name,c,s,role="decor"):
    x,y,z=c; a,b,d=s[0]/2,s[1]/2,s[2]/2
    vv=[(-a,-b,-d),(a,-b,-d),(a,b,-d),(-a,b,-d),(-a,-b,d),(a,-b,d),(a,b,d),(-a,b,d)]
    fs=[(0,2,1),(0,3,2),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(2,3,7),(2,7,6),(1,2,6),(1,6,5),(3,0,4),(3,4,7)]
    # Per-face normals are intentionally calculated from triangle geometry.
    verts=[];norms=[];faces=[]
    for tri in fs:
        q=[vv[i] for i in tri]; u=tuple(q[1][k]-q[0][k] for k in range(3)); w=tuple(q[2][k]-q[0][k] for k in range(3)); nn=(u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0]); L=math.sqrt(sum(t*t for t in nn));nn=tuple(t/L for t in nn)
        base=len(verts);verts += [(px+x,py+y,pz+z) for px,py,pz in q];norms += [nn]*3;faces.append((base,base+1,base+2))
    add(name,verts,norms,faces,role)

def radial_box_ring(name, radius, size, count, z=0.0, phase=0.0, role="core"):
    sx, sy, sz = size
    hx, hy, hz = sx/2, sy/2, sz/2
    base_verts=[(-hx,-hy,-hz),(hx,-hy,-hz),(hx,hy,-hz),(-hx,hy,-hz),(-hx,-hy,hz),(hx,-hy,hz),(hx,hy,hz),(-hx,hy,hz)]
    faces=[(0,2,1),(0,3,2),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(2,3,7),(2,7,6),(1,2,6),(1,6,5),(3,0,4),(3,4,7)]
    for i in range(count):
        a = phase + 2*math.pi*i/count
        ca, sa = math.cos(a), math.sin(a)
        cx, cy = radius*ca, radius*sa
        verts=[]; norms=[]; idx=[]
        for tri in faces:
            tri_verts=[]
            for vi in tri:
                x,y,z0 = base_verts[vi]
                # local x extends radially; local y extends tangentially
                wx = cx + x*ca - y*sa
                wy = cy + x*sa + y*ca
                wz = z + z0
                tri_verts.append((wx,wy,wz))
            u=tuple(tri_verts[1][k]-tri_verts[0][k] for k in range(3))
            w=tuple(tri_verts[2][k]-tri_verts[0][k] for k in range(3))
            nn=(u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0])
            L=math.sqrt(sum(t*t for t in nn)) or 1.0
            nn=tuple(t/L for t in nn)
            base=len(verts)
            verts += tri_verts
            norms += [nn]*3
            idx.append((base,base+1,base+2))
        add(name, verts, norms, idx, role)

# Three orbital time axes retain the v4 thickness, material and natural tilt.
torus("steel",2.72,.105,tilt=(.95,.12,.22),role="ring-a"); torus("white",2.18,.075,tilt=(.20,1.05,-.35),role="ring-b"); torus("dark",3.28,.055,tilt=(1.24,.62,.12),role="ring-c")
# The centre borrows the stronger Integrated (5) gear language.  A thick,
# emissive reactor ring sits inside the gear exactly where the review marked it.
gear("silvercore",.74,1.34,.34,28,.16,phase=.02,role="core")
gear("dark",.47,.72,.25,22,.115,phase=.09,role="core")
torus("steel",1.105,.042,major=88,minor=14,role="core")
radial_box_ring("silvercore", 1.118, (.16,.030,.085), 24, z=0.0, phase=.04, role="core")
radial_box_ring("dark", 1.045, (.11,.042,.090), 24, z=0.0, phase=.04 + math.pi/24, role="core")
torus("steel",.985,.045,major=84,minor=14,role="core")
torus("white",.875,.034,major=80,minor=12,role="core")
radial_box_ring("cyan", .965, (.24,.060,.080), 18, z=0.0, phase=.08, role="core")
radial_box_ring("white", .905, (.09,.040,.064), 18, z=0.0, phase=.08 + math.pi/18, role="core")
radial_box_ring("cyan", .700, (.10,.040,.050), 12, z=0.0, phase=.02, role="core")
# V12 front-face photon rails: thin emissive slots float just above the machined face.
radial_box_ring("cyan", 1.285, (.115,.024,.028), 28, z=.195, phase=.015, role="core")
torus("glow",1.235,.018,major=96,minor=10,role="core")
radial_box_ring("cyan", .665, (.095,.024,.026), 16, z=.155, phase=.05, role="core")
torus("white",.785,.055,major=72,minor=14,role="core")
torus("glow",.555,.125,major=72,minor=18,role="core")
torus("white",.455,.040,major=64,minor=12,role="core")
torus("cyan",.385,.055,major=64,minor=12,role="core")
torus("glow",.305,.030,major=56,minor=12,role="core")
for i in range(14):
    a=2*math.pi*i/14; rr=2.72; z=.58*math.sin(3*a); c=(rr*math.cos(a),rr*math.sin(a),z)
    sphere("cyan" if i%4==0 else "white",c,.12 if i%4==0 else .07,12,8,role="orbit-coin")
# Removed the surrounding orbit-bar cylinders per review.
# Optimization trajectory: a narrowing helix converging into the MuJoCo core.
for i in range(34):
    t=i/33; a=5.3*math.pi*t-.4; rr=3.6*(1-t)+.52*t; c=(rr*math.cos(a),rr*math.sin(a),1.55-2.05*t)
    sphere("cyan" if i%5==0 else "white",c,.105*(1-.35*t),12,8,role="trajectory")

# Denser, larger blue energy particles.  The seeded cloud keeps releases
# deterministic while concentrating visible particles around the core.
rng=random.Random(0x21215)
for i in range(132):
    a=rng.random()*2*math.pi; rr=.88+(rng.random()**.68)*2.65
    c=(rr*math.cos(a),rr*math.sin(a),(.5-rng.random())*(.42+rr*.25))
    radius=.055+(rng.random()**1.8)*.085
    sphere("cyan" if i%5 else "white",c,radius,10,7,role="energy-baked")

materials=[
 {"name":"Blue Steel","pbrMetallicRoughness":{"baseColorFactor":[.18,.46,.68,1],"metallicFactor":.97,"roughnessFactor":.12}},
 {"name":"Ceramic Steel","pbrMetallicRoughness":{"baseColorFactor":[.74,.83,.90,1],"metallicFactor":.86,"roughnessFactor":.08}},
 {"name":"Optimization Cyan","pbrMetallicRoughness":{"baseColorFactor":[.20,.73,1.0,1],"metallicFactor":.46,"roughnessFactor":.055},"emissiveFactor":[.48,1.08,1.48]},
 {"name":"Graphite","pbrMetallicRoughness":{"baseColorFactor":[.012,.045,.072,1],"metallicFactor":.94,"roughnessFactor":.18}},
 {"name":"Reactor Blue","pbrMetallicRoughness":{"baseColorFactor":[.16,.75,1.0,1],"metallicFactor":.34,"roughnessFactor":.042},"emissiveFactor":[.78,1.18,1.52]},
 {"name":"Brushed Silver Core","pbrMetallicRoughness":{"baseColorFactor":[.56,.67,.80,1],"metallicFactor":1.0,"roughnessFactor":.075}}
]
blob=bytearray(); views=[]; access=[]; primitives=[]
material_index={name:i for i,name in enumerate(("steel","white","cyan","dark","glow","silvercore"))}
for (role,name),(pos,nor,idx) in groups.items():
    mi=material_index[name]
    while len(blob)%4: blob.append(0)
    po=len(blob); blob.extend(struct.pack('<%sf'%len(pos),*pos)); views.append({"buffer":0,"byteOffset":po,"byteLength":len(pos)*4,"target":34962}); pa=len(access); access.append({"bufferView":len(views)-1,"componentType":5126,"count":len(pos)//3,"type":"VEC3","min":[min(pos[k::3]) for k in range(3)],"max":[max(pos[k::3]) for k in range(3)]})
    no=len(blob); blob.extend(struct.pack('<%sf'%len(nor),*nor)); views.append({"buffer":0,"byteOffset":no,"byteLength":len(nor)*4,"target":34962}); na=len(access); access.append({"bufferView":len(views)-1,"componentType":5126,"count":len(nor)//3,"type":"VEC3"})
    io=len(blob); blob.extend(struct.pack('<%sI'%len(idx),*idx)); views.append({"buffer":0,"byteOffset":io,"byteLength":len(idx)*4,"target":34963}); ia=len(access); access.append({"bufferView":len(views)-1,"componentType":5125,"count":len(idx),"type":"SCALAR"})
    primitives.append({"attributes":{"POSITION":pa,"NORMAL":na},"indices":ia,"material":mi,"mode":4,"extras":{"role":role}})
gltf={"asset":{"version":"2.0","generator":"MuJoCo Studio Blender-compatible procedural builder"},"scene":0,"scenes":[{"nodes":[0]}],"nodes":[{"name":"MuJoCo Timeline Optimization Core","mesh":0}],"meshes":[{"name":"DynamicsCore","primitives":primitives}],"materials":materials,"buffers":[{"byteLength":len(blob)}],"bufferViews":views,"accessors":access}
js=json.dumps(gltf,separators=(',',':')).encode(); js+=b' '*((4-len(js)%4)%4); blob+=b'\0'*((4-len(blob)%4)%4)
OUT.write_bytes(struct.pack('<4sII',b'glTF',2,12+8+len(js)+8+len(blob))+struct.pack('<I4s',len(js),b'JSON')+js+struct.pack('<I4s',len(blob),b'BIN\0')+blob)
print(f"wrote {OUT} ({OUT.stat().st_size} bytes)")
