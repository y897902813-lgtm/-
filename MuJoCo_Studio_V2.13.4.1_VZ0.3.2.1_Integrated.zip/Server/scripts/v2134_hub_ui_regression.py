#!/usr/bin/env python3
"""Focused V2.13.4 regression: Hub lightweight refresh/order + baseline sort + distance UI."""
from __future__ import annotations

import ast
import copy
import re
import sys
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.app.domain.models import ProjectSpec


def text(relative: str) -> str:
    return (ROOT / relative).read_text("utf-8")


def test_version_and_architecture() -> None:
    assert tuple(int(part) for part in text("VERSION").strip().split(".")) >= (2, 13, 4)
    architecture = text("architecture_master_prompt.md")
    assert "第九十部分：V2.13.4" in architecture
    assert "新增业务 Tool 目录 **0**" in architecture
    assert "新增 ProjectSpec/L1/L2/L3/Session/Job 权威持久字段 **0**" in architecture
    assert "Server 当前版本严格更新为 **2.13.4**" in architecture


def test_hub_sort_and_toast_contract() -> None:
    html = text("frontend/index.html")
    js = text("frontend/app.js")
    css = text("frontend/styles.css")
    assert 'id="hubBaselineSortToggle"' in html
    assert 'id="hubSort"' not in html
    assert "hubBaselineSortDescending" in js
    assert "基线：早 → 晚" in js and "基线：晚 → 早" in js
    assert "const baselineOrder=(projectStatus(a)==='baseline')-(projectStatus(b)==='baseline')" in js
    assert "hubBaselineFrozenAt(a).localeCompare(hubBaselineFrozenAt(b))" in js
    # The last V2.13.4 override must explicitly cancel historical bottom anchoring.
    tail = css[css.rfind("/* V2.13.4 Hub top-right notices"):]
    assert ".toast-region{top:16px!important;bottom:auto!important;right:16px!important;left:auto!important}" in tail
    assert "@media(max-width:760px){.toast-region{top:8px!important;bottom:auto!important;right:8px!important;left:auto!important}" in tail


def test_lightweight_hub_property_refresh_contract() -> None:
    js = text("frontend/app.js")
    main = text("backend/app/main.py")
    assert "hydrateProjectCatalogDetails" not in js
    assert "primeHubPreviewFromCatalog" in js
    assert "syncHubCatalogFromPreview" in js
    assert "waitForMetadata:false" in js
    assert "hubArchiveDragActive" in js
    assert "addEventListener('dragend'" in js
    assert "void saveHubArchiveOrder(order)" in js
    assert "async function saveHubArchiveOrder(order)" in js
    assert "/hub-properties" in js
    assert "state.hubPreviewCache.delete(projectId)" in js and "loadHubPreview(projectId,{force:true,waitForMetadata:false})" in js
    assert "class HubProjectPropertiesRequest" in main
    assert '@app.patch("/api/projects/{project_id}/hub-properties")' in main
    route = main[main.index('@app.patch("/api/projects/{project_id}/hub-properties")'):main.index("def _version_comparison_text")]
    assert '"tool_id": "project.replace"' in route
    assert 'current.lifecycle.status != "checked_out"' in route
    assert "_project_preview(working, include_latest_result=False)" in route



def test_lightweight_patch_behavior() -> None:
    """Exercise the extracted route without importing FastAPI/passlib runtime."""
    source = text("backend/app/main.py")
    tree = ast.parse(source)
    node = next(item for item in tree.body if isinstance(item, ast.FunctionDef) and item.name == "update_hub_project_properties")
    node.decorator_list = []
    module = ast.Module(body=[node], type_ignores=[])
    ast.fix_missing_locations(module)

    class FakeHTTPException(RuntimeError):
        def __init__(self, *, status_code: int, detail: Any):
            super().__init__(str(detail))
            self.status_code = status_code
            self.detail = detail

    class FakeStore:
        def unique_project_name(self, _category, requested, *, exclude_project_id=None):
            assert exclude_project_id
            return requested

        def delivery_directory(self, _project):
            return ROOT / ".v2134-regression-delivery"

        def move_delivery_tree(self, *_args, **_kwargs):
            raise AssertionError("constant fake delivery path must not move")

        def rename_baseline_history_reference(self, *_args, **_kwargs):
            return None

    class FakeBus:
        def __init__(self, owner):
            self.owner = owner
            self.calls = []

        def dispatch(self, payload):
            self.calls.append(payload)
            assert payload["tool_id"] == "project.replace"
            self.owner.current = ProjectSpec.model_validate(payload["params"]["project"])
            return SimpleNamespace(ok=True, errors=[])

    class FakeInstance:
        def __init__(self, project):
            self.current = project
            self.bus = FakeBus(self)

        def project(self):
            return self.current

    class FakeCore:
        def __init__(self, instance):
            self.instance = instance

        @contextmanager
        def acquire(self, _project_id):
            yield self.instance

    def fake_preview(project, *, include_latest_result=False):
        assert include_latest_result is False
        known = ["motion_time", "seg:motion_value"]
        order = [key for key in project.archive_order if key in known]
        order += [key for key in known if key not in order]
        return {"archive_order": order, "archive_fields": [{"key": key} for key in order]}

    def fake_apply_archive_name(_project, *, preview=None):
        assert preview is None or "archive_order" in preview

    def fake_access(_project, *, write=False):
        assert write is True
        return SimpleNamespace(username="regression")

    current = ProjectSpec(
        id="v2134_patch", name="模型A",
        lifecycle={"status": "checked_out", "checked_out_by": "regression"},
        archive_order=["motion_time", "seg:motion_value"],
        metadata={"updated_at": "before"},
    )
    instance = FakeInstance(current)
    scope = {
        "Any": Any,
        "HubProjectPropertiesRequest": object,
        "HTTPException": FakeHTTPException,
        "ProjectSpec": ProjectSpec,
        "copy": copy,
        "core": FakeCore(instance),
        "store": FakeStore(),
        "require_project_access": fake_access,
        "_project_preview": fake_preview,
        "_apply_archive_name": fake_apply_archive_name,
    }
    exec(compile(module, "<v2134-hub-properties>", "exec"), scope)
    route = scope["update_hub_project_properties"]

    result = route("v2134_patch", SimpleNamespace(name=None, archive_order=["seg:motion_value", "motion_time", "seg:motion_value"]))
    assert result["archive_order"] == ["seg:motion_value", "motion_time"]
    assert instance.current.archive_order == ["seg:motion_value", "motion_time"]
    assert len(instance.bus.calls) == 1

    renamed = route("v2134_patch", SimpleNamespace(name="模型B", archive_order=None))
    assert renamed["name"] == "模型B" and instance.current.name == "模型B"
    assert len(instance.bus.calls) == 2

    instance.current.lifecycle.status = "checked_in"
    try:
        route("v2134_patch", SimpleNamespace(name=None, archive_order=["motion_time"]))
    except FakeHTTPException as exc:
        assert exc.status_code == 409
    else:
        raise AssertionError("checked-in project must reject archive-order writes")

def test_distance_pair_ui_and_defaults() -> None:
    js = text("frontend/app.js")
    css = text("frontend/styles.css")
    models = text("backend/app/domain/models.py")
    assert "pair-card-v2134" in js and "pair-v2134-identity" in js
    assert 'aria-label="测距对名称"' in js
    assert "<b>对象A</b>" in js and "<b>对象B</b>" in js
    assert '<details class="pair-v2134-advanced"><summary>高级设置</summary>' in js
    assert "精确撒点间隙" in js and "寻优边界" in js
    assert "pair-v2134-main" in css
    new_pair = re.search(r"function newPair\(\).*?\n", js)
    assert new_pair, "newPair() missing"
    row = new_pair.group(0)
    assert "precise_spacing_mm:2" in row
    assert "animation_spacing_mm:2" in row
    assert "boundary_mm:8" in row
    assert re.search(r"precise_spacing_mm: float = Field\(default=2\.0, gt=0\)", models)
    assert re.search(r"animation_spacing_mm: float = Field\(default=2\.0, gt=0\)", models)
    assert re.search(r"boundary_mm: float = Field\(\s*default=8\.0", models)


def main() -> int:
    test_version_and_architecture()
    test_hub_sort_and_toast_contract()
    test_lightweight_hub_property_refresh_contract()
    test_lightweight_patch_behavior()
    test_distance_pair_ui_and_defaults()
    print("V2.13.4 Hub lightweight refresh + archive order + baseline sort + distance UI regression: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
