"""Blender 3.6+ rebuild source for frontend/login_mujoco_timeline.glb.

Run: blender --background --python Server/scripts/build_login_glb_blender.py
"""
import bpy, math, random
from pathlib import Path
from mathutils import Vector

OUT = Path(__file__).resolve().parents[1] / "frontend" / "login_mujoco_timeline.glb"
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)

def material(name, color, metal=.8, rough=.18, emission=None):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*color,1); p.inputs['Metallic'].default_value=metal; p.inputs['Roughness'].default_value=rough
    if emission:
        socket=p.inputs.get('Emission Color') or p.inputs.get('Emission'); socket.default_value=(*emission,1); p.inputs['Emission Strength'].default_value=2.8
    return m

steel=material('Blue Steel',(.10,.34,.47),.94,.18); white=material('Ceramic Steel',(.72,.91,.98),.72,.14); cyan=material('Optimization Cyan',(.02,.48,.78),.35,.12,(.02,.42,.8)); dark=material('Graphite',(.015,.055,.08),.92,.2); glow=material('Reactor Blue',(.01,.38,.82),.28,.08,(.08,.72,1.0))
def torus(name,R,r,rot,mat):
    bpy.ops.mesh.primitive_torus_add(major_radius=R,minor_radius=r,major_segments=72,minor_segments=12,rotation=rot); o=bpy.context.object;o.name=name;o.data.materials.append(mat);return o
def sphere(name,loc,r,mat,segments=20):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=12,radius=r,location=loc);o=bpy.context.object;o.name=name;o.data.materials.append(mat);bpy.ops.object.shade_smooth();return o
def gear(name,inner,outer,depth,teeth,tooth_depth,mat,phase=0):
    segments=teeth*4;half=depth/2;verts=[];faces=[]
    for i in range(segments):
        a=phase+2*math.pi*i/segments;r=outer+(tooth_depth if i%4 in (1,2) else 0);c,s=math.cos(a),math.sin(a)
        verts.extend([(c*r,s*r,half),(c*inner,s*inner,half),(c*r,s*r,-half),(c*inner,s*inner,-half)])
    for i in range(segments):
        j=(i+1)%segments;a=i*4;b=j*4
        faces.extend([(a,b,b+1,a+1),(b+2,a+2,a+3,b+3),(a+2,b+2,b,a),(b+3,a+3,a+1,b+1)])
    mesh=bpy.data.meshes.new(name+' Mesh');mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);o.data.materials.append(mat)
    bevel=o.modifiers.new('Machined bevel','BEVEL');bevel.width=.026;bevel.segments=2
    return o

torus('Time Orbit A',2.72,.105,(.95,.12,.22),steel);torus('Time Orbit B',2.18,.075,(.20,1.05,-.35),white);torus('Constraint Orbit',3.28,.055,(1.24,.62,.12),dark)
gear('Primary Dynamics Gear',.74,1.34,.34,28,.16,steel,.02);gear('Portal Gear',.47,.72,.25,22,.115,dark,.09)
torus('Gear Highlight',.785,.055,(0,0,0),white);torus('Reactor Glow Ring',.555,.125,(0,0,0),glow);torus('Inner Energy Rim',.385,.055,(0,0,0),cyan)
for i in range(28):
    a=2*math.pi*i/28;c=(2.72*math.cos(a),2.72*math.sin(a),.58*math.sin(3*a));sphere(f'Keyframe {i:02}',c,.12 if i%7==0 else .07,cyan if i%7==0 else white,12)
for i in range(34):
    t=i/33;a=5.3*math.pi*t-.4;r=3.6*(1-t)+.52*t;sphere(f'Convergence {i:02}',(r*math.cos(a),r*math.sin(a),1.55-2.05*t),.105*(1-.35*t),cyan if i%5==0 else white,12)
rng=random.Random(0x21215)
for i in range(132):
    a=rng.random()*2*math.pi;r=.88+(rng.random()**.68)*2.65;loc=(r*math.cos(a),r*math.sin(a),(.5-rng.random())*(.42+r*.25));radius=.055+(rng.random()**1.8)*.085
    sphere(f'Energy Particle {i:03}',loc,radius,cyan if i%5 else white,10)
for i in range(36):
    a=2*math.pi*i/36;bpy.ops.mesh.primitive_cube_add(size=1,location=(3.46*math.cos(a),3.46*math.sin(a),.18*math.sin(2*a)));o=bpy.context.object;o.name=f'Time Tick {i:02}';o.scale=(.055,.055,.48 if i%6==0 else .28);o.data.materials.append(cyan if i%6==0 else steel)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
bpy.ops.export_scene.gltf(filepath=str(OUT),export_format='GLB',export_materials='EXPORT',export_cameras=False,export_lights=False,export_yup=True)
print('Exported',OUT)
