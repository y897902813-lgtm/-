#!/usr/bin/env python3
"""Focused V2.13.2 regression: Hub->VZ calibration, runtime joint scenes and result-view UI contracts."""
from __future__ import annotations

import ast
import copy
import io
import math
import re
import sys
import tempfile
import typing
import zipfile
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.app.domain.models import DriveSegmentSpec, DriveSpec, JointSpec, LayerSpec, ProjectSpec
from backend.app.domain.time_series_library import build_time_series_bundle

VZ_ROOT = ROOT / "integrations" / "VZ_Studio_V0.3.2.1"
if str(VZ_ROOT) not in sys.path:
    sys.path.insert(0, str(VZ_ROOT))
from vz.models import make_demo_model, validate_model
from vz.scene_composition import compose_scene, compose_scene_timeline, instance_suffix
from vz.store import ModelStore


def text(relative: str) -> str:
    return (ROOT / relative).read_text("utf-8")


def load_drive_projection_helpers():
    """Load two pure helpers from main.py without importing FastAPI/runtime deps."""
    source = text("backend/app/main.py")
    tree = ast.parse(source)
    wanted = {"_vz_version_tuple", "_vz_engineer_drive_settings"}
    nodes = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in wanted]
    assert {node.name for node in nodes} == wanted
    module = ast.Module(body=nodes, type_ignores=[])
    ast.fix_missing_locations(module)
    scope = {
        "Any": typing.Any,
        "ProjectSpec": object,
        "math": math,
        "re": re,
    }
    exec(compile(module, "<v2132-main-helpers>", "exec"), scope)
    return scope["_vz_engineer_drive_settings"]


def test_hub_vz_drive_projection() -> None:
    helper = load_drive_projection_helpers()
    project = SimpleNamespace(drives=[
        SimpleNamespace(id="drive_main", name="主驱动", joint_id="joint_main", enabled=True, role="source"),
        SimpleNamespace(id="drive_aux", name="副驱动", joint_id="joint_aux", enabled=False, role="follower"),
    ])
    parts = helper(project, None)
    assert len(parts) == 2
    first = parts[0]["motions"][0]
    assert first["name"] == "主驱动" and first["joint_id"] == "joint_main"
    assert first["position_0_percent"] == 0.0
    assert first["position_100_percent"] == 30.0
    assert first["rated_speed"] == 30.0
    assert first["exchange_drive_id"] == "drive_main"
    assert "exchange_segment" not in first

    existing = {
        "_hub_source": {"source_version": "2.13.2"},
        "activity_parts": [{"motions": [{
            "exchange_drive_id": "drive_main",
            "position_0_percent": -12.5,
            "position_100_percent": 77.0,
            "rated_speed": 18.0,
            "mode": "mapping",
        }]}],
    }
    refreshed = helper(project, existing)[0]["motions"][0]
    assert refreshed["name"] == "主驱动" and refreshed["joint_id"] == "joint_main"
    assert refreshed["position_0_percent"] == -12.5
    assert refreshed["position_100_percent"] == 77.0
    assert refreshed["rated_speed"] == 18.0
    assert refreshed["mode"] == "mapping"


def test_runtime_scene_composition() -> None:
    source = make_demo_model()
    # Add one closure so names + endpoint/joint cross-references are also covered.
    base_id = source["layers"][0]["id"]
    arm_id = source["layers"][1]["id"]
    joint_id = source["layers"][1]["joints"][0]["id"]
    source["kinematic_closures"] = [{
        "id": "closure_same",
        "name": "同名闭链",
        "enabled": True,
        "endpoint_a": {"layer_id": base_id, "point_mm": [0, 0, 0]},
        "endpoint_b": {"layer_id": arm_id, "point_mm": [0, 0, 45]},
        "solve_joint_ids": [joint_id],
        "tolerance_mm": 0.05,
        "max_iterations": 40,
        "damping": 0.0001,
        "max_angle_step_deg": 8,
        "max_slide_step_mm": 5,
    }]
    model = validate_model(source)
    drive_id = model["drives"][0]["id"]

    def schedule(start: float, travel: float) -> dict:
        return {"drives": [{
            "id": drive_id,
            "name": "同名驱动",
            "segments": [{
                "id": "segment_same",
                "name": "运动段",
                "start": start,
                "end": start + 1.0,
                "travel": travel,
                "profile": "s_curve",
                "mode": "speed",
            }],
        }]}

    entries = [
        {"node": {"id": "node_a", "transform_mm": [0, 0, 0]}, "model": copy.deepcopy(model), "model_dir": Path(tempfile.gettempdir()), "schedule": schedule(0.0, 10.0)},
        {"node": {"id": "node_b", "transform_mm": [100, 0, 0]}, "model": copy.deepcopy(model), "model_dir": Path(tempfile.gettempdir()), "schedule": schedule(0.5, 20.0)},
    ]
    composed = compose_scene(entries)
    combined = composed["model"]
    assert [item["suffix"] for item in composed["instances"]] == ["a", "b"]
    assert instance_suffix(25) == "z" and instance_suffix(26) == "aa"
    assert len(combined["layers"]) == len(model["layers"]) * 2
    assert len(combined["kinematic_closures"]) == 2
    assert len(combined["drives"]) == 2
    assert all(layer["name"].endswith(("_a", "_b")) for layer in combined["layers"])
    assert all(closure["name"].endswith(("_a", "_b")) for closure in combined["kinematic_closures"])
    assert all(drive["name"].endswith(("_a", "_b")) for drive in combined["drives"])
    assert all(drive["joint_id"].endswith(("_a", "_b")) for drive in combined["drives"])
    for closure in combined["kinematic_closures"]:
        suffix = closure["name"].rsplit("_", 1)[-1]
        assert closure["endpoint_a"]["layer_id"].endswith(f"_{suffix}")
        assert closure["endpoint_b"]["layer_id"].endswith(f"_{suffix}")
        assert all(value.endswith(f"_{suffix}") for value in closure["solve_joint_ids"])

    second_arm = next(layer for layer in combined["layers"] if layer["name"].endswith("_b") and layer.get("joints"))
    second_joint_point = [float(item.strip()) for item in second_arm["joints"][0]["point"].split(",")]
    assert second_joint_point[0] == 100.0

    timeline = compose_scene_timeline(combined, composed["instances"])
    assert len(timeline["segments"]) == 2
    assert abs(timeline["duration"] - 1.5) < 1e-12
    assert len({segment["drive_id"] for segment in timeline["segments"]}) == 2
    assert all(segment["drive_id"].endswith(("_a", "_b")) for segment in timeline["segments"])
    assert all(segment["speed"] > 0 for segment in timeline["segments"])


def test_time_series_position_projection() -> None:
    joint = JointSpec(id="joint_reg", name="驱动运动副", type="rotation")
    drive = DriveSpec(id="drive_reg", name="驱动A", joint_id=joint.id, segments=[
        DriveSegmentSpec(id="seg_1", name="第一段", start=1.0, duration=2.0, speed=5.0, travel=10.0),
        DriveSegmentSpec(id="seg_2", name="第二段", start=4.0, duration=1.0, speed=5.0, travel=-5.0),
    ])
    project = ProjectSpec(id="p2132", name="V2132时序", layers=[LayerSpec(id="layer", name="层", joints=[joint])], drives=[drive])
    name, content, _ = build_time_series_bundle(project, [])
    with tempfile.TemporaryDirectory(prefix="vz2132_ts_") as temp:
        store = ModelStore(Path(temp))
        model = store.create({"id": "vz2132_ts", "name": "V2132"}, preserve_id=True)
        payload = io.BytesIO()
        with zipfile.ZipFile(payload, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(name, content.encode("utf-8"))
        store.replace_time_series_archive(model["id"], payload.getvalue())
        schedule = store.time_series_schedule(model["id"], "hub", name)
        segments = schedule["drives"][0]["segments"]
        assert [(segment["position_start"], segment["position_end"]) for segment in segments] == [(0.0, 10.0), (10.0, 5.0)]


def test_ui_contracts() -> None:
    index_html = text("frontend/index.html")
    app_js = text("frontend/app.js")
    app_css = text("frontend/styles.css")
    main_py = text("backend/app/main.py")
    client_html = text("integrations/VZ_Studio_V0.3.2.1/frontend/client.html")
    client_js = text("integrations/VZ_Studio_V0.3.2.1/frontend/client.js")
    engineer_js = text("integrations/VZ_Studio_V0.3.2.1/frontend/engineer.js")
    engineer_css = text("integrations/VZ_Studio_V0.3.2.1/frontend/studio.css")
    server_py = text("integrations/VZ_Studio_V0.3.2.1/vz/server.py")

    assert tuple(int(part) for part in text("VERSION").strip().split(".")) >= (2, 13, 2)
    assert 'id="openViewerButton"' not in index_html
    assert 'id="exportAnimationHtmlButton"' not in index_html
    assert 'id="simulateButton" class="button primary">刷新结果<' in index_html
    assert index_html.index('id="exportNxAfuButton"') < index_html.index('id="axisHeightRange"') < index_html.index('id="addCursorButton"')
    assert index_html.index('id="regenerateEmbeddedAnimation"') < index_html.index('id="reloadEmbeddedAnimation"')
    assert "async function regenerateEmbeddedAnimation()" in app_js
    regen = app_js[app_js.index("async function regenerateEmbeddedAnimation()"):app_js.index("async function exportAnimationHtml()")]
    assert "export-animation-html" in regen and "chooseLocalSaveHandle" not in regen
    assert "autoDownload=Boolean(handle)" in app_js
    assert ".axis-height-toolbar" in app_css and "result-axis-head{padding:3px 5px!important" in app_css
    assert ".simulation-advanced-settings>summary" in app_css and ".animation-export-settings>summary" in app_css

    assert "def _vz_engineer_drive_settings" in main_py
    helper = main_py[main_py.index("def _vz_engineer_drive_settings"):main_py.index("def _vz_status_for_project")]
    assert '"position_0_percent": p0' in helper and '"position_100_percent": p100' in helper
    assert '"exchange_segment"' not in helper
    assert "previous_engineer_model" in main_py

    assert 'id="sceneDropZone"' in client_html and 'id="clientTimeSeriesEditor"' in client_html
    assert "scene_nodes" in server_py and "compose_scene(entries)" in server_py and "compose_scene_timeline" in server_py
    assert "addModelToScene(modelId)" in client_js and "text/vz-model-id" in client_js
    scene_start = client_js.index("function renderSceneControlBoard(){")
    scene_board = client_js[scene_start:client_js.index("\n\n$('#sceneTimeSeriesTabs')", scene_start)]
    assert "drives.flatMap" in scene_board and "全部驱动最早开始至最晚结束" in scene_board
    assert "for(const drive of series?.drives||[])" not in scene_board
    assert "Array.from({length:axisEnd+1}" in scene_board and "${index}s" in scene_board
    assert "openUserTimeSeriesEditor" in client_js and "data-user-ts-segment" in client_js
    assert "speed:fixedSpeed" in client_js and "双击色块修改起始时间与行程" in client_js

    assert "ts-block-time" in engineer_js and "ts-block-position" in engineer_js
    assert "position_start" in engineer_js and "position_end" in engineer_js
    assert "V2.13.2 · engineer WEB time-series blocks" in engineer_css
    assert "height:40px!important" in engineer_css

    architecture = text("architecture_master_prompt.md")
    assert "第八十八部分：V2.13.2" in architecture
    assert "新增业务 Tool 目录 **0**" in architecture
    assert "runtime-only" in architecture


def main() -> int:
    test_hub_vz_drive_projection()
    test_runtime_scene_composition()
    test_time_series_position_projection()
    test_ui_contracts()
    print("V2.13.2 Hub/VZ joint-scene/result-view regression: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
