"""Focused regression for V2.12.2.1 minimum-jerk drive mapping.

Runs without MuJoCo/passlib so release validation can isolate the mapping math
from optional/runtime dependencies.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend.app.domain.mapping_curve import (  # noqa: E402
    integrated_squared_jerk,
    inverse_mapping_value,
    mapping_derivatives,
    mapping_value,
)
from backend.app.domain.motion import normalize_mapping_points, _mapping_runtime_points  # noqa: E402


def natural_cubic_jerk_cost(points: tuple[tuple[float, float], ...]) -> float:
    n = len(points)
    if n < 3:
        return 0.0
    lower = [0.0] * n
    diagonal = [1.0] * n
    upper = [0.0] * n
    rhs = [0.0] * n
    for index in range(1, n - 1):
        h0 = points[index][0] - points[index - 1][0]
        h1 = points[index + 1][0] - points[index][0]
        lower[index] = h0
        diagonal[index] = 2.0 * (h0 + h1)
        upper[index] = h1
        rhs[index] = 6.0 * (
            (points[index + 1][1] - points[index][1]) / h1
            - (points[index][1] - points[index - 1][1]) / h0
        )
    for index in range(1, n):
        factor = lower[index] / diagonal[index - 1]
        diagonal[index] -= factor * upper[index - 1]
        rhs[index] -= factor * rhs[index - 1]
    second = [0.0] * n
    second[-1] = rhs[-1] / diagonal[-1]
    for index in range(n - 2, -1, -1):
        second[index] = (rhs[index] - upper[index] * second[index + 1]) / diagonal[index]
    second[0] = second[-1] = 0.0
    total = 0.0
    for index in range(n - 1):
        width = points[index + 1][0] - points[index][0]
        jerk = (second[index + 1] - second[index]) / width
        total += jerk * jerk * width
    return total


def python_contract() -> dict[str, float | int]:
    # Smooth nonlinear table: minimum-jerk must hit every row exactly while
    # lowering the global jerk functional relative to the old natural cubic.
    smooth = tuple(
        (i / 100.0, 0.4 * (i / 100.0) + 0.2 * (i / 100.0) ** 2 - 0.05 * (i / 100.0) ** 3)
        for i in range(101)
    )
    knot_error = max(abs(mapping_value(smooth, x) - y) for x, y in smooth)
    if knot_error > 1e-10:
        raise AssertionError(f"mapping knot error too large: {knot_error}")
    quintic_cost = integrated_squared_jerk(smooth, samples_per_segment=64)
    cubic_cost = natural_cubic_jerk_cost(smooth)
    if not quintic_cost < cubic_cost:
        raise AssertionError(f"minimum-jerk cost did not improve: {quintic_cost} >= {cubic_cost}")

    # Interior C2/C3 continuity check from both sides of each knot.
    max_acc_jump = 0.0
    max_jerk_jump = 0.0
    for index in range(1, len(smooth) - 1):
        x = smooth[index][0]
        eps = min(smooth[index][0] - smooth[index - 1][0], smooth[index + 1][0] - smooth[index][0]) * 1e-7
        left = mapping_derivatives(smooth, x - eps)
        right = mapping_derivatives(smooth, x + eps)
        max_acc_jump = max(max_acc_jump, abs(left[2] - right[2]))
        max_jerk_jump = max(max_jerk_jump, abs(left[3] - right[3]))
    if max_acc_jump > 1e-5 or max_jerk_jump > 1e-3:
        raise AssertionError(f"continuity regression: acc={max_acc_jump}, jerk={max_jerk_jump}")

    # Density is no longer a semantic branch: all 10,001 normalized points are
    # authoritative runtime knots, not silently reduced to 2,049.
    dense_raw = tuple(
        (-50.0 + 100.0 * i / 10000.0,
         0.35 * (-50.0 + 100.0 * i / 10000.0) + 0.002 * (-50.0 + 100.0 * i / 10000.0) ** 2
         + (0.0 if i in (0, 10000) else (1e-5 if i % 2 else -1e-5)))
        for i in range(10001)
    )
    dense = normalize_mapping_points(dense_raw)
    if len(_mapping_runtime_points(dense)) != len(dense):
        raise AssertionError("runtime mapping unexpectedly changed hard-knot count")
    dense_knot_error = max(abs(mapping_value(dense, x) - y) for x, y in dense[::997])
    if dense_knot_error > 1e-10:
        raise AssertionError(f"dense hard-knot error too large: {dense_knot_error}")

    # Forward/inverse use the same curve at imported mapping rows.
    inverse_error = max(abs(inverse_mapping_value(smooth, y, x) - x) for x, y in smooth)
    if inverse_error > 1e-9:
        raise AssertionError(f"inverse knot error too large: {inverse_error}")

    return {
        "knot_error": knot_error,
        "dense_knot_error": dense_knot_error,
        "min_jerk_cost": quintic_cost,
        "natural_cubic_cost": cubic_cost,
        "jerk_cost_ratio": quintic_cost / cubic_cost,
        "max_acc_continuity_delta": max_acc_jump,
        "max_jerk_continuity_delta": max_jerk_jump,
        "dense_runtime_knots": len(dense),
    }


def browser_parity() -> dict[str, float | int]:
    js_path = ROOT / "frontend" / "mapping_math.js"
    if not js_path.is_file():
        raise AssertionError("mapping_math.js missing")
    points = [[float(i), 0.11 * i + 0.002 * i * i + math.sin(i * 0.3) * 0.02] for i in range(-20, 41)]
    sources = [-19.75, -8.125, -0.4, 0.0, 7.777, 18.5, 39.875]
    normalized = normalize_mapping_points(points)
    expected_values = [mapping_value(normalized, source) for source in sources]
    expected_derivatives = [mapping_derivatives(normalized, source) for source in sources]

    with tempfile.TemporaryDirectory() as folder:
        probe = Path(folder) / "probe.js"
        payload = json.dumps({"points": points, "sources": sources}, ensure_ascii=False)
        probe.write_text(
            "const M=require(" + json.dumps(str(js_path)) + ");\n"
            "const input=" + payload + ";\n"
            "console.log(JSON.stringify({values:input.sources.map(x=>M.mapPosition(input.points,x)),"
            "derivatives:input.sources.map(x=>M.mapDerivatives(input.points,x)),runtime:M.runtimeRows(input.points).length}));\n",
            encoding="utf-8",
        )
        process = subprocess.run(["node", str(probe)], text=True, capture_output=True, check=True)
    actual = json.loads(process.stdout)
    value_delta = max(abs(a - b) for a, b in zip(expected_values, actual["values"]))
    derivative_delta = max(
        abs(a - b)
        for expected_row, actual_row in zip(expected_derivatives, actual["derivatives"])
        for a, b in zip(expected_row, actual_row)
    )
    if value_delta > 1e-10 or derivative_delta > 1e-8:
        raise AssertionError(f"browser parity failed: value={value_delta}, derivative={derivative_delta}")
    if actual["runtime"] != len(normalized):
        raise AssertionError("browser runtime knot count mismatch")
    return {"value_delta": value_delta, "derivative_delta": derivative_delta, "runtime_knots": actual["runtime"]}


if __name__ == "__main__":
    report = {"python": python_contract(), "browser": browser_parity()}
    print(json.dumps(report, ensure_ascii=False, indent=2))
