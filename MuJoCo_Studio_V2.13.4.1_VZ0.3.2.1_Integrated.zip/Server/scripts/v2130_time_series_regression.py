#!/usr/bin/env python3
"""Focused V2.13.0 regression: time-series round-trip + VZ projection contracts."""
from __future__ import annotations

import io
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.app.domain.models import DriveSegmentSpec, DriveSpec, JointSpec, LayerSpec, ProjectSpec
from backend.app.domain.project_store import ProjectStore
from backend.app.domain.time_series_library import build_time_series_bundle, parse_time_series_csv

VZ_ROOT = ROOT / "integrations" / "VZ_Studio_V0.3.2.1"
if str(VZ_ROOT) not in sys.path:
    sys.path.insert(0, str(VZ_ROOT))
from vz.store import ModelStore


def main() -> int:
    source = JointSpec(id="joint_source", name="主电机", type="rotation")
    follower = JointSpec(id="joint_follower", name="伴生电机", type="rotation")
    mapping = DriveSegmentSpec(
        id="seg_mapping",
        name="变速段",
        start=0.0,
        duration=2.0,
        travel=90.0,
        profile="mapping",
        mapping_source_joint_id=source.id,
        points=[[0.0, 0.0], [30.0, 8.0], [60.0, 42.0], [90.0, 90.0]],
        mapping_csv_name="legacy_mapping.csv",
        mapping_point_count=4,
    )
    drive = DriveSpec(
        id="drive_follower",
        name="伴生驱动",
        joint_id=follower.id,
        segments=[mapping],
    )
    project = ProjectSpec(
        id="project_v2130_regression",
        name="V2130回归模型",
        layers=[LayerSpec(id="layer_main", name="机构", joints=[source, follower])],
        drives=[drive],
    )
    axes = [{
        "name": "坐标系1",
        "times": [0.0, 1.0, 2.0],
        "curves": [{"label": "伴生位置", "values": [0.0, 42.0, 90.0], "unit": "deg"}],
    }]

    main_name, main_csv, mappings = build_time_series_bundle(project, axes)
    assert main_name.endswith("时序.csv")
    assert main_csv.lstrip("\ufeff").startswith("VZ_TIME_SERIES,1.0")
    assert "RESULT,坐标系1" in main_csv
    assert len(mappings) == 1
    assert mappings[0][0] == "伴生驱动--变速段映射表格.csv"
    assert "source,target" in mappings[0][1]

    parsed = parse_time_series_csv(main_csv, project)
    assert parsed["schema_version"] == "1.0"
    assert len(parsed["drives"]) == 1
    restored_drive = parsed["drives"][0]
    assert restored_drive["name"] == "伴生驱动"
    assert restored_drive["joint_id"] == follower.id
    restored_segment = restored_drive["segments"][0]
    assert restored_segment["profile"] == "mapping"
    assert restored_segment["mapping_source_joint_id"] == source.id
    assert restored_segment["points"] == mapping.points
    assert restored_segment["csv_path"] == ""

    with tempfile.TemporaryDirectory(prefix="hub2130_regression_") as temp:
        hub_store = ProjectStore(Path(temp))
        hub_store.save(project)
        assert hub_store.time_series_directory(project).is_dir()

    with tempfile.TemporaryDirectory(prefix="vz2130_regression_") as temp:
        store = ModelStore(Path(temp))
        model = store.create({"id": "vz2130_model", "name": "V2130模型"}, preserve_id=True)
        payload = io.BytesIO()
        with zipfile.ZipFile(payload, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(main_name, main_csv.encode("utf-8"))
            for name, content in mappings:
                archive.writestr(name, content.encode("utf-8"))
        manifest = store.replace_time_series_archive(model["id"], payload.getvalue())
        assert manifest["count"] == 2
        assert manifest["latest"] is not None
        assert manifest["latest"]["drives"][0]["name"] == "伴生驱动"
        seg = manifest["latest"]["drives"][0]["segments"][0]
        assert seg["name"] == "变速段"
        assert seg["variable_speed"] is True

        nested = io.BytesIO()
        with zipfile.ZipFile(nested, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(f"nested/{main_name}", main_csv.encode("utf-8"))
        try:
            store.replace_time_series_archive(model["id"], nested.getvalue())
        except ValueError as exc:
            assert "顶层普通 CSV" in str(exc)
        else:
            raise AssertionError("nested time-series ZIP must be rejected")
        assert store.time_series_manifest(model["id"])["count"] == 2

    client_html = (VZ_ROOT / "frontend" / "client.html").read_text("utf-8")
    client_js = (VZ_ROOT / "frontend" / "client.js").read_text("utf-8")
    client_css = (VZ_ROOT / "frontend" / "styles.css").read_text("utf-8")
    animation_py = (VZ_ROOT / "vz" / "animation_export.py").read_text("utf-8")
    engineer_html = (VZ_ROOT / "frontend" / "engineer.html").read_text("utf-8")
    engineer_js = (VZ_ROOT / "frontend" / "engineer.js").read_text("utf-8")

    assert 'id="clientNewFolder"' not in client_html
    assert 'id="clientRenameFolder"' not in client_html
    assert "clientCreateFolder" not in client_js and "clientMoveModel" not in client_js
    assert '.client-left{display:none!important}' in client_css.replace(" ", "")
    assert "timeSeriesCache" in client_js and "segment.profile" in client_js
    assert '"animation_watermark_text":""' in animation_py.replace(" ", "")
    assert '"scene_preset": "classic"' in animation_py
    assert "engineer-preview-strip" not in engineer_html
    assert "data-model-preview-generate" in engineer_js

    print("V2.13.0 time-series/VZ regression: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
