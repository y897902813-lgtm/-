#!/usr/bin/env python3
"""Focused V2.13.1 regression for VZ time-series copies, UI contracts, and CSV delivery boundary."""
from __future__ import annotations

import io
import json
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.app.domain.models import DriveSegmentSpec, DriveSpec, JointSpec, LayerSpec, ProjectSpec
from backend.app.domain.time_series_library import build_time_series_bundle

VZ_ROOT = ROOT / "integrations" / "VZ_Studio_V0.3.2.1"
if str(VZ_ROOT) not in sys.path:
    sys.path.insert(0, str(VZ_ROOT))
from vz.store import ModelStore


def text(relative: str) -> str:
    return (ROOT / relative).read_text("utf-8")


def main() -> int:
    assert tuple(int(part) for part in text("VERSION").strip().split(".")) >= (2, 13, 1)

    source = JointSpec(id="joint_source", name="主电机", type="rotation")
    follower = JointSpec(id="joint_follower", name="伴生电机", type="rotation")
    segment = DriveSegmentSpec(
        id="seg_mapping",
        name="变速段",
        start=0.5,
        duration=2.0,
        travel=20.0,
        speed=10.0,
        mode="duration",
        profile="mapping",
        mapping_source_joint_id=source.id,
        points=[[0.0, 0.0], [10.0, 6.0], [20.0, 20.0]],
    )
    drive = DriveSpec(id="drive_follower", name="伴生驱动", joint_id=follower.id, segments=[segment])
    project = ProjectSpec(
        id="project_v2131_regression",
        name="V2131回归模型",
        layers=[LayerSpec(id="layer_main", name="机构", joints=[source, follower])],
        drives=[drive],
    )
    axes = [{
        "name": "伴生驱动",
        "times": [0.0, 1.0, 2.0],
        "curves": [{"label": "伴生驱动", "values": [0.0, 6.0, 20.0], "unit": "deg"}],
    }]
    main_name, main_csv, mappings = build_time_series_bundle(project, axes)
    assert "MAPPING_POINT" in main_csv and "RESULT,伴生驱动" in main_csv
    assert mappings and mappings[0][0] == "伴生驱动--变速段映射表格.csv"

    with tempfile.TemporaryDirectory(prefix="vz2131_regression_") as temp:
        store = ModelStore(Path(temp))
        model = store.create({"id": "vz2131_model", "name": "V2131模型"}, preserve_id=True)
        payload = io.BytesIO()
        with zipfile.ZipFile(payload, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(main_name, main_csv.encode("utf-8"))
            for name, content in mappings:
                archive.writestr(name, content.encode("utf-8"))

        store.replace_time_series_archive(model["id"], payload.getvalue())
        manifest = store.time_series_editor_manifest(model["id"])
        assert manifest["hub_count"] == 1 and manifest["local_count"] == 0
        hub_item = manifest["items"][0]
        assert hub_item["scope"] == "hub" and hub_item["readonly"] is True
        assert hub_item["drives"][0]["segments"][0]["variable_speed"] is True

        source_before = store.time_series_path(model["id"], hub_item["name"]).read_bytes()
        manifest = store.copy_time_series(model["id"], "hub", hub_item["name"], "工程师副本")
        local = next(item for item in manifest["items"] if item["scope"] == "local")
        assert local["readonly"] is False
        drive_row = local["drives"][0]
        segment_row = drive_row["segments"][0]

        manifest = store.update_time_series_segment(
            model["id"], local["name"], drive_row["id"], segment_row["id"],
            {"start": 2.0, "mode": "speed", "speed": 5.0, "travel": 20.0},
        )
        local = next(item for item in manifest["items"] if item["scope"] == "local")
        edited = local["drives"][0]["segments"][0]
        assert edited["start"] == 2.0
        assert edited["duration"] == 4.0
        assert edited["end"] == 6.0
        local_text = store._workspace_time_series_path(model["id"], local["name"]).read_text("utf-8-sig")
        assert "MAPPING_POINT" in local_text and "RESULT,伴生驱动" in local_text
        assert store.time_series_path(model["id"], hub_item["name"]).read_bytes() == source_before

        # A fresh Hub sync may replace the authoritative library but must never erase VZ copies.
        store.replace_time_series_archive(model["id"], payload.getvalue())
        after_refresh = store.time_series_editor_manifest(model["id"])
        assert after_refresh["hub_count"] == 1 and after_refresh["local_count"] == 1

        local = next(item for item in after_refresh["items"] if item["scope"] == "local")
        renamed = store.rename_time_series_copy(model["id"], local["name"], "改名副本")
        local = next(item for item in renamed["items"] if item["scope"] == "local")
        assert local["name"] == "改名副本.csv"
        deleted = store.delete_time_series_copy(model["id"], local["name"])
        assert deleted["local_count"] == 0 and deleted["hub_count"] == 1

        user_manifest = store.time_series_manifest(model["id"])
        assert user_manifest["latest"] is not None and user_manifest["latest"]["scope"] == "hub"
        assert len(user_manifest["series"]) == 1

    engineer_html = text("integrations/VZ_Studio_V0.3.2.1/frontend/engineer.html")
    engineer_js = text("integrations/VZ_Studio_V0.3.2.1/frontend/engineer.js")
    engineer_css = text("integrations/VZ_Studio_V0.3.2.1/frontend/studio.css")
    client_html = text("integrations/VZ_Studio_V0.3.2.1/frontend/client.html")
    client_js = text("integrations/VZ_Studio_V0.3.2.1/frontend/client.js")
    client_css = text("integrations/VZ_Studio_V0.3.2.1/frontend/styles.css")
    animation_py = text("integrations/VZ_Studio_V0.3.2.1/vz/legacy_animation_html_export.py")
    app_js = text("frontend/app.js")
    index_html = text("frontend/index.html")
    main_py = text("backend/app/main.py")

    assert 'data-page="time-series"' in engineer_html and 'id="timeSeriesGantt"' in engineer_html
    assert "time-series-gantt-block" in engineer_js and "openTimeSeriesSegmentEditor" in engineer_js
    assert "item.readonly" in engineer_js and "Hub 同步时序不能直接修改" in engineer_html
    assert ".time-series-gantt-block.uniform{background:#f4c75a" in engineer_css
    assert ".time-series-gantt-block.variable{background:#4294d0" in engineer_css
    assert "action:'update_segment'" in engineer_js and "双击" in engineer_js
    # Reuse the second-generation WEB Gantt interactions without new model fields.
    for control_id in (
        'timeSeriesGanttScaleX', 'timeSeriesGanttScaleY', 'timeSeriesGanttCursorVisible',
        'timeSeriesGanttAutoSort', 'timeSeriesGanttSortDesc', 'timeSeriesGanttReverse',
        'timeSeriesGanttDriveList', 'timeSeriesGanttFullscreen',
    ):
        assert f'id="{control_id}"' in engineer_html
    for contract in (
        "saveTimeSeriesGanttUi", "timeSeriesGanttBaseRows", "includeReverse",
        "data-ts-gantt-visible", "data-ts-gantt-drive-row", "timeSeriesGanttPan",
    ):
        assert contract in engineer_js
    assert "localStorage.getItem('vz.timeSeriesGanttUi.v1')" in engineer_js
    assert ".time-series-gantt-cursor" in engineer_css and ".time-series-gantt-expanded" in engineer_css

    assert 'id="sceneTimeSeriesTabs"' in client_html
    assert "selectedSceneTimeSeries" in client_js and "时序${index+1}" in client_js
    assert "nodes.find(node=>node.model_id===state.model?.id)||nodes[0]" in client_js
    assert ".scene-coordinate-badge{top:auto!important" in client_css
    assert "left:2px!important;bottom:2px!important" in client_css
    assert "color:#fff!important" in client_css
    assert "background:rgba(18,24,34,.20)" in animation_py
    assert ".transport-button{min-width:20px;height:17px" in animation_py

    assert "function adaptiveAddResultAxes()" in app_js
    assert "function adaptiveResultAxisName(axisIndex)" in app_js
    assert 'data-action="adaptive-result-axis-name"' in app_js
    assert 'id="adaptiveAddResultAxesButton"' in index_html
    assert "publishResultAxesTimeSeries" in app_js and "pushResultAxesCsvDelivery" not in app_js
    assert "合并 CSV 是模型时序库文件" in index_html

    assert 'LEGACY_DELIVERY_KINDS = {"axes_csv_folder"}' in main_py
    assert 'required_kinds = {"nx_afu_script", "gantt_png", "model_json", "animation_html"}' in main_py
    assert '"time_series_only": True' in main_py and '"delivery": False' in main_py
    desktop_block = main_py[main_py.index("desktop_only = ("):main_py.index("if desktop_only:")]
    assert "export-axes-csv" not in desktop_block
    read_only_block = main_py[main_py.index("is_read_only_action = ("):main_py.index("write_request = (", main_py.index("is_read_only_action = ("))]
    assert "export-axes-csv" not in read_only_block
    assert "def _result_axes_csv_files" not in main_py

    architecture = text("architecture_master_prompt.md")
    assert "第八十七部分：V2.13.1" in architecture
    assert "新增业务 Tool 目录 0" in architecture
    assert "managed delivery 当前只有四类" in architecture

    print("V2.13.1 time-series/UI/CSV-delivery regression: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
