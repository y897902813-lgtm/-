# Integration validation

Validated on 2026-09-08 in a temporary Linux test workspace.

- Python syntax: `compileall`/`py_compile` passed for MuJoCo backend, integrated VZ backend, and both launchers.
- JavaScript syntax: `node --check` passed for MuJoCo Hub `app.js`, VZ `engineer.js`, and VZ `client.js`.
- VZ regression suite: 83 tests passed, 2 skipped.
- VZ modeling-exchange suite: 9 tests passed.
- Live VZ HTTP smoke test: health endpoint, engineer/client catalog scope, Hub publication metadata, original-name retention, and native-copy isolation passed.
- MuJoCo→VZ publisher helper smoke test: temporary Hub model was published to a live VZ service, hidden from the client catalog when switched off, restored when switched on, and retained the engineer-renamed VZ name plus the original Hub source name.
- MuJoCo launcher integration smoke test: bundled VZ 0.3.2.1 child service auto-started and reached `/api/health` successfully.
- Visible engineer UI contract checked: removed controls are absent from the visible UI; drive settings occupy the main workspace; model name/material/render/save controls remain.

Note: the test container did not have `passlib` preinstalled, so the direct publisher-helper smoke test supplied a minimal import-time stub for that unrelated authentication dependency. `Server/start.bat` installs the complete `Server/requirements.txt`, which includes `passlib>=1.7,<2`.
