# EntryFX timing1 / package-size note

## Interaction timing (V13 PrecisionFocus)

- Interaction zone: centered on the WebGL dynamics core; radius remains responsive to the viewport.
- Core response: about 100 ms attack / 300 ms release, so cursor-following feels immediate without snapping.
- Ring response: about 280 ms attack / 420 ms release. Ring tilt is reduced to roughly 14° / 16° / 18° with a calmer ~0.9x / 1.35x / 1.8x speed hierarchy.
- Particle field: procedural field reduced from 1,480 to 1,120 points. Hover still produces a restrained outward breathing response, but no longer reads as a continuous particle eruption.
- Long hover: activation now plateaus before the former threshold-break region; the login core no longer escalates into repeated vent / shockwave / heat-haze fireworks.
- Core spin: heat-driven acceleration is capped to a precision-instrument range instead of reaching the former extreme overheat speed.
- Login success: WebGL aperture handoff is about 760 ms; JS reload handoff waits about 780 ms. Final zoom and rotational kick are substantially reduced.
- Reduced motion: WebGL and Canvas2D fallbacks freeze the continuous core/ring/particle motion and use a short opacity handoff.
- Touch / pen: active pointer lifecycle is explicit, so touch interaction releases on pointer-up/cancel instead of leaving a sticky hover state.
- Asset startup: the GLB is preloaded with the exact cache-busted URL used by the viewer.

## Why the original ZIP was about 62 MB

The release ZIP accidentally included pip temporary download/unpack directories and raw temporary files under `Server/`.
They are not referenced by `start.sh`, `start.bat`, `requirements.txt`, or application code.
The normal startup path still creates `.venv` and installs from `requirements.txt`.

The largest removable content was:

- `Server/pip-unpack-*`: roughly 55.2 MiB compressed.
- `Server/tmp*`: roughly 4.7 MiB compressed.
- `Server/pip-metadata-*`: roughly 0.15 MiB compressed.

Together they were about 97.6% of the compressed package. The actual application, GLB, frontend, backend, VZ integration and documentation are only around 1.5 MiB compressed.

If a truly offline installer is required later, use an intentional `wheels/` wheelhouse and point pip to it; do not ship pip's transient `pip-unpack-*` / `pip-metadata-*` working directories.


## Timing / interaction refinement (timing2)

- Removed the surrounding orbit-bar / stick cylinders entirely.
- Reduced the orbit-coin / round peripheral cylinders to half density: 28 -> 14.
- Added a tighter inner white core ring so the centre-hole area reads more blue-white.
- Increased emissive response of the cyan / reactor materials.
- The centre gear-hole blue/white core now gets a soft white emissive aura closer to the surrounding particle glow.


## V6 volcanic core / render recovery

- Rebuilt the login WebGL viewer from the last stable clip-fix baseline to eliminate the regression where the centre core stopped rendering.
- Kept the slim geometry package: removed outer sticks, reduced peripheral coins, strengthened blue-white center glow.
- Added a 20-second heat buildup.
- The core now keeps its original blue/steel detail while heating, instead of washing out to flat white.
- Added a dedicated center-hole white vent particle spray that only becomes visible near extreme overheat.
- Added a dedicated core spin that accelerates from slow to very fast as heat accumulates.
- While hovered, the three orbital rings continuously keep changing tilt instead of settling into a static lean.
- Surrounding particles slightly intensify with heat as an extra polish layer.


## V7 FurnaceWave

- Added a white-hot outward shockwave ring that appears together with the center-hole venting near maximum heat.
- Added a localized heat-haze / refractive-distortion style layer around the core using a soft turbulent additive particle field.
- Fixed the ring-hover bug: the three rings no longer snap/jerk several times at hover entry.
- Ring motion now ramps in smoothly, then continuously changes tilt and local rotation axis while hovered.
- Outer / middle / inner ring motion speeds are now staged at 1x / 2x / 3x, with the inner ring moving three times as fast as the outer ring.
- The hover-to-tilt target is about 30 degrees, with slightly smaller amplitude on the outer ring and the largest amplitude on the inner ring.
- Preserved the V6 20-second heat buildup, center-hole white vent particles, core-detail-preserving heat shading, and heat-driven core spin.


## V8 ThresholdBreak

- Added a pre-burst threshold cycle at extreme heat: the center core now briefly contracts / stores energy, then breaks out into the white vent + shockwave.
- White-hot center-hole vent particles now intensify specifically during the breakthrough burst window.
- The shockwave ring is now directly coupled to the burst window instead of being only a generic high-heat pulse.
- Added a stronger heat-haze / air-distortion layer that swells during the threshold-break burst.
- Preserved the smoother hover-entry ring motion. Rings still change tilt continuously and keep the 1x / 2x / 3x outer/middle/inner speed hierarchy.
- Rendering stack remains a custom WebGL2 viewer reading a GLB asset plus glTF-like material factors.


## V9 PBRMetalCore

- Began the "Scheme B" upgrade path toward a more realistic PBR presentation.
- The outer main core gear now has its own `Brushed Silver Core` GLB material instead of sharing the general blue-steel ring material.
- Replaced the previous simplified mesh shading with a more PBR-like custom WebGL2 shader:
  - GGX-style microfacet direct specular
  - Schlick fresnel
  - approximate image-based lighting / environment reflections
  - metallic/roughness response
  - ACES-like tone mapping
- Retained the V8 threshold-break behavior (charge -> brief contraction -> burst), white vent particles, shockwave ring, and heat haze.
- This is still a custom lightweight renderer, not yet a full HDRI + postprocessing engine like a dedicated DCC or high-end Three.js pipeline.

## V9.1 shader compatibility fix

The V9 PBR renderer used the identifier `active` inside three GLSL ES shader strings.
`active` is reserved by GLSL ES/WebGL on some drivers, causing:
`Illegal use of reserved word` / `syntax error`.

V9.1 renames that identifier to `activation` everywhere and updates the cache version.

## V9.2 runtime compatibility

The prior build treated a missing WebGL2 context as fatal. Some embedded browsers/WebViews
can expose WebGL1 but not WebGL2, even when previous simpler builds appeared to work.

V9.2 uses this startup order:

1. WebGL2: full PBR-like renderer.
2. WebGL1: compatibility renderer using translated GLSL ES 1.00 shaders.
3. Canvas2D: visual fallback so the login core is still present when GPU WebGL is unavailable.

The full PBR path remains WebGL2 when the environment supports it.

## V9.3 palette rebalance

User feedback: metal feel returned, but blue ring accents and the core blue were washed out,
and the overall image leaned too white.

This revision restores the intended silver-blue style by:
- making the silver core cooler and more steel-like instead of near-white;
- increasing cyan/reactor emissive intensity in the GLB materials;
- reducing white bias in the PBR-like shader environment and glow response;
- boosting ring-base blue contribution and ring emissive output at runtime.

## V10 AzureForge

Intent:
- Push the visual design further toward the user's silver-blue reference direction.

Work completed:
- stronger structural layering in the core itself;
- restored / enhanced blue energy language in both outer rings and the center;
- pulled broad white back toward cooler silver;
- kept the current runtime compatibility improvements intact.

## V11 ReactorAegis

Goal:
- Continue from V10 and move the core even closer to a layered silver-blue industrial reactor.

Main visual changes:
- more mechanical segmentation around the outer core ring;
- deeper blue energy slots in the center;
- stronger ring blue accents;
- metallic white pushed further toward cold silver;
- slightly sharper procedural highlight breakup for a more machined feel.

## V12 SpectralAegis — prompt visual-tech extraction

Useful ideas extracted from the provided web-project prompts:
- `mix-blend-mode: screen` -> translated into an additive WebGL glow-shell pass.
- radial spotlight mask -> translated into cursor-reactive metallic/specular focus on the reactor.
- blurred/saturated scene layers -> translated into the existing heat haze plus stronger additive halo.
- cyberpunk reveal language -> translated into animated spectral scan bands and front-face photon rails.

Not copied/bundled:
- remote product images, hero images, MP4 video, or third-party fonts.
- Those are presentation assets for unrelated projects, not generic metal/PBR material maps.

The project therefore remains self-contained/offline and avoids adding third-party visual assets whose redistribution rights are unknown.
